import React, { useEffect } from 'react';
import { createPortal } from 'react-dom';
import { X } from 'lucide-react';
import { useApp } from '@/src/context/AppContext';
import { useMobilePortalContainer } from '@/src/layouts/MobileShell';

interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  subtitle?: string;
  children: React.ReactNode;
}

export const Modal: React.FC<ModalProps> = ({
  isOpen,
  onClose,
  title,
  subtitle,
  children,
}) => {
  const portalContainer = useMobilePortalContainer();
  const { t } = useApp();

  useEffect(() => {
    if (!isOpen) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const sheetContent = (
    <div
      className="pointer-events-auto absolute inset-0 z-50 flex items-end justify-center bg-[#172554]/35 backdrop-blur-[2px]"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
    >
      <div
        className="w-full rounded-t-3xl bg-white border-t border-slate-200 shadow-2xl overflow-hidden max-h-[88%] flex flex-col animate-[slideUp_180ms_ease-out]"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="w-10 h-1 bg-slate-300 rounded-full mx-auto mt-2.5 shrink-0" />
        <div className="flex items-start justify-between gap-3 px-4 py-3.5 border-b border-slate-100 shrink-0">
          <div className="min-w-0">
            <h2 className="text-base font-display font-semibold text-[#172554] truncate">
              {title}
            </h2>
            {subtitle && (
              <p className="text-[11px] text-[#64748B] mt-0.5 truncate">{subtitle}</p>
            )}
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label={t.common.close}
            className="min-h-[38px] min-w-[38px] rounded-full flex items-center justify-center text-[#64748B] hover:text-[#172554] hover:bg-slate-100 cursor-pointer shrink-0"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-4 pb-6 overflow-y-auto">{children}</div>
      </div>
    </div>
  );

  if (portalContainer) {
    return createPortal(sheetContent, portalContainer);
  }
  return sheetContent;
};
