import React from 'react';
import { Mic, Square, Loader2 } from 'lucide-react';
import { useApp } from '@/src/context/AppContext';
import { VoiceState } from '@/src/types';

interface MicrophoneButtonProps {
  voiceState: VoiceState;
  onStart: () => void;
  onStop: () => void;
  size?: 'md' | 'lg';
}

export const MicrophoneButton: React.FC<MicrophoneButtonProps> = ({
  voiceState,
  onStart,
  onStop,
  size = 'lg',
}) => {
  const { t } = useApp();
  const isRecording = voiceState === 'RECORDING';
  const isProcessing =
    voiceState === 'AUDIO_READY' ||
    voiceState === 'TRANSCRIBING' ||
    voiceState === 'INTERPRETING' ||
    voiceState === 'VALIDATING' ||
    voiceState === 'SAVING';

  const dimensions =
    size === 'lg' ? 'w-28 h-28 sm:w-32 sm:h-32' : 'w-20 h-20';

  const handleClick = () => {
    if (isProcessing) return;
    if (isRecording) onStop();
    else onStart();
  };

  return (
    <div className="relative inline-flex items-center justify-center my-2">
      <span
        aria-hidden="true"
        className={`absolute -inset-5 rounded-full transition-all duration-300 ${
          isRecording
            ? 'bg-[#DBEAFE] animate-[micPulse_1.5s_ease-in-out_infinite]'
            : isProcessing
            ? 'bg-[#DBEAFE]/80 animate-pulse'
            : 'bg-[#DBEAFE]/70'
        }`}
      />

      {isRecording ? (
        <span
          aria-hidden="true"
          className="absolute -inset-2.5 rounded-full border-2 border-[#2563EB]/45 animate-ping"
        />
      ) : (
        <span
          aria-hidden="true"
          className="absolute -inset-2.5 rounded-full border border-[#93C5FD]/60"
        />
      )}

      <button
        type="button"
        onClick={handleClick}
        disabled={isProcessing}
        aria-label={isRecording ? t.voice.micAriaStop : t.voice.micAriaStart}
        className={`relative z-10 ${dimensions} rounded-full flex flex-col items-center justify-center gap-1 transition-all duration-200 focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-[#2563EB]/40 active:scale-95 cursor-pointer disabled:opacity-85 border-4 border-white ${
          isRecording
            ? 'bg-[#1D4ED8] text-white shadow-[0_14px_38px_rgba(37,99,235,0.5)]'
            : isProcessing
            ? 'bg-[#2563EB] text-white shadow-[0_10px_30px_rgba(37,99,235,0.35)]'
            : 'bg-[#2563EB] text-white shadow-[0_12px_34px_rgba(37,99,235,0.38)] hover:bg-[#1D4ED8]'
        }`}
      >
        {isRecording ? (
          <>
            <Square className="w-8 h-8 text-white fill-white" />
            <span className="text-[10px] font-semibold tracking-wide text-blue-100">
              {t.voice.stopLabel}
            </span>
          </>
        ) : isProcessing ? (
          <Loader2 className="w-11 h-11 text-white animate-spin" />
        ) : (
          <Mic className="w-12 h-12 text-white stroke-[2.2]" />
        )}
      </button>
    </div>
  );
};
