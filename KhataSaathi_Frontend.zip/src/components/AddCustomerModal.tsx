import React, { useMemo, useState } from 'react';
import { AlertTriangle, IndianRupee, Phone, UserPlus } from 'lucide-react';
import { useApp } from '@/src/context/AppContext';
import { findDuplicateCustomerMatches } from '@/src/services/mock/ledgerEngine';
import { Customer } from '@/src/types';
import { parseRupeesToPaise } from '@/src/utils/currency';
import { Button } from './Button';
import { Input } from './Input';
import { Modal } from './Modal';

interface AddCustomerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCreated?: (customer: Customer) => void;
}

export const AddCustomerModal: React.FC<AddCustomerModalProps> = ({
  isOpen,
  onClose,
  onCreated,
}) => {
  const { customers, addCustomer, t } = useApp();
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [openingBalance, setOpeningBalance] = useState('');
  const [notes, setNotes] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [duplicateAck, setDuplicateAck] = useState(false);

  const duplicateMatches = useMemo(
    () => findDuplicateCustomerMatches(name, phone, customers),
    [name, phone, customers]
  );

  const resetForm = () => {
    setName('');
    setPhone('');
    setOpeningBalance('');
    setNotes('');
    setError(null);
    setDuplicateAck(false);
  };

  const handleClose = () => {
    resetForm();
    onClose();
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (name.trim().length < 2) {
      setError(t.modals.errNameMin);
      return;
    }

    let openingPaise = 0;
    if (openingBalance.trim()) {
      const parsed = parseRupeesToPaise(openingBalance, false);
      if (parsed === null) {
        setError(t.modals.errInvalidOpeningBal);
        return;
      }
      openingPaise = parsed;
    }

    if (duplicateMatches.length > 0 && !duplicateAck) {
      setError(t.modals.errDuplicateAck);
      return;
    }

    const result = addCustomer({
      name,
      phone,
      notes,
      openingBalancePaise: openingPaise,
    });

    if (!result.ok || !result.data) {
      setError(result.error || t.modals.errCreateCustomer);
      return;
    }

    const created = result.data;
    resetForm();
    onClose();
    onCreated?.(created);
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={handleClose}
      title={t.modals.addCustomerTitle}
      subtitle={t.modals.addCustomerSubtitle}
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        <Input
          label={t.modals.customerNameLabel}
          placeholder={t.modals.customerNamePlaceholder}
          value={name}
          onChange={(e) => {
            setName(e.target.value);
            setDuplicateAck(false);
          }}
          required
        />

        <Input
          label={t.modals.mobileLabel}
          placeholder={t.modals.mobilePlaceholder}
          type="tel"
          leftAddon={<Phone className="w-4 h-4" />}
          value={phone}
          onChange={(e) => {
            setPhone(e.target.value);
            setDuplicateAck(false);
          }}
        />

        <Input
          label={t.modals.openingBalLabel}
          placeholder="0"
          inputMode="decimal"
          leftAddon={<IndianRupee className="w-4 h-4" />}
          value={openingBalance}
          onChange={(e) => setOpeningBalance(e.target.value)}
          helperText={t.modals.openingBalHelper}
        />

        <Input
          label={t.modals.notesLabel}
          placeholder={t.modals.notesPlaceholder}
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
        />

        {duplicateMatches.length > 0 && (
          <div className="rounded-xl bg-amber-50 border border-amber-200 p-3.5 space-y-2">
            <div className="flex items-start gap-2.5 text-amber-800 text-xs font-medium">
              <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5 text-amber-600" />
              <div>
                <p>{t.modals.duplicateWarning}</p>
                <ul className="mt-1 space-y-0.5 text-amber-700 font-normal">
                  {duplicateMatches.slice(0, 3).map((m) => (
                    <li key={m.id}>
                      {m.name} {m.phone ? `· ${m.phone}` : ''}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
            <label className="flex items-center gap-2 text-xs text-[#172554] cursor-pointer pt-1">
              <input
                type="checkbox"
                checked={duplicateAck}
                onChange={(e) => setDuplicateAck(e.target.checked)}
                className="rounded border-slate-300 bg-white text-[#2563EB] focus:ring-[#2563EB]"
              />
              <span>{t.modals.addAnyway}</span>
            </label>
          </div>
        )}

        {error && (
          <div className="rounded-xl bg-orange-50 border border-orange-200 px-3.5 py-2.5 text-xs text-orange-700">
            {error}
          </div>
        )}

        <div className="flex items-center justify-end gap-3 pt-2">
          <Button variant="ghost" onClick={handleClose}>
            {t.common.cancel}
          </Button>
          <Button type="submit" leftIcon={<UserPlus className="w-4 h-4" />}>
            {t.modals.createBtn}
          </Button>
        </div>
      </form>
    </Modal>
  );
};
