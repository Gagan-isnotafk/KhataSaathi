import React from 'react';

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
  helperText?: string;
  leftAddon?: React.ReactNode;
  rightAddon?: React.ReactNode;
}

export const Input: React.FC<InputProps> = ({
  label,
  error,
  helperText,
  leftAddon,
  rightAddon,
  className = '',
  id,
  ...props
}) => {
  const inputId = id || (label ? label.toLowerCase().replace(/\s+/g, '-') : undefined);

  return (
    <div className="w-full space-y-1.5">
      {label && (
        <label
          htmlFor={inputId}
          className="block text-xs font-semibold text-[#172554] tracking-wide"
        >
          {label}
        </label>
      )}
      <div
        className={`flex items-center rounded-xl bg-[#F8FAFF] border transition-colors min-h-[48px] px-3.5 gap-2.5 ${
          error
            ? 'border-red-400 focus-within:border-red-500'
            : 'border-slate-200 focus-within:border-[#2563EB] focus-within:bg-white'
        }`}
      >
        {leftAddon && <div className="text-[#64748B] shrink-0">{leftAddon}</div>}
        <input
          id={inputId}
          className={`w-full bg-transparent text-sm text-[#172554] placeholder:text-slate-400 focus:outline-none tabular-nums ${className}`}
          {...props}
        />
        {rightAddon && <div className="text-[#64748B] shrink-0">{rightAddon}</div>}
      </div>
      {error && <p className="text-xs text-red-600 font-medium">{error}</p>}
      {!error && helperText && <p className="text-xs text-[#64748B]">{helperText}</p>}
    </div>
  );
};
