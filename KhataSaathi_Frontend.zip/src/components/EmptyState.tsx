import React from 'react';
import { Button } from './Button';

interface EmptyStateProps {
  icon: React.ReactNode;
  title: string;
  description: string;
  actionLabel?: string;
  onAction?: () => void;
}

export const EmptyState: React.FC<EmptyStateProps> = ({
  icon,
  title,
  description,
  actionLabel,
  onAction,
}) => {
  return (
    <div className="rounded-2xl bg-white border border-slate-200/80 shadow-[0_2px_10px_rgba(37,99,235,0.04)] p-8 sm:p-10 text-center flex flex-col items-center justify-center gap-3">
      <div className="w-12 h-12 rounded-2xl bg-[#DBEAFE]/60 border border-[#DBEAFE] flex items-center justify-center text-[#2563EB]">
        {icon}
      </div>
      <div className="space-y-1 max-w-sm">
        <h3 className="text-base font-semibold text-[#172554]">{title}</h3>
        <p className="text-sm text-[#64748B] leading-relaxed">{description}</p>
      </div>
      {actionLabel && onAction && (
        <div className="pt-2">
          <Button variant="primary" size="sm" onClick={onAction}>
            {actionLabel}
          </Button>
        </div>
      )}
    </div>
  );
};
