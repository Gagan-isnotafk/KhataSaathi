import React from 'react';
import { ChevronRight } from 'lucide-react';
import { useApp } from '@/src/context/AppContext';
import { CustomerSummary } from '@/src/types';
import { formatINR } from '@/src/utils/currency';
import { formatDateTime } from '@/src/utils/date';

interface CustomerCardProps {
  summary: CustomerSummary;
  onClick: () => void;
}

function getInitials(name: string): string {
  return name
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase() || '')
    .join('');
}

export const CustomerCard: React.FC<CustomerCardProps> = ({ summary, onClick }) => {
  const { shop, t } = useApp();
  const { customer, currentBalancePaise, transactionCount, lastTransactionAt } = summary;
  const isDue = currentBalancePaise > 0;
  const isAdvance = currentBalancePaise < 0;

  return (
    <button
      type="button"
      onClick={onClick}
      className="w-full text-left rounded-2xl bg-white border border-slate-200/80 shadow-[0_2px_10px_rgba(37,99,235,0.04)] hover:border-[#BFDBFE] active:bg-[#F8FAFF] transition-colors p-3.5 flex items-center justify-between gap-3 min-h-[72px] cursor-pointer group"
    >
      <div className="flex items-center gap-3 min-w-0">
        <div className="w-11 h-11 rounded-xl bg-[#DBEAFE] text-[#2563EB] flex items-center justify-center text-sm font-bold shrink-0">
          {getInitials(customer.name)}
        </div>
        <div className="min-w-0 space-y-0.5">
          <div className="flex items-center gap-1.5">
            <span className="text-[15px] font-semibold text-[#172554] truncate">
              {customer.name}
            </span>
            {customer.status === 'INACTIVE' && (
              <span className="text-[11px] text-[#64748B] shrink-0">
                {t.customers.inactiveTag}
              </span>
            )}
          </div>
          <div className="flex items-center gap-1.5 text-xs text-[#64748B] truncate">
            {customer.phone && <span className="tabular-nums">{customer.phone}</span>}
            {customer.phone && <span aria-hidden="true">·</span>}
            <span>{t.common.entriesCount(transactionCount)}</span>
            {lastTransactionAt && (
              <>
                <span aria-hidden="true">·</span>
                <span className="truncate">{formatDateTime(lastTransactionAt, shop.language)}</span>
              </>
            )}
          </div>
        </div>
      </div>

      <div className="flex items-center gap-2 shrink-0">
        <div className="text-right">
          <div
            className={`text-base font-bold font-mono tabular-nums ${
              isDue
                ? 'text-orange-600'
                : isAdvance
                ? 'text-green-600'
                : 'text-[#172554]'
            }`}
          >
            {formatINR(Math.abs(currentBalancePaise))}
          </div>
          <div className="text-[11px] font-medium text-[#64748B]">
            {isDue
              ? t.customers.statusDue
              : isAdvance
              ? t.customers.statusAdvance
              : t.customers.statusSettled}
          </div>
        </div>
        <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-[#2563EB] transition-colors" />
      </div>
    </button>
  );
};
