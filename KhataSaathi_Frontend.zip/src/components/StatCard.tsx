import React from 'react';

interface StatCardProps {
  label: string;
  value: string;
  sublabel?: string;
  tone?: 'neutral' | 'blue' | 'green' | 'orange' | 'amber';
  icon?: React.ReactNode;
  onClick?: () => void;
}

export const StatCard: React.FC<StatCardProps> = ({
  label,
  value,
  sublabel,
  tone = 'neutral',
  icon,
  onClick,
}) => {
  const valueTone: Record<NonNullable<StatCardProps['tone']>, string> = {
    neutral: 'text-[#172554]',
    blue: 'text-[#2563EB]',
    green: 'text-green-600',
    orange: 'text-orange-600',
    amber: 'text-amber-600',
  };

  const interactiveClass = onClick
    ? 'cursor-pointer hover:border-[#BFDBFE] active:bg-[#F8FAFF] transition-colors text-left w-full'
    : '';

  const Wrapper = onClick ? 'button' : 'div';

  return (
    <Wrapper
      type={onClick ? 'button' : undefined}
      onClick={onClick}
      className={`rounded-2xl bg-white border border-slate-200/80 shadow-[0_2px_10px_rgba(37,99,235,0.04)] p-4 flex flex-col justify-between gap-2.5 ${interactiveClass}`}
    >
      <div className="flex items-center justify-between gap-2">
        <span className="text-xs font-medium text-[#64748B] truncate">{label}</span>
        {icon && <span className="text-[#2563EB] shrink-0">{icon}</span>}
      </div>
      <div className="space-y-0.5">
        <div
          className={`text-xl sm:text-2xl font-bold font-display tracking-tight tabular-nums ${valueTone[tone]}`}
        >
          {value}
        </div>
        {sublabel && <p className="text-[11px] text-[#64748B] truncate">{sublabel}</p>}
      </div>
    </Wrapper>
  );
};
