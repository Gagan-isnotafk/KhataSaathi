import React from 'react';
import { ArrowDownLeft, ArrowUpRight, RotateCcw, Mic, PenLine } from 'lucide-react';
import { useApp } from '@/src/context/AppContext';
import { Transaction } from '@/src/types';
import { formatINR } from '@/src/utils/currency';
import { formatDateTime } from '@/src/utils/date';

interface TransactionCardProps {
  transaction: Transaction;
  customerName?: string;
  onClick?: () => void;
  onReverse?: (transaction: Transaction) => void;
}

export const TransactionCard: React.FC<TransactionCardProps> = ({
  transaction,
  customerName,
  onClick,
  onReverse,
}) => {
  const { shop, t } = useApp();
  const isCredit = transaction.type === 'CREDIT';
  const isRepayment = transaction.type === 'REPAYMENT';
  const isReversal = transaction.type === 'REVERSAL';
  const isReversed = transaction.status === 'REVERSED';

  const typeLabel = isCredit
    ? t.labels.credit
    : isRepayment
    ? t.labels.repayment
    : t.labels.reversal;

  const iconBox = isCredit
    ? 'bg-orange-50 text-orange-600 border-orange-200/80'
    : isRepayment
    ? 'bg-green-50 text-green-600 border-green-200/80'
    : 'bg-blue-50 text-[#2563EB] border-blue-200/80';

  return (
    <div
      className={`rounded-2xl bg-white border border-slate-200/80 shadow-[0_2px_10px_rgba(37,99,235,0.04)] p-3.5 flex items-center justify-between gap-3 transition-colors ${
        onClick ? 'hover:border-[#BFDBFE] active:bg-[#F8FAFF] cursor-pointer' : ''
      } ${isReversed ? 'opacity-65' : ''}`}
      onClick={onClick}
      role={onClick ? 'button' : undefined}
      tabIndex={onClick ? 0 : undefined}
      onKeyDown={
        onClick
          ? (e) => {
              if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                onClick();
              }
            }
          : undefined
      }
    >
      <div className="flex items-center gap-3 min-w-0">
        <div
          className={`w-10 h-10 rounded-xl border flex items-center justify-center shrink-0 ${iconBox}`}
        >
          {isCredit && <ArrowUpRight className="w-4 h-4" />}
          {isRepayment && <ArrowDownLeft className="w-4 h-4" />}
          {isReversal && <RotateCcw className="w-4 h-4" />}
        </div>

        <div className="min-w-0 space-y-0.5">
          <div className="flex items-center gap-1.5 min-w-0">
            <span className="text-[14px] font-semibold text-[#172554] truncate">
              {customerName || transaction.description}
            </span>
            {isReversed && (
              <span className="text-[11px] font-medium text-amber-600 shrink-0">
                · {t.labels.reversal}
              </span>
            )}
          </div>

          <div className="flex items-center gap-1.5 text-xs text-[#64748B] truncate">
            <span
              className={`font-medium ${
                isCredit
                  ? 'text-orange-600'
                  : isRepayment
                  ? 'text-green-600'
                  : 'text-[#2563EB]'
              }`}
            >
              {typeLabel}
            </span>
            <span aria-hidden="true">·</span>
            <span className="inline-flex items-center gap-1">
              {transaction.source === 'VOICE' ? (
                <Mic className="w-3 h-3 text-[#2563EB]" />
              ) : (
                <PenLine className="w-3 h-3 text-slate-400" />
              )}
              {transaction.source === 'VOICE' ? t.labels.voiceEntry : t.labels.manualEntry}
            </span>
            <span aria-hidden="true">·</span>
            <span className="truncate">{formatDateTime(transaction.occurredAt, shop.language)}</span>
          </div>

          {customerName && transaction.description && (
            <p className="text-xs text-slate-400 truncate">{transaction.description}</p>
          )}
        </div>
      </div>

      <div className="flex items-center gap-2 shrink-0">
        <div className="text-right">
          <div
            className={`text-base font-bold font-mono tabular-nums ${
              isReversed
                ? 'line-through text-slate-400'
                : isCredit
                ? 'text-orange-600'
                : isRepayment
                ? 'text-green-600'
                : 'text-[#2563EB]'
            }`}
          >
            {isCredit ? '+' : isRepayment ? '-' : ''}
            {formatINR(transaction.amountPaise)}
          </div>
        </div>

        {onReverse && transaction.status === 'POSTED' && transaction.type !== 'REVERSAL' && (
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              onReverse(transaction);
            }}
            title={t.labels.reverseBtnTitle}
            className="min-h-[34px] px-2.5 rounded-lg border border-slate-200 bg-[#F8FAFF] text-[11px] font-semibold text-[#64748B] hover:text-orange-600 hover:border-orange-200 hover:bg-orange-50 transition-colors cursor-pointer"
          >
            {t.common.reverse}
          </button>
        )}
      </div>
    </div>
  );
};
