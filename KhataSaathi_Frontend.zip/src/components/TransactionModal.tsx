import React, { useEffect, useMemo, useState } from 'react';
import { AlertTriangle, CheckCircle2, IndianRupee } from 'lucide-react';
import { useApp } from '@/src/context/AppContext';
import { formatINR, parseRupeesToPaise } from '@/src/utils/currency';
import { generateIdempotencyKey } from '@/src/utils/idempotency';
import { Button } from './Button';
import { Input } from './Input';
import { Modal } from './Modal';

interface TransactionModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialType?: 'CREDIT' | 'REPAYMENT';
  initialCustomerId?: string;
}

export const TransactionModal: React.FC<TransactionModalProps> = ({
  isOpen,
  onClose,
  initialType = 'CREDIT',
  initialCustomerId = '',
}) => {
  const { customerSummaries, recordTransaction, t } = useApp();

  const activeCustomers = useMemo(
    () => customerSummaries.filter((s) => s.customer.status === 'ACTIVE'),
    [customerSummaries]
  );

  const [type, setType] = useState<'CREDIT' | 'REPAYMENT'>(initialType);
  const [customerId, setCustomerId] = useState(initialCustomerId);
  const [amountInput, setAmountInput] = useState('');
  const [description, setDescription] = useState('');
  const [dateInput, setDateInput] = useState(() => new Date().toISOString().slice(0, 16));
  const [idempotencyKey, setIdempotencyKey] = useState(() => generateIdempotencyKey('manual'));
  const [error, setError] = useState<string | null>(null);
  const [overpaymentConfirmed, setOverpaymentConfirmed] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setType(initialType);
      setCustomerId(initialCustomerId || activeCustomers[0]?.customer.id || '');
      setAmountInput('');
      setDescription('');
      setDateInput(new Date().toISOString().slice(0, 16));
      setIdempotencyKey(generateIdempotencyKey('manual'));
      setError(null);
      setOverpaymentConfirmed(false);
    }
  }, [isOpen, initialType, initialCustomerId, activeCustomers]);

  const selectedSummary = useMemo(
    () => activeCustomers.find((s) => s.customer.id === customerId),
    [activeCustomers, customerId]
  );

  const parsedPaise = parseRupeesToPaise(amountInput, true);
  const currentBalance = selectedSummary?.currentBalancePaise ?? 0;
  const newBalance =
    parsedPaise === null
      ? currentBalance
      : type === 'CREDIT'
      ? currentBalance + parsedPaise
      : currentBalance - parsedPaise;

  const isOverpayment =
    type === 'REPAYMENT' && parsedPaise !== null && parsedPaise > Math.max(0, currentBalance);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!customerId) {
      setError(t.modals.errSelectCustomer);
      return;
    }

    if (parsedPaise === null) {
      setError(t.modals.errValidAmount);
      return;
    }

    if (isOverpayment && !overpaymentConfirmed) {
      setError(t.modals.errConfirmOverpay);
      return;
    }

    const res = recordTransaction({
      customerId,
      type,
      amountPaise: parsedPaise,
      description:
        description.trim() ||
        (type === 'CREDIT' ? 'Manual credit entry' : 'Manual repayment received'),
      source: 'MANUAL',
      occurredAt: dateInput ? new Date(dateInput).toISOString() : new Date().toISOString(),
      idempotencyKey,
    });

    if (!res.ok) {
      setError(res.error || t.modals.errSaveTxn);
      return;
    }

    onClose();
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={type === 'CREDIT' ? t.modals.txnAddCreditTitle : t.modals.txnRecordRepaymentTitle}
      subtitle={t.modals.txnSubtitle}
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="grid grid-cols-2 gap-1.5 p-1 rounded-xl bg-[#F5F8FF] border border-slate-200">
          <button
            type="button"
            onClick={() => {
              setType('CREDIT');
              setOverpaymentConfirmed(false);
            }}
            className={`min-h-[40px] rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
              type === 'CREDIT'
                ? 'bg-orange-50 text-orange-700 border border-orange-200 shadow-xs'
                : 'text-[#64748B] hover:text-[#172554]'
            }`}
          >
            {t.modals.creditTab}
          </button>
          <button
            type="button"
            onClick={() => {
              setType('REPAYMENT');
              setOverpaymentConfirmed(false);
            }}
            className={`min-h-[40px] rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
              type === 'REPAYMENT'
                ? 'bg-green-50 text-green-700 border border-green-200 shadow-xs'
                : 'text-[#64748B] hover:text-[#172554]'
            }`}
          >
            {t.modals.repaymentTab}
          </button>
        </div>

        <div className="space-y-1.5">
          <label className="block text-xs font-medium text-[#172554]">
            {t.modals.selectCustomerLabel}
          </label>
          <select
            value={customerId}
            onChange={(e) => {
              setCustomerId(e.target.value);
              setOverpaymentConfirmed(false);
            }}
            className="w-full min-h-[46px] rounded-xl bg-white border border-slate-200 px-3.5 text-sm text-[#172554] focus:outline-none focus:border-[#2563EB] focus:ring-2 focus:ring-[#DBEAFE]"
            required
          >
            <option value="">{t.modals.selectCustomerOption}</option>
            {activeCustomers.map((s) => (
              <option key={s.customer.id} value={s.customer.id}>
                {s.customer.name} ({formatINR(s.currentBalancePaise)} {t.modals.dueSuffix})
              </option>
            ))}
          </select>
        </div>

        <Input
          label={t.modals.amountLabel}
          placeholder={t.modals.amountPlaceholder}
          inputMode="decimal"
          leftAddon={<IndianRupee className="w-4 h-4" />}
          value={amountInput}
          onChange={(e) => {
            setAmountInput(e.target.value);
            setOverpaymentConfirmed(false);
          }}
          required
        />

        <Input
          label={t.modals.descLabel}
          placeholder={
            type === 'CREDIT'
              ? t.modals.descCreditPlaceholder
              : t.modals.descRepayPlaceholder
          }
          value={description}
          onChange={(e) => setDescription(e.target.value)}
        />

        <div className="space-y-1.5">
          <label className="block text-xs font-medium text-[#172554]">
            {t.modals.dateLabel}
          </label>
          <input
            type="datetime-local"
            value={dateInput}
            onChange={(e) => setDateInput(e.target.value)}
            className="w-full min-h-[46px] rounded-xl bg-white border border-slate-200 px-3.5 text-sm text-[#172554] focus:outline-none focus:border-[#2563EB] focus:ring-2 focus:ring-[#DBEAFE] tabular-nums"
          />
        </div>

        {selectedSummary && (
          <div className="rounded-xl bg-[#F5F8FF] border border-slate-200 p-3.5 flex items-center justify-between text-xs">
            <div>
              <span className="text-[#64748B]">{t.modals.prevBal}</span>
              <p className="text-sm font-mono font-semibold text-[#172554] tabular-nums mt-0.5">
                {formatINR(currentBalance)}
              </p>
            </div>
            <div className="text-right">
              <span className="text-[#64748B]">{t.modals.newBal}</span>
              <p
                className={`text-sm font-mono font-bold tabular-nums mt-0.5 ${
                  newBalance > 0
                    ? 'text-orange-600'
                    : newBalance < 0
                    ? 'text-green-600'
                    : 'text-[#2563EB]'
                }`}
              >
                {formatINR(newBalance)}
              </p>
            </div>
          </div>
        )}

        {isOverpayment && (
          <div className="rounded-xl bg-amber-50 border border-amber-200 p-3.5 space-y-2">
            <div className="flex items-start gap-2 text-xs text-amber-800">
              <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5 text-amber-600" />
              <span>
                {t.modals.overpaymentMsg(
                  formatINR(parsedPaise!),
                  formatINR(Math.max(0, currentBalance)),
                  formatINR(Math.abs(newBalance))
                )}
              </span>
            </div>
            <label className="flex items-center gap-2 text-xs text-[#172554] cursor-pointer">
              <input
                type="checkbox"
                checked={overpaymentConfirmed}
                onChange={(e) => setOverpaymentConfirmed(e.target.checked)}
                className="rounded border-slate-300 bg-white text-[#2563EB] focus:ring-[#2563EB]"
              />
              <span>{t.modals.overpaymentAck}</span>
            </label>
          </div>
        )}

        {error && (
          <div className="rounded-xl bg-orange-50 border border-orange-200 px-3.5 py-2.5 text-xs text-orange-700">
            {error}
          </div>
        )}

        <div className="flex items-center justify-end gap-3 pt-2">
          <Button variant="ghost" onClick={onClose}>
            {t.common.cancel}
          </Button>
          <Button
            type="submit"
            leftIcon={<CheckCircle2 className="w-4 h-4" />}
          >
            {type === 'CREDIT' ? t.modals.saveCreditBtn : t.modals.saveRepayBtn}
          </Button>
        </div>
      </form>
    </Modal>
  );
};
