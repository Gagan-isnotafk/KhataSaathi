import React from 'react';

interface LogoMarkProps {
  className?: string;
}

export const LogoMark: React.FC<LogoMarkProps> = ({ className = 'w-9 h-9' }) => {
  return (
    <svg
      viewBox="0 0 40 40"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      aria-hidden="true"
    >
      <rect width="40" height="40" rx="11" fill="#2563EB" />
      <path
        d="M12 11.5C12 10.6716 12.6716 10 13.5 10H22.5C25.5376 10 28 12.4624 28 15.5V28.5C28 29.3284 27.3284 30 26.5 30H13.5C12.6716 30 12 29.3284 12 28.5V11.5Z"
        stroke="#FFFFFF"
        strokeWidth="2.2"
      />
      <path
        d="M17 16.5V23.5M20 14.5V25.5M23 18V22"
        stroke="#FFFFFF"
        strokeWidth="2.3"
        strokeLinecap="round"
      />
    </svg>
  );
};
