import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  CheckCircle2,
  Download,
  LogOut,
  MapPin,
  Phone,
  RotateCcw,
  Shield,
  Store,
  User,
  Volume2,
} from 'lucide-react';
import { Button } from '@/src/components/Button';
import { Input } from '@/src/components/Input';
import { Modal } from '@/src/components/Modal';
import { useApp } from '@/src/context/AppContext';
import { LanguageCode, ShopCategory } from '@/src/types';
import { formatDateTime } from '@/src/utils/date';
import { LANGUAGE_OPTIONS } from '@/src/utils/i18n';

const CATEGORIES: ShopCategory[] = [
  'Kirana & Grocery',
  'Wholesale & Distributors',
  'Hardware & Electrical',
  'Pharmacy & Medical',
  'Stationery & Books',
  'Textiles & Apparel',
  'Other',
];

export const SettingsPage: React.FC = () => {
  const { shop, user, auditLogs, t, setLanguage, updateShop, resetDemoData, logout } = useApp();
  const navigate = useNavigate();

  const [shopName, setShopName] = useState(shop.name);
  const [ownerName, setOwnerName] = useState(shop.ownerName);
  const [category, setCategory] = useState<ShopCategory>(shop.category);
  const [address, setAddress] = useState(shop.address || '');
  const [language, setLocalLanguage] = useState<LanguageCode>(shop.language);
  const [voiceEnabled, setVoiceEnabled] = useState(shop.voiceFeedbackEnabled);
  const [saveFeedback, setSaveFeedback] = useState<string | null>(null);
  const [saveError, setSaveError] = useState<string | null>(null);
  const [resetModalOpen, setResetModalOpen] = useState(false);

  useEffect(() => {
    setLocalLanguage(shop.language);
  }, [shop.language]);

  const handleLanguageChange = (code: LanguageCode) => {
    setLocalLanguage(code);
    setLanguage(code);
    setSaveFeedback(null);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    setSaveFeedback(null);
    setSaveError(null);

    const res = updateShop({
      name: shopName.trim(),
      ownerName: ownerName.trim(),
      category,
      address: address.trim() || undefined,
      language,
      voiceFeedbackEnabled: voiceEnabled,
    });

    if (!res.ok) {
      setSaveError(res.error || t.errors.couldNotSaveSettings);
      return;
    }

    setSaveFeedback(t.settings.savedFeedback);
  };

  const handleLogout = () => {
    logout();
    navigate('/login', { replace: true });
  };

  const handleResetDemo = () => {
    resetDemoData();
    setResetModalOpen(false);
    navigate('/dashboard');
  };

  return (
    <div className="space-y-4 pb-2">
      <form
        onSubmit={handleSave}
        className="rounded-2xl bg-white border border-slate-200/80 shadow-[0_2px_10px_rgba(37,99,235,0.04)] p-4 space-y-3.5"
      >
        <div className="flex items-center justify-between border-b border-slate-100 pb-2.5">
          <h3 className="text-sm font-display font-semibold text-[#172554]">
            {t.settings.shopProfileTitle}
          </h3>
          <span className="text-[11px] text-[#64748B] font-mono tabular-nums flex items-center gap-1">
            <Phone className="w-3 h-3 text-[#2563EB]" />
            {user.phone}
          </span>
        </div>

        <div className="space-y-1.5">
          <label className="block text-xs font-medium text-[#172554]">
            {t.settings.languageLabel}
          </label>
          <div className="grid grid-cols-3 gap-2">
            {LANGUAGE_OPTIONS.map((l) => (
              <button
                key={l.code}
                type="button"
                onClick={() => handleLanguageChange(l.code)}
                className={`min-h-[40px] rounded-xl text-xs font-semibold border cursor-pointer transition-colors ${
                  language === l.code
                    ? 'bg-[#DBEAFE] text-[#2563EB] border-[#2563EB]/40'
                    : 'bg-[#F5F8FF] text-[#64748B] border-slate-200 hover:text-[#172554]'
                }`}
              >
                {l.nativeLabel}
              </button>
            ))}
          </div>
        </div>

        <Input
          label={t.settings.shopNameLabel}
          leftAddon={<Store className="w-4 h-4" />}
          value={shopName}
          onChange={(e) => setShopName(e.target.value)}
          required
        />

        <Input
          label={t.settings.ownerNameLabel}
          leftAddon={<User className="w-4 h-4" />}
          value={ownerName}
          onChange={(e) => setOwnerName(e.target.value)}
          required
        />

        <div className="space-y-1.5">
          <label className="block text-xs font-medium text-[#172554]">
            {t.settings.categoryLabel}
          </label>
          <select
            value={category}
            onChange={(e) => setCategory(e.target.value as ShopCategory)}
            className="w-full min-h-[44px] rounded-xl bg-white border border-slate-200 px-3 text-sm text-[#172554] focus:outline-none focus:border-[#2563EB] focus:ring-2 focus:ring-[#DBEAFE]"
          >
            {CATEGORIES.map((c) => (
              <option key={c} value={c}>
                {t.categories[c]}
              </option>
            ))}
          </select>
        </div>

        <Input
          label={t.settings.addressLabel}
          leftAddon={<MapPin className="w-4 h-4" />}
          value={address}
          onChange={(e) => setAddress(e.target.value)}
        />

        <label className="flex items-center justify-between rounded-xl bg-[#F5F8FF] border border-slate-200 p-3.5 cursor-pointer">
          <div className="flex items-center gap-2.5 pr-3">
            <Volume2 className="w-4 h-4 text-[#2563EB] shrink-0" />
            <div>
              <p className="text-xs font-semibold text-[#172554]">
                {t.settings.spokenRepliesTitle}
              </p>
              <p className="text-[11px] text-[#64748B]">{t.settings.spokenRepliesDesc}</p>
            </div>
          </div>
          <input
            type="checkbox"
            checked={voiceEnabled}
            onChange={(e) => setVoiceEnabled(e.target.checked)}
            className="w-5 h-5 rounded border-slate-300 bg-white text-[#2563EB] focus:ring-[#2563EB]"
          />
        </label>

        {saveError && (
          <div className="rounded-xl bg-orange-50 border border-orange-200 px-3 py-2 text-xs text-orange-700">
            {saveError}
          </div>
        )}
        {saveFeedback && (
          <div className="rounded-xl bg-green-50 border border-green-200 px-3 py-2 text-xs text-green-700 flex items-center gap-1.5">
            <CheckCircle2 className="w-4 h-4 text-green-600" />
            <span>{saveFeedback}</span>
          </div>
        )}

        <Button type="submit" className="w-full">
          {t.settings.saveSettingsBtn}
        </Button>
      </form>

      <div className="rounded-2xl bg-white border border-slate-200/80 shadow-[0_2px_10px_rgba(37,99,235,0.04)] p-4 space-y-3">
        <div className="flex items-center gap-2">
          <Shield className="w-4 h-4 text-[#2563EB]" />
          <h3 className="text-sm font-display font-semibold text-[#172554]">
            {t.settings.auditTrailTitle}
          </h3>
        </div>
        <div className="divide-y divide-slate-100 max-h-48 overflow-y-auto">
          {auditLogs.slice(0, 8).map((log) => (
            <div key={log.id} className="py-2 flex items-center justify-between gap-3 text-xs">
              <p className="text-[#172554] truncate">{log.summary}</p>
              <span className="text-[11px] text-[#64748B] shrink-0 tabular-nums">
                {formatDateTime(log.createdAt, shop.language)}
              </span>
            </div>
          ))}
        </div>
      </div>

      <div className="rounded-2xl bg-white border border-slate-200/80 shadow-[0_2px_10px_rgba(37,99,235,0.04)] p-4 space-y-2.5">
        <a
          href="/KhataSaathi_Frontend.zip"
          download="KhataSaathi_Frontend.zip"
          className="w-full min-h-[44px] rounded-xl bg-[#F5F8FF] border border-slate-200 hover:border-[#2563EB]/40 text-[#172554] text-xs font-semibold flex items-center justify-center gap-2 transition-colors"
        >
          <Download className="w-4 h-4 text-[#2563EB]" />
          <span>{t.settings.downloadZip}</span>
        </a>

        <div className="grid grid-cols-2 gap-2.5">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setResetModalOpen(true)}
            leftIcon={<RotateCcw className="w-3.5 h-3.5" />}
          >
            {t.settings.resetDemoBtn}
          </Button>
          <Button
            variant="danger"
            size="sm"
            onClick={handleLogout}
            leftIcon={<LogOut className="w-3.5 h-3.5" />}
          >
            {t.settings.logoutBtn}
          </Button>
        </div>
      </div>

      <Modal
        isOpen={resetModalOpen}
        onClose={() => setResetModalOpen(false)}
        title={t.settings.resetModalTitle}
        subtitle={t.settings.resetModalSubtitle}
      >
        <div className="space-y-4">
          <p className="text-xs text-[#64748B] leading-relaxed">
            {t.settings.resetModalDesc}
          </p>
          <div className="grid grid-cols-2 gap-2.5">
            <Button variant="ghost" onClick={() => setResetModalOpen(false)}>
              {t.common.cancel}
            </Button>
            <Button variant="danger" onClick={handleResetDemo}>
              {t.settings.confirmResetBtn}
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
};
