import React, { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ChevronRight, Download, Mic, PenLine } from 'lucide-react';
import {
  Bar,
  BarChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
} from 'recharts';
import { Button } from '@/src/components/Button';
import { StatCard } from '@/src/components/StatCard';
import { useApp } from '@/src/context/AppContext';
import {
  exportTransactionsToCsv,
  generatePeriodReport,
} from '@/src/services/mock/reportService';
import { ReportPeriod } from '@/src/types';
import { formatINR } from '@/src/utils/currency';

export const ReportsPage: React.FC = () => {
  const { customers, transactions, shop, t } = useApp();
  const navigate = useNavigate();

  const [period, setPeriod] = useState<ReportPeriod>('WEEKLY');

  const report = useMemo(
    () => generatePeriodReport(period, customers, transactions, shop.language),
    [period, customers, transactions, shop.language]
  );

  const handleDownloadCsv = () => {
    const csv = exportTransactionsToCsv(customers, transactions);
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${shop.name.toLowerCase().replace(/[^a-z0-9]+/g, '_')}_khata_ledger.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-4 pb-2">
      <div className="flex items-center justify-between gap-2">
        <div className="flex-1 grid grid-cols-3 gap-1 p-1 rounded-xl bg-white border border-slate-200/80 shadow-[0_2px_8px_rgba(37,99,235,0.04)]">
          {(
            [
              { id: 'DAILY', label: t.reports.periods.daily },
              { id: 'WEEKLY', label: t.reports.periods.weekly },
              { id: 'MONTHLY', label: t.reports.periods.monthly },
            ] as const
          ).map((p) => (
            <button
              key={p.id}
              type="button"
              onClick={() => setPeriod(p.id)}
              className={`min-h-[36px] rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
                period === p.id
                  ? 'bg-[#2563EB] text-white shadow-[0_2px_8px_rgba(37,99,235,0.22)]'
                  : 'text-[#64748B] hover:text-[#172554]'
              }`}
            >
              {p.label}
            </button>
          ))}
        </div>

        <Button
          size="sm"
          variant="secondary"
          onClick={handleDownloadCsv}
          leftIcon={<Download className="w-3.5 h-3.5 text-[#2563EB]" />}
        >
          {t.reports.csvBtn}
        </Button>
      </div>

      <div className="grid grid-cols-2 gap-2.5">
        <StatCard
          label={t.reports.creditGiven}
          value={formatINR(report.totalCreditPaise)}
          sublabel={t.common.entriesCount(report.transactionCount)}
          tone="orange"
        />
        <StatCard
          label={t.reports.repayments}
          value={formatINR(report.totalRepaymentPaise)}
          sublabel={t.reports.collectedSub}
          tone="green"
        />
        <StatCard
          label={t.reports.netChange}
          value={formatINR(report.netChangePaise, { showSign: true })}
          tone={report.netChangePaise > 0 ? 'amber' : 'green'}
        />
        <StatCard
          label={t.reports.totalDue}
          value={formatINR(report.totalOutstandingPaise)}
          sublabel={t.reports.partiesDueSub(report.topDebtors.length)}
          tone="blue"
        />
      </div>

      <div className="rounded-2xl bg-white border border-slate-200/80 shadow-[0_2px_10px_rgba(37,99,235,0.04)] p-4 space-y-2.5">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-display font-semibold text-[#172554]">
            {t.reports.chartTitle}
          </h3>
          <div className="flex items-center gap-3 text-[11px] text-[#64748B]">
            <span className="inline-flex items-center gap-1">
              <span className="w-2 h-2 rounded-xs bg-orange-500" />
              {t.reports.creditLegend}
            </span>
            <span className="inline-flex items-center gap-1">
              <span className="w-2 h-2 rounded-xs bg-green-600" />
              {t.reports.paidLegend}
            </span>
          </div>
        </div>

        <div className="h-[175px] w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={report.chartSeries} margin={{ top: 6, right: 0, left: 0, bottom: 0 }}>
              <XAxis
                dataKey="label"
                tick={{ fill: '#64748B', fontSize: 10 }}
                axisLine={false}
                tickLine={false}
              />
              <Tooltip
                cursor={{ fill: 'rgba(37, 99, 235, 0.05)' }}
                contentStyle={{
                  backgroundColor: '#FFFFFF',
                  borderColor: '#CBD5E1',
                  borderRadius: '10px',
                  fontSize: '11px',
                  color: '#172554',
                  boxShadow: '0 4px 12px rgba(37, 99, 235, 0.1)',
                }}
                formatter={(value: unknown, name: unknown) => [
                  `₹${Number(value || 0).toLocaleString('en-IN')}`,
                  name === 'creditRupees' ? t.reports.tooltipCredit : t.reports.tooltipRepayment,
                ]}
              />
              <Bar dataKey="creditRupees" fill="#F97316" radius={[4, 4, 0, 0]} maxBarSize={20} />
              <Bar dataKey="repaymentRupees" fill="#16A34A" radius={[4, 4, 0, 0]} maxBarSize={20} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="rounded-2xl bg-white border border-slate-200/80 shadow-[0_2px_10px_rgba(37,99,235,0.04)] p-4 grid grid-cols-2 gap-3 text-xs">
        <div className="flex items-center justify-between">
          <span className="inline-flex items-center gap-1.5 text-[#172554] font-medium">
            <Mic className="w-3.5 h-3.5 text-[#2563EB]" />
            {t.reports.voiceEntries}
          </span>
          <span className="font-mono font-bold text-[#2563EB] tabular-nums">
            {report.voiceCount}
          </span>
        </div>
        <div className="flex items-center justify-between">
          <span className="inline-flex items-center gap-1.5 text-[#172554] font-medium">
            <PenLine className="w-3.5 h-3.5 text-[#64748B]" />
            {t.reports.manualEntries}
          </span>
          <span className="font-mono font-bold text-[#172554] tabular-nums">
            {report.manualCount}
          </span>
        </div>
      </div>

      <div className="rounded-2xl bg-white border border-slate-200/80 shadow-[0_2px_10px_rgba(37,99,235,0.04)] overflow-hidden">
        <div className="px-4 py-3 border-b border-slate-100">
          <h3 className="text-sm font-display font-semibold text-[#172554]">
            {t.reports.highestOutstanding}
          </h3>
        </div>

        <div className="divide-y divide-slate-100">
          {report.topDebtors.length === 0 ? (
            <p className="p-6 text-center text-xs text-[#64748B]">
              {t.reports.allSettled}
            </p>
          ) : (
            report.topDebtors.map((s) => (
              <button
                key={s.customer.id}
                type="button"
                onClick={() => navigate(`/customers/${s.customer.id}`)}
                className="w-full p-3.5 flex items-center justify-between gap-3 text-left active:bg-[#F5F8FF] cursor-pointer"
              >
                <div className="min-w-0">
                  <p className="text-sm font-semibold text-[#172554] truncate">
                    {s.customer.name}
                  </p>
                  <p className="text-[11px] text-[#64748B] mt-0.5 tabular-nums">
                    {t.reports.creditSummary(
                      formatINR(s.totalCreditPaise),
                      formatINR(s.totalRepaymentPaise)
                    )}
                  </p>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <span className="text-sm font-mono font-bold text-orange-600 tabular-nums">
                    {formatINR(s.currentBalancePaise)}
                  </span>
                  <ChevronRight className="w-4 h-4 text-slate-400" />
                </div>
              </button>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
