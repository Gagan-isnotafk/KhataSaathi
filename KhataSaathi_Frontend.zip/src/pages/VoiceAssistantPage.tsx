import React, { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  AlertCircle,
  AlertTriangle,
  CheckCircle2,
  Edit3,
  Info,
  RefreshCw,
  RotateCcw,
  Sparkles,
  UserCheck,
  UserPlus,
  Volume2,
  VolumeX,
} from 'lucide-react';
import { Button } from '@/src/components/Button';
import { MicrophoneButton } from '@/src/components/MicrophoneButton';
import { useApp } from '@/src/context/AppContext';
import { useSpeechSynthesis } from '@/src/hooks/useSpeechSynthesis';
import { useVoiceRecorder } from '@/src/hooks/useVoiceRecorder';
import { computeCustomerLedger } from '@/src/services/mock/ledgerEngine';
import {
  interpretVoiceTranscript,
  simulateSpeechToText,
  VOICE_SAMPLE_PROMPTS,
  VoicePresetSample,
} from '@/src/services/mock/voiceAiService';
import { ParsedVoiceCommand, Transaction, VoiceState } from '@/src/types';
import { formatINR, paiseToInputString, parseRupeesToPaise } from '@/src/utils/currency';
import { formatDateTime, formatDuration } from '@/src/utils/date';
import { generateIdempotencyKey } from '@/src/utils/idempotency';

export const VoiceAssistantPage: React.FC = () => {
  const {
    customers,
    transactions,
    customerSummaries,
    dashboardMetrics,
    shop,
    t,
    updateShop,
    recordTransaction,
    addCustomer,
  } = useApp();
  const navigate = useNavigate();

  const recorder = useVoiceRecorder({
    unavailable: t.voice.micUnavailable,
    denied: t.voice.micPermissionDenied,
    notFound: t.voice.micNotFound,
  });
  const tts = useSpeechSynthesis();

  const [voiceState, setVoiceState] = useState<VoiceState>('IDLE');
  const [transcript, setTranscript] = useState('');
  const [isEditingTranscript, setIsEditingTranscript] = useState(false);
  const [parsed, setParsed] = useState<ParsedVoiceCommand | null>(null);

  const [selectedCustomerId, setSelectedCustomerId] = useState<string>('');
  const [editType, setEditType] = useState<'CREDIT' | 'REPAYMENT'>('CREDIT');
  const [editAmountText, setEditAmountText] = useState<string>('');
  const [editDescription, setEditDescription] = useState<string>('');
  const [overpaymentAck, setOverpaymentAck] = useState(false);
  const [idempotencyKey, setIdempotencyKey] = useState(() => generateIdempotencyKey('voice'));
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [savedTransaction, setSavedTransaction] = useState<Transaction | null>(null);
  const [savedMessage, setSavedMessage] = useState<string | null>(null);
  const [simulateFailureMode, setSimulateFailureMode] = useState(false);

  const activeCustomers = useMemo(
    () => customers.filter((c) => c.status === 'ACTIVE'),
    [customers]
  );

  const selectedCustomerSummary = useMemo(
    () => customerSummaries.find((s) => s.customer.id === selectedCustomerId),
    [customerSummaries, selectedCustomerId]
  );

  const selectedCustomerLedger = useMemo(() => {
    if (!selectedCustomerSummary) return null;
    return computeCustomerLedger(selectedCustomerSummary.customer, transactions);
  }, [selectedCustomerSummary, transactions]);

  const speakIfEnabled = (text: string) => {
    if (shop.voiceFeedbackEnabled && tts.isSupported) {
      tts.speak(text, shop.language);
    }
  };

  const resetSession = () => {
    tts.stopSpeaking();
    recorder.clearAudio();
    setVoiceState('IDLE');
    setTranscript('');
    setIsEditingTranscript(false);
    setParsed(null);
    setSelectedCustomerId('');
    setEditAmountText('');
    setEditDescription('');
    setOverpaymentAck(false);
    setErrorMessage(null);
    setSavedTransaction(null);
    setSavedMessage(null);
    setIdempotencyKey(generateIdempotencyKey('voice'));
  };

  const runInterpretationPipeline = (rawText: string) => {
    setErrorMessage(null);
    setSavedTransaction(null);
    setSavedMessage(null);
    setVoiceState('INTERPRETING');

    window.setTimeout(() => {
      if (simulateFailureMode) {
        setVoiceState('FAILED');
        setErrorMessage(t.voice.errSimulatedAi);
        return;
      }

      setVoiceState('VALIDATING');
      const result = interpretVoiceTranscript(rawText, customers, shop.language);
      setParsed(result);
      setIdempotencyKey(generateIdempotencyKey('voice'));
      setOverpaymentAck(false);

      if (result.intent === 'UNKNOWN') {
        setVoiceState('FAILED');
        setErrorMessage(result.clarificationMessage || t.voice.errUnknownCommand);
        speakIfEnabled(t.voice.spokenCommandNotUnderstood);
        return;
      }

      setSelectedCustomerId(result.matchedCustomerId || '');
      setEditType(result.intent === 'RECORD_REPAYMENT' ? 'REPAYMENT' : 'CREDIT');
      setEditAmountText(result.amountPaise ? paiseToInputString(result.amountPaise) : '');
      setEditDescription(result.description);

      if (result.isReadOnly && !result.needsClarification) {
        setVoiceState('SUCCESS');
        if (result.intent === 'DAILY_SUMMARY') {
          const msg = t.voice.msgDailySummary(
            formatINR(dashboardMetrics.todaysCreditPaise),
            formatINR(dashboardMetrics.todaysRepaymentPaise),
            formatINR(dashboardMetrics.totalOutstandingPaise)
          );
          setSavedMessage(msg);
          speakIfEnabled(msg);
        } else if (result.intent === 'TOTAL_OUTSTANDING') {
          const msg = t.voice.msgTotalOutstanding(
            dashboardMetrics.activeCustomerCount,
            formatINR(dashboardMetrics.totalOutstandingPaise)
          );
          setSavedMessage(msg);
          speakIfEnabled(msg);
        } else if (result.intent === 'CHECK_BALANCE' && result.matchedCustomerId) {
          const summary = customerSummaries.find((s) => s.customer.id === result.matchedCustomerId);
          if (summary) {
            const msg = t.voice.msgCustomerBalance(
              summary.customer.name,
              formatINR(summary.currentBalancePaise)
            );
            setSavedMessage(msg);
            speakIfEnabled(msg);
          }
        } else if (result.intent === 'CUSTOMER_HISTORY' && result.matchedCustomerId) {
          const summary = customerSummaries.find((s) => s.customer.id === result.matchedCustomerId);
          if (summary) {
            const msg = t.voice.msgCustomerHistory(
              summary.customer.name,
              formatINR(summary.currentBalancePaise)
            );
            setSavedMessage(msg);
            speakIfEnabled(msg);
          }
        }
        return;
      }

      setVoiceState('WAITING_FOR_CONFIRMATION');
    }, 420);
  };

  const handleStartRecording = async () => {
    resetSession();
    const started = await recorder.startRecording();
    if (started) {
      setVoiceState('RECORDING');
    }
  };

  const handleStopRecording = async () => {
    const secs = await recorder.stopRecording();
    setVoiceState('AUDIO_READY');

    window.setTimeout(() => {
      setVoiceState('TRANSCRIBING');
      window.setTimeout(() => {
        const simulatedText = simulateSpeechToText(secs, shop.language);
        setTranscript(simulatedText);
        setVoiceState('TRANSCRIPT_READY');
        runInterpretationPipeline(simulatedText);
      }, 480);
    }, 220);
  };

  const handleRunSample = (sample: VoicePresetSample) => {
    tts.stopSpeaking();
    setErrorMessage(null);
    setSavedTransaction(null);
    setSavedMessage(null);
    setTranscript(sample.transcript);
    setIsEditingTranscript(false);
    setVoiceState('TRANSCRIBING');

    window.setTimeout(() => {
      setVoiceState('TRANSCRIPT_READY');
      runInterpretationPipeline(sample.transcript);
    }, 280);
  };

  const handleReinterpretTranscript = (e: React.FormEvent) => {
    e.preventDefault();
    if (!transcript.trim()) {
      setErrorMessage(t.voice.errTypeOrRecord);
      return;
    }
    setIsEditingTranscript(false);
    runInterpretationPipeline(transcript);
  };

  const handleSelectCandidate = (custId: string) => {
    setSelectedCustomerId(custId);
    setOverpaymentAck(false);
    if (parsed) {
      const cust = customers.find((c) => c.id === custId);
      setParsed({
        ...parsed,
        matchedCustomerId: custId,
        customerNameQuery: cust?.name || parsed.customerNameQuery,
        needsClarification:
          !parsed.isReadOnly && (!parsed.amountPaise || parsed.amountPaise <= 0),
        clarificationType:
          !parsed.isReadOnly && (!parsed.amountPaise || parsed.amountPaise <= 0)
            ? 'MISSING_AMOUNT'
            : undefined,
      });

      if (parsed.isReadOnly) {
        const summary = customerSummaries.find((s) => s.customer.id === custId);
        if (summary) {
          setVoiceState('SUCCESS');
          const msg = t.voice.msgCustomerBalance(
            summary.customer.name,
            formatINR(summary.currentBalancePaise)
          );
          setSavedMessage(msg);
          speakIfEnabled(msg);
        }
      }
    }
  };

  const editedAmountPaise = parseRupeesToPaise(editAmountText, true);
  const previousBalancePaise = selectedCustomerSummary?.currentBalancePaise ?? 0;
  const proposedNewBalancePaise =
    editedAmountPaise === null
      ? previousBalancePaise
      : editType === 'CREDIT'
      ? previousBalancePaise + editedAmountPaise
      : previousBalancePaise - editedAmountPaise;

  const isOverpayment =
    editType === 'REPAYMENT' &&
    editedAmountPaise !== null &&
    editedAmountPaise > Math.max(0, previousBalancePaise);

  const handleConfirmSave = () => {
    setErrorMessage(null);

    if (parsed?.intent === 'CREATE_CUSTOMER') {
      const nameToCreate = parsed.customerNameQuery?.trim() || '';
      if (nameToCreate.length < 2) {
        setErrorMessage(t.voice.errInvalidCustName);
        return;
      }
      setVoiceState('SAVING');
      window.setTimeout(() => {
        const res = addCustomer({
          name: nameToCreate,
          notes: 'Created via Voice Assistant',
        });
        if (!res.ok || !res.data) {
          setVoiceState('FAILED');
          setErrorMessage(res.error || t.voice.errCreateCustomerFailed);
          return;
        }
        setVoiceState('SUCCESS');
        const msg = t.voice.msgCustomerAdded(res.data.name);
        setSavedMessage(msg);
        speakIfEnabled(msg);
      }, 260);
      return;
    }

    if (!selectedCustomerId || !selectedCustomerSummary) {
      setErrorMessage(t.voice.errSelectCustomer);
      return;
    }

    if (editedAmountPaise === null) {
      setErrorMessage(t.voice.errInvalidAmount);
      return;
    }

    if (isOverpayment && !overpaymentAck) {
      setErrorMessage(t.voice.errConfirmOverpay);
      return;
    }

    setVoiceState('SAVING');
    window.setTimeout(() => {
      if (simulateFailureMode) {
        setVoiceState('FAILED');
        setErrorMessage(t.voice.errSimulatedSave);
        return;
      }

      const res = recordTransaction({
        customerId: selectedCustomerId,
        type: editType,
        amountPaise: editedAmountPaise,
        description: editDescription || (editType === 'CREDIT' ? 'Voice credit' : 'Voice repayment'),
        source: 'VOICE',
        idempotencyKey,
      });

      if (!res.ok || !res.data) {
        setVoiceState('FAILED');
        setErrorMessage(res.error || t.voice.errSaveFailed);
        return;
      }

      setSavedTransaction(res.data);
      setVoiceState('SUCCESS');
      const msg = t.voice.msgSavedEntry(
        formatINR(editedAmountPaise),
        editType,
        selectedCustomerSummary.customer.name,
        formatINR(proposedNewBalancePaise)
      );
      setSavedMessage(msg);
      speakIfEnabled(msg);
    }, 280);
  };

  const candidateCustomers = useMemo(() => {
    if (!parsed || parsed.candidateCustomerIds.length === 0) return [];
    return customerSummaries.filter((s) => parsed.candidateCustomerIds.includes(s.customer.id));
  }, [parsed, customerSummaries]);

  const orderedSamples = useMemo(() => {
    const preferred = VOICE_SAMPLE_PROMPTS.filter((p) => p.language === shop.language);
    const others = VOICE_SAMPLE_PROMPTS.filter((p) => p.language !== shop.language);
    return [...preferred, ...others];
  }, [shop.language]);

  const isBusy =
    voiceState === 'AUDIO_READY' ||
    voiceState === 'TRANSCRIBING' ||
    voiceState === 'INTERPRETING' ||
    voiceState === 'VALIDATING' ||
    voiceState === 'SAVING';

  return (
    <div className="space-y-4 pb-2">
      <div className="flex items-center justify-between gap-2 rounded-xl bg-white border border-slate-200/80 shadow-[0_2px_8px_rgba(37,99,235,0.04)] px-3 py-2 text-[11px]">
        <span className="inline-flex items-center gap-1.5 text-[#172554] font-medium truncate">
          <Info className="w-3.5 h-3.5 text-[#2563EB] shrink-0" />
          <span className="truncate">{t.voice.demoBadge}</span>
        </span>

        <div className="flex items-center gap-1.5 shrink-0">
          <button
            type="button"
            onClick={() => updateShop({ voiceFeedbackEnabled: !shop.voiceFeedbackEnabled })}
            className="min-h-[32px] px-2.5 rounded-lg bg-[#F5F8FF] border border-slate-200 text-[#172554] inline-flex items-center gap-1 cursor-pointer"
          >
            {shop.voiceFeedbackEnabled ? (
              <Volume2 className="w-3.5 h-3.5 text-[#2563EB]" />
            ) : (
              <VolumeX className="w-3.5 h-3.5 text-[#64748B]" />
            )}
            <span>{shop.voiceFeedbackEnabled ? t.voice.voiceOn : t.voice.muted}</span>
          </button>

          <button
            type="button"
            onClick={() => setSimulateFailureMode((v) => !v)}
            className={`min-h-[32px] px-2.5 rounded-lg border inline-flex items-center gap-1 cursor-pointer ${
              simulateFailureMode
                ? 'bg-amber-50 border-amber-300 text-amber-700 font-medium'
                : 'bg-[#F5F8FF] border-slate-200 text-[#64748B]'
            }`}
          >
            <AlertTriangle className="w-3 h-3" />
            <span>{simulateFailureMode ? t.voice.errOn : t.voice.errOff}</span>
          </button>
        </div>
      </div>

      <div className="rounded-3xl bg-white border border-slate-200/80 shadow-[0_6px_24px_rgba(37,99,235,0.08)] px-4 py-6 flex flex-col items-center text-center gap-4">
        <MicrophoneButton
          voiceState={voiceState}
          onStart={handleStartRecording}
          onStop={handleStopRecording}
        />

        <div className="space-y-1">
          <p
            className={`text-base font-display font-bold ${
              voiceState === 'RECORDING' || isBusy ? 'text-[#2563EB]' : 'text-[#172554]'
            }`}
          >
            {voiceState === 'RECORDING'
              ? `${t.voice.states.listening} · ${formatDuration(recorder.durationSeconds)}`
              : voiceState === 'AUDIO_READY'
              ? t.voice.states.processingAudio
              : voiceState === 'TRANSCRIBING'
              ? t.voice.states.transcribing
              : voiceState === 'INTERPRETING' || voiceState === 'VALIDATING'
              ? t.voice.states.extracting
              : voiceState === 'SAVING'
              ? t.voice.states.saving
              : t.voice.states.tapToSpeak}
          </p>
          <p className="text-xs text-[#64748B]">
            {t.voice.subtitle}
          </p>
        </div>

        <div
          className="w-full h-12 rounded-xl bg-[#DBEAFE]/40 border border-[#93C5FD]/50 px-2.5 flex items-center justify-center gap-1"
          aria-hidden="true"
        >
          {recorder.waveformBars.map((height, idx) => (
            <div
              key={idx}
              style={{
                height: `${
                  voiceState === 'RECORDING'
                    ? height
                    : isBusy
                    ? 25 + ((idx * 17) % 55)
                    : 18
                }%`,
              }}
              className={`w-1 rounded-full transition-all duration-100 ${
                voiceState === 'RECORDING'
                  ? 'bg-[#2563EB]'
                  : isBusy
                  ? 'bg-[#60A5FA]'
                  : 'bg-[#93C5FD]/75'
              }`}
            />
          ))}
        </div>

        {recorder.audioUrl && (
          <audio controls src={recorder.audioUrl} className="w-full h-8" />
        )}

        {recorder.micError && (
          <div className="w-full rounded-xl bg-amber-50 border border-amber-200 p-2.5 text-left text-[11px] text-amber-800 flex items-start gap-2">
            <AlertCircle className="w-3.5 h-3.5 text-amber-600 shrink-0 mt-0.5" />
            <span>{recorder.micError}</span>
          </div>
        )}

        <div className="w-full text-left space-y-1.5 pt-1">
          <span className="text-[11px] font-medium text-[#64748B]">
            {t.voice.samplePromptHeading}
          </span>
          <div className="flex gap-2 overflow-x-auto no-scrollbar pb-0.5">
            {orderedSamples.map((sample) => (
              <button
                key={sample.id}
                type="button"
                onClick={() => handleRunSample(sample)}
                className="shrink-0 min-h-[36px] px-3 rounded-xl bg-[#F5F8FF] border border-slate-200 hover:border-[#2563EB]/50 hover:bg-[#DBEAFE]/50 text-xs font-medium text-[#172554] whitespace-nowrap cursor-pointer transition-colors"
              >
                {t.voice.sampleLabels[sample.id]?.label || sample.transcript}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="rounded-2xl bg-white border border-slate-200/80 shadow-[0_2px_10px_rgba(37,99,235,0.04)] p-4 space-y-2.5">
        <div className="flex items-center justify-between">
          <span className="text-xs font-semibold text-[#172554]">{t.voice.transcriptTitle}</span>
          <div className="flex items-center gap-3">
            {transcript && (
              <button
                type="button"
                onClick={() => setIsEditingTranscript((v) => !v)}
                className="text-xs font-medium text-[#2563EB] inline-flex items-center gap-1 cursor-pointer"
              >
                <Edit3 className="w-3 h-3" />
                <span>{isEditingTranscript ? t.common.cancel : t.common.edit}</span>
              </button>
            )}
            {(transcript || parsed) && (
              <button
                type="button"
                onClick={resetSession}
                className="text-xs text-[#64748B] hover:text-[#172554] inline-flex items-center gap-1 cursor-pointer"
              >
                <RotateCcw className="w-3 h-3" />
                <span>{t.common.reset}</span>
              </button>
            )}
          </div>
        </div>

        {isEditingTranscript || !transcript ? (
          <form onSubmit={handleReinterpretTranscript} className="space-y-2.5">
            <textarea
              rows={2}
              value={transcript}
              onChange={(e) => setTranscript(e.target.value)}
              placeholder={t.voice.transcriptPlaceholder}
              className="w-full rounded-xl bg-[#F5F8FF] border border-slate-200 focus:border-[#2563EB] focus:ring-2 focus:ring-[#DBEAFE] p-3 text-sm text-[#172554] placeholder:text-slate-400 focus:outline-none"
            />
            <Button
              type="submit"
              size="sm"
              className="w-full"
              leftIcon={<Sparkles className="w-3.5 h-3.5" />}
            >
              {t.voice.interpretBtn}
            </Button>
          </form>
        ) : (
          <div className="rounded-xl bg-[#F5F8FF] border border-slate-200 p-3 text-sm text-[#172554] font-medium">
            “{transcript}”
          </div>
        )}
      </div>

      {voiceState === 'FAILED' && errorMessage && (
        <div className="rounded-2xl bg-orange-50 border border-orange-200 p-4 space-y-3">
          <div className="flex items-start gap-2.5">
            <AlertCircle className="w-5 h-5 text-orange-600 shrink-0 mt-0.5" />
            <div className="space-y-0.5">
              <h4 className="text-sm font-semibold text-orange-800">{t.voice.notSaved}</h4>
              <p className="text-xs text-orange-700 leading-relaxed">{errorMessage}</p>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <Button
              size="sm"
              variant="secondary"
              onClick={() => setIsEditingTranscript(true)}
            >
              {t.voice.editText}
            </Button>
            <Button
              size="sm"
              variant="outline"
              onClick={resetSession}
              leftIcon={<RefreshCw className="w-3.5 h-3.5" />}
            >
              {t.common.retry}
            </Button>
          </div>
        </div>
      )}

      {voiceState === 'WAITING_FOR_CONFIRMATION' &&
        parsed?.clarificationType === 'DUPLICATE_CUSTOMER' &&
        !selectedCustomerId && (
          <div className="rounded-2xl bg-amber-50 border border-amber-200 p-4 space-y-3">
            <div className="flex items-start gap-2.5">
              <UserCheck className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
              <div>
                <h4 className="text-sm font-semibold text-amber-900">
                  {t.voice.selectCustomerTitle(candidateCustomers.length)}
                </h4>
                <p className="text-xs text-amber-800 mt-0.5">{parsed.clarificationMessage}</p>
              </div>
            </div>

            <div className="space-y-2">
              {candidateCustomers.map((s) => (
                <button
                  key={s.customer.id}
                  type="button"
                  onClick={() => handleSelectCandidate(s.customer.id)}
                  className="w-full rounded-xl bg-white border border-amber-200 hover:border-[#2563EB] p-3 flex items-center justify-between text-left cursor-pointer"
                >
                  <div>
                    <p className="text-sm font-semibold text-[#172554]">{s.customer.name}</p>
                    <p className="text-xs text-[#64748B]">{s.customer.phone || t.common.noPhone}</p>
                  </div>
                  <span className="text-sm font-mono font-bold text-orange-600 tabular-nums">
                    {formatINR(s.currentBalancePaise)}
                  </span>
                </button>
              ))}
            </div>
          </div>
        )}

      {(voiceState === 'WAITING_FOR_CONFIRMATION' || voiceState === 'SAVING') &&
        parsed?.intent === 'CREATE_CUSTOMER' && (
          <div className="rounded-2xl bg-white border border-[#93C5FD] shadow-[0_4px_16px_rgba(37,99,235,0.08)] p-4 space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-[11px] font-semibold text-[#2563EB]">
                  {t.voice.confirmNewCustomer}
                </span>
                <h4 className="text-base font-display font-bold text-[#172554] mt-0.5">
                  {parsed.customerNameQuery}
                </h4>
              </div>
              <UserPlus className="w-5 h-5 text-[#2563EB]" />
            </div>

            <div className="grid grid-cols-2 gap-2.5">
              <Button variant="ghost" size="sm" onClick={resetSession}>
                {t.common.cancel}
              </Button>
              <Button
                size="sm"
                onClick={handleConfirmSave}
                isLoading={voiceState === 'SAVING'}
              >
                {t.voice.confirmAdd}
              </Button>
            </div>
          </div>
        )}

      {(voiceState === 'WAITING_FOR_CONFIRMATION' || voiceState === 'SAVING') &&
        parsed &&
        !parsed.isReadOnly &&
        parsed.intent !== 'CREATE_CUSTOMER' &&
        (selectedCustomerId || parsed.clarificationType === 'MISSING_CUSTOMER') && (
          <div className="rounded-2xl bg-white border border-[#93C5FD] shadow-[0_4px_18px_rgba(37,99,235,0.08)] p-4 space-y-3.5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-[#2563EB]">
                {t.voice.confirmEntryTitle}
              </span>
              <span className="text-[11px] font-semibold text-[#64748B]">
                {editType === 'CREDIT' ? t.labels.credit : t.labels.repayment}
              </span>
            </div>

            <div className="space-y-3">
              <select
                value={selectedCustomerId}
                onChange={(e) => {
                  setSelectedCustomerId(e.target.value);
                  setOverpaymentAck(false);
                }}
                aria-label={t.voice.selectCustomerPlaceholder}
                className="w-full min-h-[44px] rounded-xl bg-[#F5F8FF] border border-slate-200 px-3 text-sm text-[#172554] focus:outline-none focus:border-[#2563EB]"
              >
                <option value="">{t.voice.selectCustomerPlaceholder}</option>
                {activeCustomers.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>

              <div className="grid grid-cols-2 gap-1.5 p-1 rounded-xl bg-[#F5F8FF] border border-slate-200">
                <button
                  type="button"
                  onClick={() => {
                    setEditType('CREDIT');
                    setOverpaymentAck(false);
                  }}
                  className={`min-h-[38px] rounded-lg text-xs font-semibold cursor-pointer ${
                    editType === 'CREDIT'
                      ? 'bg-orange-50 text-orange-700 border border-orange-200 shadow-xs'
                      : 'text-[#64748B]'
                  }`}
                >
                  {t.voice.creditToggle}
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setEditType('REPAYMENT');
                    setOverpaymentAck(false);
                  }}
                  className={`min-h-[38px] rounded-lg text-xs font-semibold cursor-pointer ${
                    editType === 'REPAYMENT'
                      ? 'bg-green-50 text-green-700 border border-green-200 shadow-xs'
                      : 'text-[#64748B]'
                  }`}
                >
                  {t.voice.repaymentToggle}
                </button>
              </div>

              <div className="grid grid-cols-2 gap-2.5">
                <div>
                  <label className="block text-[11px] font-medium text-[#64748B] mb-1">
                    {t.voice.amountLabel}
                  </label>
                  <input
                    type="text"
                    inputMode="decimal"
                    value={editAmountText}
                    onChange={(e) => {
                      setEditAmountText(e.target.value);
                      setOverpaymentAck(false);
                    }}
                    className="w-full min-h-[44px] rounded-xl bg-[#F5F8FF] border border-slate-200 focus:border-[#2563EB] px-3 text-base font-mono font-bold text-[#172554] tabular-nums focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-medium text-[#64748B] mb-1">
                    {t.voice.notesLabel}
                  </label>
                  <input
                    type="text"
                    value={editDescription}
                    onChange={(e) => setEditDescription(e.target.value)}
                    className="w-full min-h-[44px] rounded-xl bg-[#F5F8FF] border border-slate-200 focus:border-[#2563EB] px-3 text-xs text-[#172554] focus:outline-none"
                  />
                </div>
              </div>
            </div>

            {selectedCustomerSummary && (
              <div className="rounded-xl bg-[#F5F8FF] border border-slate-200 p-3 grid grid-cols-3 gap-2 text-xs">
                <div>
                  <span className="text-[10px] text-[#64748B]">{t.voice.prevBal}</span>
                  <p className="font-mono font-semibold text-[#172554] tabular-nums mt-0.5">
                    {formatINR(previousBalancePaise)}
                  </p>
                </div>
                <div>
                  <span className="text-[10px] text-[#64748B]">
                    {editType === 'CREDIT' ? t.voice.plusCredit : t.voice.minusPaid}
                  </span>
                  <p
                    className={`font-mono font-semibold tabular-nums mt-0.5 ${
                      editType === 'CREDIT' ? 'text-orange-600' : 'text-green-600'
                    }`}
                  >
                    {editedAmountPaise !== null ? formatINR(editedAmountPaise) : '—'}
                  </p>
                </div>
                <div className="text-right">
                  <span className="text-[10px] text-[#64748B]">{t.voice.newBal}</span>
                  <p className="font-mono font-bold text-[#2563EB] tabular-nums mt-0.5">
                    {formatINR(proposedNewBalancePaise)}
                  </p>
                </div>
              </div>
            )}

            {isOverpayment && (
              <label className="flex items-center gap-2 rounded-xl bg-amber-50 border border-amber-200 p-3 text-xs text-amber-800 cursor-pointer">
                <input
                  type="checkbox"
                  checked={overpaymentAck}
                  onChange={(e) => setOverpaymentAck(e.target.checked)}
                  className="rounded border-slate-300 bg-white text-[#2563EB]"
                />
                <span>{t.voice.advanceAck}</span>
              </label>
            )}

            {errorMessage && (
              <div className="rounded-xl bg-orange-50 border border-orange-200 px-3 py-2 text-xs text-orange-700">
                {errorMessage}
              </div>
            )}

            <div className="grid grid-cols-2 gap-2.5 pt-1">
              <Button variant="ghost" onClick={resetSession}>
                {t.common.discard}
              </Button>
              <Button
                onClick={handleConfirmSave}
                isLoading={voiceState === 'SAVING'}
                leftIcon={<CheckCircle2 className="w-4 h-4" />}
              >
                {t.common.confirmAndSave}
              </Button>
            </div>
          </div>
        )}

      {voiceState === 'SUCCESS' && savedMessage && (
        <div className="rounded-2xl bg-[#DBEAFE]/50 border border-[#93C5FD] p-4 space-y-3">
          <div className="flex items-start gap-2.5">
            <CheckCircle2 className="w-5 h-5 text-[#2563EB] shrink-0 mt-0.5" />
            <div>
              <h4 className="text-sm font-semibold text-[#172554]">
                {parsed?.isReadOnly ? t.voice.answerTitle : t.voice.savedTitle}
              </h4>
              <p className="text-xs text-[#172554] leading-relaxed mt-0.5">{savedMessage}</p>
            </div>
          </div>

          {parsed?.intent === 'CUSTOMER_HISTORY' &&
            selectedCustomerLedger &&
            selectedCustomerLedger.entries.length > 0 && (
              <div className="rounded-xl bg-white border border-slate-200 divide-y divide-slate-100">
                {selectedCustomerLedger.entries
                  .slice(-3)
                  .reverse()
                  .map((entry) => (
                    <div
                      key={entry.transaction.id}
                      className="p-2.5 flex items-center justify-between text-xs"
                    >
                      <div className="min-w-0 pr-2">
                        <p className="text-[#172554] font-medium truncate">
                          {entry.transaction.description}
                        </p>
                        <p className="text-[11px] text-[#64748B]">
                          {formatDateTime(entry.transaction.occurredAt, shop.language)}
                        </p>
                      </div>
                      <span className="font-mono font-semibold text-[#2563EB] tabular-nums shrink-0">
                        {formatINR(entry.transaction.amountPaise)}
                      </span>
                    </div>
                  ))}
              </div>
            )}

          <div className="grid grid-cols-2 gap-2">
            {selectedCustomerId ? (
              <Button
                size="sm"
                variant="secondary"
                onClick={() => navigate(`/customers/${selectedCustomerId}`)}
              >
                {t.voice.openLedger}
              </Button>
            ) : (
              <Button
                size="sm"
                variant="secondary"
                onClick={() => navigate(savedTransaction ? '/transactions' : '/dashboard')}
              >
                {savedTransaction ? t.voice.transactionsBtn : t.voice.dashboardBtn}
              </Button>
            )}
            <Button size="sm" onClick={resetSession}>
              {t.voice.speakAgain}
            </Button>
          </div>
        </div>
      )}
    </div>
  );
};
