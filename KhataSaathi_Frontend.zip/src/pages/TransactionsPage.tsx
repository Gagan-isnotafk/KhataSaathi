import React, { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  ArrowDownLeft,
  Plus,
  ReceiptIndianRupee,
  RotateCcw,
  Search,
  SlidersHorizontal,
} from 'lucide-react';
import { Button } from '@/src/components/Button';
import { EmptyState } from '@/src/components/EmptyState';
import { Input } from '@/src/components/Input';
import { Modal } from '@/src/components/Modal';
import { TransactionCard } from '@/src/components/TransactionCard';
import { TransactionModal } from '@/src/components/TransactionModal';
import { useApp } from '@/src/context/AppContext';
import { Transaction } from '@/src/types';
import { formatINR, parseRupeesToPaise } from '@/src/utils/currency';
import { isSameLocalDay, isWithinLastDays } from '@/src/utils/date';

type TypeFilter = 'ALL' | 'CREDIT' | 'REPAYMENT' | 'REVERSAL';
type SourceFilter = 'ALL' | 'VOICE' | 'MANUAL';
type DateRangeFilter = 'ALL' | 'TODAY' | '7D' | '30D';

export const TransactionsPage: React.FC = () => {
  const { customers, transactions, t, reverseTransaction } = useApp();
  const navigate = useNavigate();

  const [search, setSearch] = useState('');
  const [customerIdFilter, setCustomerIdFilter] = useState('');
  const [typeFilter, setTypeFilter] = useState<TypeFilter>('ALL');
  const [sourceFilter, setSourceFilter] = useState<SourceFilter>('ALL');
  const [dateFilter, setDateFilter] = useState<DateRangeFilter>('ALL');
  const [minAmount, setMinAmount] = useState('');
  const [maxAmount, setMaxAmount] = useState('');
  const [filtersOpen, setFiltersOpen] = useState(false);

  const [txnModal, setTxnModal] = useState<{ open: boolean; type: 'CREDIT' | 'REPAYMENT' }>({
    open: false,
    type: 'CREDIT',
  });
  const [reverseTarget, setReverseTarget] = useState<Transaction | null>(null);
  const [reverseReason, setReverseReason] = useState('');
  const [reverseError, setReverseError] = useState<string | null>(null);

  const customerMap = useMemo(
    () => new Map(customers.map((c) => [c.id, c.name])),
    [customers]
  );

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    const minPaise = minAmount.trim() ? parseRupeesToPaise(minAmount, false) : null;
    const maxPaise = maxAmount.trim() ? parseRupeesToPaise(maxAmount, false) : null;
    const now = new Date();

    return [...transactions]
      .filter((txn) => {
        if (customerIdFilter && txn.customerId !== customerIdFilter) return false;
        if (typeFilter !== 'ALL' && txn.type !== typeFilter) return false;
        if (sourceFilter !== 'ALL' && txn.source !== sourceFilter) return false;

        if (dateFilter === 'TODAY' && !isSameLocalDay(txn.occurredAt, now)) return false;
        if (dateFilter === '7D' && !isWithinLastDays(txn.occurredAt, 7, now)) return false;
        if (dateFilter === '30D' && !isWithinLastDays(txn.occurredAt, 30, now)) return false;

        if (minPaise !== null && txn.amountPaise < minPaise) return false;
        if (maxPaise !== null && txn.amountPaise > maxPaise) return false;

        if (q) {
          const custName = (customerMap.get(txn.customerId) || '').toLowerCase();
          const desc = txn.description.toLowerCase();
          if (!custName.includes(q) && !desc.includes(q)) return false;
        }
        return true;
      })
      .sort((a, b) => new Date(b.occurredAt).getTime() - new Date(a.occurredAt).getTime());
  }, [
    transactions,
    customerIdFilter,
    typeFilter,
    sourceFilter,
    dateFilter,
    minAmount,
    maxAmount,
    search,
    customerMap,
  ]);

  const totals = useMemo(() => {
    let credit = 0;
    let repayment = 0;
    for (const txn of filtered) {
      if (txn.status !== 'POSTED') continue;
      if (txn.type === 'CREDIT') credit += txn.amountPaise;
      if (txn.type === 'REPAYMENT') repayment += txn.amountPaise;
    }
    return { credit, repayment };
  }, [filtered]);

  const activeFilterCount =
    (customerIdFilter ? 1 : 0) +
    (sourceFilter !== 'ALL' ? 1 : 0) +
    (dateFilter !== 'ALL' ? 1 : 0) +
    (minAmount ? 1 : 0) +
    (maxAmount ? 1 : 0);

  const handleConfirmReverse = (e: React.FormEvent) => {
    e.preventDefault();
    if (!reverseTarget) return;
    setReverseError(null);
    const res = reverseTransaction(reverseTarget.id, reverseReason);
    if (!res.ok) {
      setReverseError(res.error || t.errors.couldNotReverseTxn);
      return;
    }
    setReverseTarget(null);
    setReverseReason('');
  };

  return (
    <div className="space-y-3.5 pb-2">
      <div className="grid grid-cols-2 gap-2.5">
        <Button
          size="sm"
          onClick={() => setTxnModal({ open: true, type: 'CREDIT' })}
          leftIcon={<Plus className="w-4 h-4" />}
        >
          {t.transactions.addCredit}
        </Button>
        <Button
          size="sm"
          variant="secondary"
          onClick={() => setTxnModal({ open: true, type: 'REPAYMENT' })}
          leftIcon={<ArrowDownLeft className="w-4 h-4 text-green-600" />}
        >
          {t.transactions.gotPayment}
        </Button>
      </div>

      <div className="rounded-xl bg-white border border-slate-200/80 shadow-[0_2px_8px_rgba(37,99,235,0.04)] px-3.5 py-2.5 flex items-center justify-between text-xs tabular-nums">
        <span className="text-[#64748B] font-medium">{t.common.entriesCount(filtered.length)}</span>
        <div className="flex items-center gap-3">
          <span className="text-orange-600 font-mono font-semibold">
            +{formatINR(totals.credit)}
          </span>
          <span className="text-green-600 font-mono font-semibold">
            -{formatINR(totals.repayment)}
          </span>
        </div>
      </div>

      <div className="flex items-center gap-2">
        <div className="flex-1">
          <Input
            placeholder={t.transactions.searchPlaceholder}
            leftAddon={<Search className="w-4 h-4" />}
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        <Button
          size="md"
          variant="secondary"
          onClick={() => setFiltersOpen(true)}
          leftIcon={<SlidersHorizontal className="w-4 h-4" />}
        >
          {activeFilterCount > 0
            ? t.transactions.filtersCountBtn(activeFilterCount)
            : t.transactions.filtersBtn}
        </Button>
      </div>

      <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar">
        {(
          [
            { id: 'ALL', label: t.transactions.types.all },
            { id: 'CREDIT', label: t.transactions.types.credit },
            { id: 'REPAYMENT', label: t.transactions.types.repayment },
            { id: 'REVERSAL', label: t.transactions.types.reversal },
          ] as const
        ).map((tab) => (
          <button
            key={tab.id}
            type="button"
            onClick={() => setTypeFilter(tab.id)}
            className={`shrink-0 min-h-[34px] px-3.5 rounded-xl text-xs font-semibold transition-colors cursor-pointer ${
              typeFilter === tab.id
                ? 'bg-[#2563EB] text-white shadow-[0_2px_8px_rgba(37,99,235,0.22)]'
                : 'bg-white border border-slate-200 text-[#64748B] hover:text-[#172554]'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {filtered.length === 0 ? (
        <EmptyState
          icon={<ReceiptIndianRupee className="w-6 h-6" />}
          title={t.transactions.emptyTitle}
          description={t.transactions.emptyDesc}
          actionLabel={t.transactions.addCredit}
          onAction={() => setTxnModal({ open: true, type: 'CREDIT' })}
        />
      ) : (
        <div className="space-y-2">
          {filtered.map((txn) => (
            <TransactionCard
              key={txn.id}
              transaction={txn}
              customerName={customerMap.get(txn.customerId) || t.common.customer}
              onClick={() => navigate(`/customers/${txn.customerId}`)}
              onReverse={(item) => {
                setReverseTarget(item);
                setReverseReason('');
                setReverseError(null);
              }}
            />
          ))}
        </div>
      )}

      <Modal
        isOpen={filtersOpen}
        onClose={() => setFiltersOpen(false)}
        title={t.transactions.filterModalTitle}
      >
        <div className="space-y-3.5">
          <div className="space-y-1.5">
            <label className="block text-xs font-medium text-[#172554]">
              {t.transactions.customerFilterLabel}
            </label>
            <select
              value={customerIdFilter}
              onChange={(e) => setCustomerIdFilter(e.target.value)}
              className="w-full min-h-[44px] rounded-xl bg-white border border-slate-200 px-3 text-sm text-[#172554] focus:outline-none focus:border-[#2563EB]"
            >
              <option value="">{t.transactions.allCustomers}</option>
              {customers.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>

          <div className="space-y-1.5">
            <label className="block text-xs font-medium text-[#172554]">
              {t.transactions.dateRangeLabel}
            </label>
            <select
              value={dateFilter}
              onChange={(e) => setDateFilter(e.target.value as DateRangeFilter)}
              className="w-full min-h-[44px] rounded-xl bg-white border border-slate-200 px-3 text-sm text-[#172554] focus:outline-none focus:border-[#2563EB]"
            >
              <option value="ALL">{t.transactions.dates.all}</option>
              <option value="TODAY">{t.transactions.dates.today}</option>
              <option value="7D">{t.transactions.dates.last7d}</option>
              <option value="30D">{t.transactions.dates.last30d}</option>
            </select>
          </div>

          <div className="space-y-1.5">
            <label className="block text-xs font-medium text-[#172554]">
              {t.transactions.entrySourceLabel}
            </label>
            <div className="grid grid-cols-3 gap-1.5 p-1 rounded-xl bg-[#F5F8FF] border border-slate-200">
              {(
                [
                  { id: 'ALL', label: t.transactions.sources.all },
                  { id: 'VOICE', label: t.transactions.sources.voice },
                  { id: 'MANUAL', label: t.transactions.sources.manual },
                ] as const
              ).map((src) => (
                <button
                  key={src.id}
                  type="button"
                  onClick={() => setSourceFilter(src.id)}
                  className={`min-h-[36px] rounded-lg text-xs font-semibold cursor-pointer ${
                    sourceFilter === src.id
                      ? 'bg-[#2563EB] text-white shadow-xs'
                      : 'text-[#64748B]'
                  }`}
                >
                  {src.label}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2.5">
            <Input
              label={t.transactions.minAmount}
              placeholder="0"
              inputMode="decimal"
              value={minAmount}
              onChange={(e) => setMinAmount(e.target.value)}
            />
            <Input
              label={t.transactions.maxAmount}
              placeholder="10000"
              inputMode="decimal"
              value={maxAmount}
              onChange={(e) => setMaxAmount(e.target.value)}
            />
          </div>

          <div className="grid grid-cols-2 gap-2.5 pt-2">
            <Button
              variant="ghost"
              onClick={() => {
                setCustomerIdFilter('');
                setDateFilter('ALL');
                setSourceFilter('ALL');
                setTypeFilter('ALL');
                setMinAmount('');
                setMaxAmount('');
              }}
            >
              {t.common.clearAll}
            </Button>
            <Button onClick={() => setFiltersOpen(false)}>{t.common.apply}</Button>
          </div>
        </div>
      </Modal>

      <TransactionModal
        isOpen={txnModal.open}
        onClose={() => setTxnModal((prev) => ({ ...prev, open: false }))}
        initialType={txnModal.type}
      />

      <Modal
        isOpen={Boolean(reverseTarget)}
        onClose={() => setReverseTarget(null)}
        title={t.transactions.reverseTitle}
        subtitle={t.transactions.reverseSubtitle}
      >
        {reverseTarget && (
          <form onSubmit={handleConfirmReverse} className="space-y-3.5">
            <div className="rounded-xl bg-[#F5F8FF] border border-slate-200 p-3 text-xs space-y-1">
              <p className="text-[#64748B]">
                {t.transactions.customerLabel}{' '}
                <span className="text-[#172554] font-semibold">
                  {customerMap.get(reverseTarget.customerId)}
                </span>
              </p>
              <p className="text-[#64748B]">
                {t.transactions.entryLabel}{' '}
                <span className="text-[#172554] font-mono font-semibold tabular-nums">
                  {reverseTarget.type === 'CREDIT'
                    ? t.labels.credit
                    : reverseTarget.type === 'REPAYMENT'
                    ? t.labels.repayment
                    : t.labels.reversal}{' '}
                  {formatINR(reverseTarget.amountPaise)}
                </span>
              </p>
            </div>
            <Input
              label={t.transactions.reasonLabel}
              placeholder={t.transactions.reasonPlaceholder}
              value={reverseReason}
              onChange={(e) => setReverseReason(e.target.value)}
            />
            {reverseError && (
              <div className="rounded-xl bg-orange-50 border border-orange-200 px-3 py-2 text-xs text-orange-700">
                {reverseError}
              </div>
            )}
            <div className="grid grid-cols-2 gap-2.5 pt-1">
              <Button variant="ghost" onClick={() => setReverseTarget(null)}>
                {t.common.cancel}
              </Button>
              <Button type="submit" variant="danger" leftIcon={<RotateCcw className="w-4 h-4" />}>
                {t.common.reverse}
              </Button>
            </div>
          </form>
        )}
      </Modal>
    </div>
  );
};
