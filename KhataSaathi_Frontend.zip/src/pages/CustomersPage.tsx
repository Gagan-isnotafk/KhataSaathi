import React, { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, UserPlus, Users } from 'lucide-react';
import { AddCustomerModal } from '@/src/components/AddCustomerModal';
import { Button } from '@/src/components/Button';
import { CustomerCard } from '@/src/components/CustomerCard';
import { EmptyState } from '@/src/components/EmptyState';
import { Input } from '@/src/components/Input';
import { useApp } from '@/src/context/AppContext';
import { formatINR } from '@/src/utils/currency';

type FilterMode = 'ALL' | 'DUE' | 'SETTLED' | 'INACTIVE';

export const CustomersPage: React.FC = () => {
  const { customerSummaries, dashboardMetrics, t } = useApp();
  const navigate = useNavigate();

  const [search, setSearch] = useState('');
  const [filterMode, setFilterMode] = useState<FilterMode>('ALL');
  const [addOpen, setAddOpen] = useState(false);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return customerSummaries
      .filter((s) => {
        if (filterMode === 'INACTIVE') {
          if (s.customer.status !== 'INACTIVE') return false;
        } else {
          if (s.customer.status !== 'ACTIVE') return false;
          if (filterMode === 'DUE' && s.currentBalancePaise <= 0) return false;
          if (filterMode === 'SETTLED' && s.currentBalancePaise !== 0) return false;
        }

        if (!q) return true;
        const nameMatch = s.customer.name.toLowerCase().includes(q);
        const phoneMatch = (s.customer.phone || '')
          .replace(/\s/g, '')
          .includes(q.replace(/\s/g, ''));
        return nameMatch || phoneMatch;
      })
      .sort((a, b) => b.currentBalancePaise - a.currentBalancePaise);
  }, [customerSummaries, search, filterMode]);

  return (
    <div className="space-y-3.5 pb-2">
      <div className="flex items-center justify-between gap-3">
        <div>
          <p className="text-xs text-[#64748B] tabular-nums">
            {t.customers.activeSummary(dashboardMetrics.activeCustomerCount)} · {t.customers.dueLabel}{' '}
            <span className="text-[#2563EB] font-mono font-bold">
              {formatINR(dashboardMetrics.totalOutstandingPaise)}
            </span>
          </p>
        </div>

        <Button
          size="sm"
          onClick={() => setAddOpen(true)}
          leftIcon={<UserPlus className="w-4 h-4" />}
        >
          {t.customers.addParty}
        </Button>
      </div>

      <Input
        placeholder={t.customers.searchPlaceholder}
        leftAddon={<Search className="w-4 h-4" />}
        value={search}
        onChange={(e) => setSearch(e.target.value)}
      />

      <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar">
        {(
          [
            { id: 'ALL', label: t.customers.filters.all },
            { id: 'DUE', label: t.customers.filters.due },
            { id: 'SETTLED', label: t.customers.filters.settled },
            { id: 'INACTIVE', label: t.customers.filters.inactive },
          ] as const
        ).map((tab) => (
          <button
            key={tab.id}
            type="button"
            onClick={() => setFilterMode(tab.id)}
            className={`shrink-0 min-h-[36px] px-3.5 rounded-xl text-xs font-semibold transition-colors cursor-pointer ${
              filterMode === tab.id
                ? 'bg-[#2563EB] text-white shadow-[0_2px_8px_rgba(37,99,235,0.22)]'
                : 'bg-white border border-slate-200 text-[#64748B] hover:text-[#172554]'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {filtered.length === 0 ? (
        <EmptyState
          icon={<Users className="w-6 h-6" />}
          title={t.customers.emptyTitle}
          description={
            search
              ? t.customers.emptySearchDesc(search)
              : t.customers.emptyFilterDesc
          }
          actionLabel={t.customers.emptyAction}
          onAction={() => setAddOpen(true)}
        />
      ) : (
        <div className="space-y-2">
          {filtered.map((summary) => (
            <CustomerCard
              key={summary.customer.id}
              summary={summary}
              onClick={() => navigate(`/customers/${summary.customer.id}`)}
            />
          ))}
        </div>
      )}

      <AddCustomerModal
        isOpen={addOpen}
        onClose={() => setAddOpen(false)}
        onCreated={(c) => navigate(`/customers/${c.id}`)}
      />
    </div>
  );
};
