import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowRight, CheckCircle2, Phone, User } from 'lucide-react';
import { LogoMark } from '@/src/assets/LogoMark';
import { Button } from '@/src/components/Button';
import { Input } from '@/src/components/Input';
import { useApp } from '@/src/context/AppContext';
import {
  generateDemoOtp,
  isValidIndianMobile,
  normalizeIndianPhone,
} from '@/src/services/mock/authService';
import { LANGUAGE_OPTIONS } from '@/src/utils/i18n';

export const WelcomeLoginPage: React.FC = () => {
  const {
    session,
    shop,
    t,
    setLanguage,
    loginWithOtp,
    registerWithOtp,
    loginAsDemoShopkeeper,
  } = useApp();
  const navigate = useNavigate();

  const [mode, setMode] = useState<'LOGIN' | 'REGISTER'>('LOGIN');
  const [step, setStep] = useState<'PHONE' | 'OTP'>('PHONE');
  const [ownerName, setOwnerName] = useState('');
  const [phone, setPhone] = useState('98450 23190');
  const [otpInput, setOtpInput] = useState('');
  const [generatedOtp, setGeneratedOtp] = useState('');
  const [resendCooldown, setResendCooldown] = useState(0);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (session.isAuthenticated) {
      navigate(session.isShopSetupComplete ? '/dashboard' : '/setup', {
        replace: true,
      });
    }
  }, [session.isAuthenticated, session.isShopSetupComplete, navigate]);

  useEffect(() => {
    if (resendCooldown <= 0) return;
    const timer = window.setInterval(() => {
      setResendCooldown((prev) => Math.max(0, prev - 1));
    }, 1000);
    return () => window.clearInterval(timer);
  }, [resendCooldown]);

  const handleSendOtp = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (mode === 'REGISTER' && ownerName.trim().length < 2) {
      setError(t.auth.errNameRequired);
      return;
    }

    if (!isValidIndianMobile(phone)) {
      setError(t.auth.errInvalidMobile);
      return;
    }

    const otp = generateDemoOtp();
    setGeneratedOtp(otp);
    setOtpInput('');
    setResendCooldown(30);
    setStep('OTP');
  };

  const handleResendOtp = () => {
    if (resendCooldown > 0) return;
    const otp = generateDemoOtp();
    setGeneratedOtp(otp);
    setOtpInput('');
    setResendCooldown(30);
    setError(null);
  };

  const handleVerifyOtp = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (otpInput.trim() !== generatedOtp) {
      setError(t.auth.errIncorrectOtp(generatedOtp));
      return;
    }

    const normalized = normalizeIndianPhone(phone);
    if (mode === 'REGISTER') {
      registerWithOtp(ownerName.trim(), normalized);
      navigate('/setup', { replace: true });
    } else {
      loginWithOtp(normalized);
      navigate('/dashboard', { replace: true });
    }
  };

  const handleDemoLogin = () => {
    loginAsDemoShopkeeper();
    navigate('/dashboard', { replace: true });
  };

  return (
    <div className="flex-1 flex flex-col justify-between overflow-y-auto px-4 py-5 bg-[#F5F8FF] text-[#172554]">
      <div className="space-y-5">
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2.5 min-w-0">
            <LogoMark className="w-10 h-10 shrink-0" />
            <div className="min-w-0">
              <h1 className="text-lg font-display font-bold text-[#172554] leading-tight truncate">
                {t.brandName}
              </h1>
              <p className="text-[11px] text-[#2563EB] font-semibold truncate">{t.tagline}</p>
            </div>
          </div>

          <div className="flex gap-1 shrink-0">
            {LANGUAGE_OPTIONS.map((lang) => (
              <button
                key={lang.code}
                type="button"
                onClick={() => setLanguage(lang.code)}
                className={`min-h-[34px] px-2.5 rounded-lg text-[11px] font-semibold border transition-colors cursor-pointer ${
                  shop.language === lang.code
                    ? 'bg-[#DBEAFE] text-[#2563EB] border-[#2563EB]/40'
                    : 'bg-white text-[#64748B] border-slate-200 hover:text-[#172554]'
                }`}
              >
                {lang.nativeLabel}
              </button>
            ))}
          </div>
        </div>

        <div className="space-y-1 pt-1">
          <h2 className="text-xl font-display font-bold text-[#172554] leading-snug">
            {t.auth.heroTitle}
          </h2>
          <p className="text-xs text-[#64748B] leading-relaxed">
            {t.auth.heroSubtitle}
          </p>
        </div>

        <div className="rounded-2xl bg-white border border-slate-200/80 shadow-[0_4px_18px_rgba(37,99,235,0.06)] p-4 space-y-4">
          <div className="grid grid-cols-2 gap-1 p-1 rounded-xl bg-[#F5F8FF] border border-slate-200">
            <button
              type="button"
              onClick={() => {
                setMode('LOGIN');
                setStep('PHONE');
                setError(null);
              }}
              className={`min-h-[40px] rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
                mode === 'LOGIN'
                  ? 'bg-white text-[#2563EB] border border-slate-200 shadow-xs'
                  : 'text-[#64748B] hover:text-[#172554]'
              }`}
            >
              {t.auth.loginTab}
            </button>
            <button
              type="button"
              onClick={() => {
                setMode('REGISTER');
                setStep('PHONE');
                setError(null);
              }}
              className={`min-h-[40px] rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
                mode === 'REGISTER'
                  ? 'bg-white text-[#2563EB] border border-slate-200 shadow-xs'
                  : 'text-[#64748B] hover:text-[#172554]'
              }`}
            >
              {t.auth.newShopTab}
            </button>
          </div>

          {step === 'PHONE' ? (
            <form onSubmit={handleSendOtp} className="space-y-3.5">
              {mode === 'REGISTER' && (
                <Input
                  label={t.auth.ownerNameLabel}
                  placeholder={t.auth.ownerNamePlaceholder}
                  leftAddon={<User className="w-4 h-4" />}
                  value={ownerName}
                  onChange={(e) => setOwnerName(e.target.value)}
                  required
                />
              )}

              <Input
                label={t.auth.mobileLabel}
                placeholder="98450 23190"
                type="tel"
                inputMode="tel"
                leftAddon={<span className="text-xs font-mono font-semibold text-[#172554]">+91</span>}
                rightAddon={<Phone className="w-4 h-4" />}
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                required
              />

              {error && (
                <div className="rounded-xl bg-orange-50 border border-orange-200 px-3 py-2 text-xs text-orange-700">
                  {error}
                </div>
              )}

              <Button
                type="submit"
                className="w-full"
                rightIcon={<ArrowRight className="w-4 h-4" />}
              >
                {t.auth.sendOtpBtn}
              </Button>
            </form>
          ) : (
            <form onSubmit={handleVerifyOtp} className="space-y-3.5">
              <div className="text-xs text-[#64748B]">
                {t.auth.otpSentTo}{' '}
                <span className="text-[#172554] font-mono font-semibold">+91 {phone}</span>
              </div>

              <div className="rounded-xl bg-[#DBEAFE]/60 border border-[#93C5FD] px-3.5 py-2.5 flex items-center justify-between gap-2">
                <div className="text-xs text-[#172554]">
                  {t.auth.demoOtpLabel}{' '}
                  <span className="font-mono font-bold text-base text-[#2563EB] tabular-nums">
                    {generatedOtp}
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => setOtpInput(generatedOtp)}
                  className="text-xs font-semibold text-[#2563EB] underline cursor-pointer"
                >
                  {t.auth.autoFill}
                </button>
              </div>

              <Input
                label={t.auth.enterOtpLabel}
                placeholder="••••"
                inputMode="numeric"
                maxLength={4}
                value={otpInput}
                onChange={(e) => setOtpInput(e.target.value.replace(/\D/g, '').slice(0, 4))}
                className="font-mono tracking-[0.45em] text-base"
                required
              />

              {error && (
                <div className="rounded-xl bg-orange-50 border border-orange-200 px-3 py-2 text-xs text-orange-700">
                  {error}
                </div>
              )}

              <Button
                type="submit"
                className="w-full"
                leftIcon={<CheckCircle2 className="w-4 h-4" />}
              >
                {t.auth.verifyBtn}
              </Button>

              <div className="flex items-center justify-between text-xs pt-0.5">
                <button
                  type="button"
                  onClick={() => {
                    setStep('PHONE');
                    setError(null);
                  }}
                  className="text-[#64748B] hover:text-[#172554] cursor-pointer"
                >
                  {t.auth.changeNumber}
                </button>
                <button
                  type="button"
                  disabled={resendCooldown > 0}
                  onClick={handleResendOtp}
                  className="text-[#2563EB] font-medium disabled:text-slate-400 tabular-nums cursor-pointer"
                >
                  {resendCooldown > 0 ? t.auth.resendIn(resendCooldown) : t.auth.resendOtp}
                </button>
              </div>
            </form>
          )}
        </div>
      </div>

      <div className="pt-5 space-y-2">
        <Button variant="secondary" className="w-full" onClick={handleDemoLogin}>
          {t.auth.demoShopBtn}
        </Button>
        <p className="text-[11px] text-[#64748B] text-center">
          {t.auth.demoFooterNote}
        </p>
      </div>
    </div>
  );
};
