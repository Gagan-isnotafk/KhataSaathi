import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { CheckCircle2, MapPin, Store, User } from 'lucide-react';
import { LogoMark } from '@/src/assets/LogoMark';
import { Button } from '@/src/components/Button';
import { Input } from '@/src/components/Input';
import { useApp } from '@/src/context/AppContext';
import { LanguageCode, ShopCategory } from '@/src/types';
import { LANGUAGE_OPTIONS } from '@/src/utils/i18n';

const CATEGORIES: ShopCategory[] = [
  'Kirana & Grocery',
  'Wholesale & Distributors',
  'Hardware & Electrical',
  'Pharmacy & Medical',
  'Stationery & Books',
  'Textiles & Apparel',
  'Other',
];

export const ShopSetupPage: React.FC = () => {
  const { shop, user, t, setLanguage, completeShopSetup } = useApp();
  const navigate = useNavigate();

  const [shopName, setShopName] = useState(shop.name || '');
  const [ownerName, setOwnerName] = useState(user.name || shop.ownerName || '');
  const [category, setCategory] = useState<ShopCategory>(shop.category || 'Kirana & Grocery');
  const [language, setLocalLanguage] = useState<LanguageCode>(shop.language || 'en');
  const [address, setAddress] = useState(shop.address || '');
  const [error, setError] = useState<string | null>(null);

  const handleSelectLanguage = (code: LanguageCode) => {
    setLocalLanguage(code);
    setLanguage(code);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    const res = completeShopSetup({
      name: shopName,
      ownerName,
      category,
      language,
      address,
    });

    if (!res.ok) {
      setError(res.error || t.setup.errRequired);
      return;
    }

    navigate('/dashboard', { replace: true });
  };

  return (
    <div className="flex-1 flex flex-col min-h-0 bg-[#F5F8FF] text-[#172554]">
      <header className="shrink-0 h-[56px] px-4 border-b border-slate-200/80 flex items-center gap-3 bg-white">
        <LogoMark className="w-8 h-8" />
        <div>
          <h1 className="text-base font-display font-bold text-[#172554] leading-tight">
            {t.setup.title}
          </h1>
          <p className="text-[11px] text-[#64748B]">{t.setup.subtitle}</p>
        </div>
      </header>

      <form onSubmit={handleSubmit} className="flex-1 flex flex-col min-h-0">
        <div className="flex-1 overflow-y-auto px-4 py-4 space-y-4">
          <div className="rounded-2xl bg-white border border-slate-200/80 shadow-[0_2px_10px_rgba(37,99,235,0.04)] p-4 space-y-4">
            <div className="space-y-1.5">
              <label className="block text-xs font-medium text-[#172554]">
                {t.setup.languageLabel}
              </label>
              <div className="grid grid-cols-3 gap-2">
                {LANGUAGE_OPTIONS.map((lang) => (
                  <button
                    key={lang.code}
                    type="button"
                    onClick={() => handleSelectLanguage(lang.code)}
                    className={`min-h-[42px] rounded-xl text-xs font-semibold border transition-colors cursor-pointer ${
                      language === lang.code
                        ? 'bg-[#DBEAFE] text-[#2563EB] border-[#2563EB]/40'
                        : 'bg-[#F5F8FF] text-[#64748B] border-slate-200 hover:text-[#172554]'
                    }`}
                  >
                    {lang.nativeLabel}
                  </button>
                ))}
              </div>
            </div>

            <Input
              label={t.setup.shopNameLabel}
              placeholder={t.setup.shopNamePlaceholder}
              leftAddon={<Store className="w-4 h-4" />}
              value={shopName}
              onChange={(e) => setShopName(e.target.value)}
              required
            />

            <Input
              label={t.setup.ownerNameLabel}
              placeholder={t.setup.ownerNamePlaceholder}
              leftAddon={<User className="w-4 h-4" />}
              value={ownerName}
              onChange={(e) => setOwnerName(e.target.value)}
              required
            />

            <div className="space-y-1.5">
              <label className="block text-xs font-medium text-[#172554]">
                {t.setup.categoryLabel}
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as ShopCategory)}
                className="w-full min-h-[46px] rounded-xl bg-white border border-slate-200 px-3.5 text-sm text-[#172554] focus:outline-none focus:border-[#2563EB] focus:ring-2 focus:ring-[#DBEAFE]"
              >
                {CATEGORIES.map((cat) => (
                  <option key={cat} value={cat}>
                    {t.categories[cat]}
                  </option>
                ))}
              </select>
            </div>

            <Input
              label={t.setup.addressLabel}
              placeholder={t.setup.addressPlaceholder}
              leftAddon={<MapPin className="w-4 h-4" />}
              value={address}
              onChange={(e) => setAddress(e.target.value)}
            />
          </div>

          {error && (
            <div className="rounded-xl bg-orange-50 border border-orange-200 px-3.5 py-2.5 text-xs text-orange-700">
              {error}
            </div>
          )}
        </div>

        <div className="shrink-0 p-4 border-t border-slate-200/80 bg-white">
          <Button
            type="submit"
            className="w-full"
            leftIcon={<CheckCircle2 className="w-4 h-4" />}
          >
            {t.setup.launchBtn}
          </Button>
        </div>
      </form>
    </div>
  );
};
