import React, { useMemo, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import {
  ArrowDownLeft,
  ArrowUpRight,
  Edit3,
  Phone,
  RotateCcw,
  UserCheck,
  UserX,
} from 'lucide-react';
import { Button } from '@/src/components/Button';
import { EmptyState } from '@/src/components/EmptyState';
import { Input } from '@/src/components/Input';
import { Modal } from '@/src/components/Modal';
import { TransactionModal } from '@/src/components/TransactionModal';
import { useApp } from '@/src/context/AppContext';
import { computeCustomerLedger } from '@/src/services/mock/ledgerEngine';
import { Transaction } from '@/src/types';
import { formatINR } from '@/src/utils/currency';
import { formatDateTime, formatShortDate } from '@/src/utils/date';

export const CustomerLedgerPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const {
    customers,
    transactions,
    shop,
    t,
    updateCustomer,
    toggleCustomerStatus,
    reverseTransaction,
  } = useApp();

  const customer = useMemo(() => customers.find((c) => c.id === id), [customers, id]);

  const ledger = useMemo(() => {
    if (!customer) return null;
    return computeCustomerLedger(customer, transactions);
  }, [customer, transactions]);

  const [txnModal, setTxnModal] = useState<{ open: boolean; type: 'CREDIT' | 'REPAYMENT' }>({
    open: false,
    type: 'CREDIT',
  });
  const [editOpen, setEditOpen] = useState(false);
  const [editName, setEditName] = useState('');
  const [editPhone, setEditPhone] = useState('');
  const [editNotes, setEditNotes] = useState('');
  const [editError, setEditError] = useState<string | null>(null);

  const [reverseTarget, setReverseTarget] = useState<Transaction | null>(null);
  const [reverseReason, setReverseReason] = useState('');
  const [reverseError, setReverseError] = useState<string | null>(null);

  if (!customer || !ledger) {
    return (
      <EmptyState
        icon={<UserX className="w-6 h-6" />}
        title={t.ledger.notFoundTitle}
        description={t.ledger.notFoundDesc}
        actionLabel={t.ledger.backToCustomers}
        onAction={() => navigate('/customers')}
      />
    );
  }

  const openEditModal = () => {
    setEditName(customer.name);
    setEditPhone(customer.phone || '');
    setEditNotes(customer.notes || '');
    setEditError(null);
    setEditOpen(true);
  };

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    const res = updateCustomer(customer.id, {
      name: editName,
      phone: editPhone,
      notes: editNotes,
    });
    if (!res.ok) {
      setEditError(res.error || t.errors.couldNotUpdateCustomer);
      return;
    }
    setEditOpen(false);
  };

  const handleConfirmReverse = (e: React.FormEvent) => {
    e.preventDefault();
    if (!reverseTarget) return;
    setReverseError(null);
    const res = reverseTransaction(reverseTarget.id, reverseReason);
    if (!res.ok) {
      setReverseError(res.error || t.errors.couldNotReverseTxn);
      return;
    }
    setReverseTarget(null);
    setReverseReason('');
  };

  const orderedEntriesDesc = [...ledger.entries].reverse();

  return (
    <div className="space-y-3.5 pb-2">
      <div className="rounded-2xl bg-white border border-slate-200/80 shadow-[0_4px_16px_rgba(37,99,235,0.06)] p-4 space-y-3.5">
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <h2 className="text-lg font-display font-bold text-[#172554] truncate">
              {customer.name}
            </h2>
            <div className="flex items-center gap-2 text-xs text-[#64748B] mt-0.5 truncate">
              {customer.phone && (
                <span className="inline-flex items-center gap-1 tabular-nums">
                  <Phone className="w-3 h-3 text-[#2563EB]" />
                  {customer.phone}
                </span>
              )}
              {customer.status === 'INACTIVE' && (
                <span className="text-amber-600 font-medium">{t.ledger.inactiveTag}</span>
              )}
            </div>
            {customer.notes && (
              <p className="text-[11px] text-[#64748B] mt-1 truncate">{customer.notes}</p>
            )}
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            <button
              type="button"
              onClick={openEditModal}
              aria-label={t.ledger.editProfileAria}
              className="min-h-[38px] min-w-[38px] rounded-xl bg-[#F5F8FF] border border-slate-200 flex items-center justify-center text-[#172554] hover:border-[#2563EB] cursor-pointer"
            >
              <Edit3 className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={() => toggleCustomerStatus(customer.id)}
              aria-label={
                customer.status === 'ACTIVE' ? t.ledger.deactivateAria : t.ledger.reactivateAria
              }
              className="min-h-[38px] min-w-[38px] rounded-xl bg-[#F5F8FF] border border-slate-200 flex items-center justify-center text-[#172554] hover:border-[#2563EB] cursor-pointer"
            >
              {customer.status === 'ACTIVE' ? (
                <UserX className="w-4 h-4" />
              ) : (
                <UserCheck className="w-4 h-4 text-green-600" />
              )}
            </button>
          </div>
        </div>

        <div className="pt-3 border-t border-slate-100 flex items-end justify-between">
          <div>
            <span className="text-[11px] font-medium text-[#64748B]">{t.ledger.netBalance}</span>
            <div
              className={`text-2xl font-mono font-bold tabular-nums ${
                ledger.currentBalancePaise > 0
                  ? 'text-orange-600'
                  : ledger.currentBalancePaise < 0
                  ? 'text-green-600'
                  : 'text-[#2563EB]'
              }`}
            >
              {formatINR(Math.abs(ledger.currentBalancePaise))}
            </div>
            <span className="text-[11px] text-[#64748B]">
              {ledger.currentBalancePaise > 0
                ? t.ledger.owesYou
                : ledger.currentBalancePaise < 0
                ? t.ledger.advanceWithShop
                : t.ledger.settled}
            </span>
          </div>

          <div className="text-right space-y-1 text-xs tabular-nums">
            <p className="text-[#64748B]">
              {t.ledger.creditLabel}{' '}
              <span className="text-orange-600 font-mono font-semibold">
                {formatINR(ledger.totalCreditPaise)}
              </span>
            </p>
            <p className="text-[#64748B]">
              {t.ledger.repaidLabel}{' '}
              <span className="text-green-600 font-mono font-semibold">
                {formatINR(ledger.totalRepaymentPaise)}
              </span>
            </p>
          </div>
        </div>
      </div>

      {customer.status === 'ACTIVE' && (
        <div className="grid grid-cols-2 gap-2.5">
          <Button
            onClick={() => setTxnModal({ open: true, type: 'CREDIT' })}
            leftIcon={<ArrowUpRight className="w-4 h-4" />}
          >
            {t.ledger.giveCredit}
          </Button>
          <Button
            variant="secondary"
            onClick={() => setTxnModal({ open: true, type: 'REPAYMENT' })}
            leftIcon={<ArrowDownLeft className="w-4 h-4 text-green-600" />}
          >
            {t.ledger.gotPayment}
          </Button>
        </div>
      )}

      <div className="rounded-2xl bg-white border border-slate-200/80 shadow-[0_2px_10px_rgba(37,99,235,0.04)] overflow-hidden">
        <div className="px-4 py-3 border-b border-slate-100 flex items-center justify-between">
          <h3 className="text-sm font-display font-semibold text-[#172554]">
            {t.ledger.historyTitle}
          </h3>
          <span className="text-[11px] font-mono text-[#2563EB] font-semibold tabular-nums">
            {t.common.entriesCount(ledger.entries.length)}
          </span>
        </div>

        <div className="divide-y divide-slate-100">
          {orderedEntriesDesc.map(({ transaction, runningBalancePaise }) => {
            const isCredit = transaction.type === 'CREDIT';
            const isRepayment = transaction.type === 'REPAYMENT';
            const isReversed = transaction.status === 'REVERSED';
            const typeText = isCredit
              ? t.labels.credit
              : isRepayment
              ? t.labels.repayment
              : t.labels.reversal;
            const sourceText =
              transaction.source === 'VOICE' ? t.labels.voiceEntry : t.labels.manualEntry;

            return (
              <div key={transaction.id} className="p-3.5 space-y-1.5">
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <p className="text-sm font-medium text-[#172554] leading-snug">
                      {transaction.description}
                    </p>
                    <p className="text-[11px] text-[#64748B] mt-0.5">
                      <span
                        className={`font-semibold ${
                          isCredit
                            ? 'text-orange-600'
                            : isRepayment
                            ? 'text-green-600'
                            : 'text-[#2563EB]'
                        }`}
                      >
                        {typeText}
                      </span>{' '}
                      · {sourceText} · {formatDateTime(transaction.occurredAt, shop.language)}
                    </p>
                  </div>
                  <div className="text-right shrink-0">
                    <div
                      className={`text-sm font-mono font-bold tabular-nums ${
                        isReversed
                          ? 'line-through text-slate-400'
                          : isCredit
                          ? 'text-orange-600'
                          : isRepayment
                          ? 'text-green-600'
                          : 'text-[#2563EB]'
                      }`}
                    >
                      {isCredit ? '+' : isRepayment ? '-' : ''}
                      {formatINR(transaction.amountPaise)}
                    </div>
                    <div className="text-[11px] font-mono text-[#64748B] tabular-nums">
                      {t.ledger.balShort}{' '}
                      <span className="text-[#2563EB] font-semibold">
                        {formatINR(runningBalancePaise)}
                      </span>
                    </div>
                  </div>
                </div>

                {transaction.status === 'POSTED' && transaction.type !== 'REVERSAL' && (
                  <div className="flex justify-end">
                    <button
                      type="button"
                      onClick={() => {
                        setReverseTarget(transaction);
                        setReverseReason('');
                        setReverseError(null);
                      }}
                      className="text-[11px] text-[#64748B] hover:text-orange-600 inline-flex items-center gap-1 cursor-pointer"
                    >
                      <RotateCcw className="w-3 h-3" />
                      <span>{t.common.reverse}</span>
                    </button>
                  </div>
                )}
              </div>
            );
          })}

          <div className="p-3.5 bg-[#F5F8FF] flex items-center justify-between text-xs text-[#64748B]">
            <span>
              {t.ledger.openingBalance} ({formatShortDate(customer.createdAt, shop.language)})
            </span>
            <span className="font-mono font-semibold text-[#172554] tabular-nums">
              {formatINR(customer.openingBalancePaise)}
            </span>
          </div>
        </div>
      </div>

      <TransactionModal
        isOpen={txnModal.open}
        onClose={() => setTxnModal((prev) => ({ ...prev, open: false }))}
        initialType={txnModal.type}
        initialCustomerId={customer.id}
      />

      <Modal isOpen={editOpen} onClose={() => setEditOpen(false)} title={t.ledger.editCustomerTitle}>
        <form onSubmit={handleSaveProfile} className="space-y-3.5">
          <Input
            label={t.ledger.customerNameLabel}
            value={editName}
            onChange={(e) => setEditName(e.target.value)}
            required
          />
          <Input
            label={t.ledger.phoneLabel}
            value={editPhone}
            onChange={(e) => setEditPhone(e.target.value)}
          />
          <Input
            label={t.ledger.notesLabel}
            value={editNotes}
            onChange={(e) => setEditNotes(e.target.value)}
          />
          {editError && (
            <div className="rounded-xl bg-orange-50 border border-orange-200 px-3 py-2 text-xs text-orange-700">
              {editError}
            </div>
          )}
          <div className="grid grid-cols-2 gap-2.5 pt-1">
            <Button variant="ghost" onClick={() => setEditOpen(false)}>
              {t.common.cancel}
            </Button>
            <Button type="submit">{t.common.save}</Button>
          </div>
        </form>
      </Modal>

      <Modal
        isOpen={Boolean(reverseTarget)}
        onClose={() => setReverseTarget(null)}
        title={t.ledger.reverseEntryTitle}
        subtitle={t.ledger.reverseSubtitle}
      >
        {reverseTarget && (
          <form onSubmit={handleConfirmReverse} className="space-y-3.5">
            <div className="rounded-xl bg-[#F5F8FF] border border-slate-200 p-3 text-xs space-y-1">
              <p className="text-[#64748B]">
                {t.ledger.entryLabel}{' '}
                <span className="text-[#172554] font-mono font-semibold tabular-nums">
                  {reverseTarget.type === 'CREDIT'
                    ? t.labels.credit
                    : reverseTarget.type === 'REPAYMENT'
                    ? t.labels.repayment
                    : t.labels.reversal}{' '}
                  {formatINR(reverseTarget.amountPaise)}
                </span>
              </p>
              <p className="text-[#64748B] truncate">{reverseTarget.description}</p>
            </div>
            <Input
              label={t.ledger.reasonLabel}
              placeholder={t.ledger.reasonPlaceholder}
              value={reverseReason}
              onChange={(e) => setReverseReason(e.target.value)}
            />
            {reverseError && (
              <div className="rounded-xl bg-orange-50 border border-orange-200 px-3 py-2 text-xs text-orange-700">
                {reverseError}
              </div>
            )}
            <div className="grid grid-cols-2 gap-2.5 pt-1">
              <Button variant="ghost" onClick={() => setReverseTarget(null)}>
                {t.common.cancel}
              </Button>
              <Button type="submit" variant="danger">
                {t.common.reverse}
              </Button>
            </div>
          </form>
        )}
      </Modal>
    </div>
  );
};
