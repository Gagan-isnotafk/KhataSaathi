import React, { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  ArrowDownLeft,
  ArrowUpRight,
  BarChart3,
  ChevronRight,
  Mic,
  Plus,
  UserPlus,
} from 'lucide-react';
import {
  Bar,
  BarChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
} from 'recharts';
import { AddCustomerModal } from '@/src/components/AddCustomerModal';
import { TransactionCard } from '@/src/components/TransactionCard';
import { TransactionModal } from '@/src/components/TransactionModal';
import { useApp } from '@/src/context/AppContext';
import { buildSevenDaySeries } from '@/src/services/mock/reportService';
import { formatINR } from '@/src/utils/currency';

export const DashboardPage: React.FC = () => {
  const { customers, transactions, dashboardMetrics, shop, t } = useApp();
  const navigate = useNavigate();

  const [txnModal, setTxnModal] = useState<{ open: boolean; type: 'CREDIT' | 'REPAYMENT' }>({
    open: false,
    type: 'CREDIT',
  });
  const [addCustomerOpen, setAddCustomerOpen] = useState(false);

  const customerMap = useMemo(
    () => new Map(customers.map((c) => [c.id, c.name])),
    [customers]
  );

  const recentTransactions = useMemo(
    () =>
      [...transactions]
        .sort((a, b) => new Date(b.occurredAt).getTime() - new Date(a.occurredAt).getTime())
        .slice(0, 5),
    [transactions]
  );

  const chartData = useMemo(
    () => buildSevenDaySeries(transactions, shop.language),
    [transactions, shop.language]
  );

  return (
    <div className="space-y-4">
      <section className="rounded-2xl bg-white border border-slate-200/80 shadow-[0_4px_18px_rgba(37,99,235,0.06)] p-4 space-y-3.5">
        <div className="flex items-start justify-between gap-2">
          <div>
            <span className="text-xs font-medium text-[#64748B]">
              {t.dashboard.totalOutstanding}
            </span>
            <div className="text-[30px] font-display font-bold text-[#2563EB] tabular-nums leading-tight mt-0.5">
              {formatINR(dashboardMetrics.totalOutstandingPaise)}
            </div>
          </div>
          <button
            type="button"
            onClick={() => navigate('/customers')}
            className="text-xs font-semibold text-[#2563EB] bg-[#DBEAFE]/70 border border-[#93C5FD]/60 rounded-xl px-3 py-1.5 inline-flex items-center gap-1 cursor-pointer tabular-nums hover:bg-[#DBEAFE] transition-colors"
          >
            <span>{t.dashboard.partiesCount(dashboardMetrics.activeCustomerCount)}</span>
            <ChevronRight className="w-3.5 h-3.5 text-[#2563EB]" />
          </button>
        </div>

        <div className="grid grid-cols-2 gap-2.5 pt-3 border-t border-slate-100">
          <div className="rounded-xl bg-orange-50/70 border border-orange-200/60 px-3 py-2.5">
            <span className="text-[11px] font-medium text-orange-700 flex items-center gap-1">
              <ArrowUpRight className="w-3.5 h-3.5 text-orange-600" />
              {t.dashboard.todaysCredit}
            </span>
            <p className="text-base font-mono font-bold text-orange-600 tabular-nums mt-0.5">
              {formatINR(dashboardMetrics.todaysCreditPaise)}
            </p>
          </div>
          <div className="rounded-xl bg-green-50/70 border border-green-200/60 px-3 py-2.5 text-right">
            <span className="text-[11px] font-medium text-green-700 inline-flex items-center gap-1">
              <ArrowDownLeft className="w-3.5 h-3.5 text-green-600" />
              {t.dashboard.todaysRepayments}
            </span>
            <p className="text-base font-mono font-bold text-green-600 tabular-nums mt-0.5">
              {formatINR(dashboardMetrics.todaysRepaymentPaise)}
            </p>
          </div>
        </div>
      </section>

      <button
        type="button"
        onClick={() => navigate('/voice')}
        className="w-full rounded-2xl bg-gradient-to-r from-[#2563EB] to-[#1D4ED8] shadow-[0_8px_22px_rgba(37,99,235,0.28)] active:scale-[0.99] transition-transform p-3.5 flex items-center justify-between gap-3 text-left cursor-pointer"
      >
        <div className="flex items-center gap-3 min-w-0">
          <span className="w-12 h-12 rounded-full bg-white/15 ring-4 ring-white/20 text-white flex items-center justify-center shrink-0">
            <Mic className="w-6 h-6 stroke-[2.2]" />
          </span>
          <div className="min-w-0">
            <p className="text-sm font-display font-bold text-white truncate">
              {t.dashboard.voiceCtaTitle}
            </p>
            <p className="text-[11px] text-[#DBEAFE] truncate">
              {t.dashboard.voiceCtaExample}
            </p>
          </div>
        </div>
        <ChevronRight className="w-5 h-5 text-white shrink-0" />
      </button>

      <section className="grid grid-cols-4 gap-2">
        <button
          type="button"
          onClick={() => setTxnModal({ open: true, type: 'CREDIT' })}
          className="rounded-2xl bg-white border border-slate-200/80 shadow-[0_2px_8px_rgba(37,99,235,0.04)] active:bg-[#F5F8FF] py-3 px-1.5 flex flex-col items-center gap-1.5 cursor-pointer"
        >
          <span className="w-9 h-9 rounded-xl bg-orange-50 text-orange-600 border border-orange-200/70 flex items-center justify-center">
            <Plus className="w-4 h-4" />
          </span>
          <span className="text-[11px] font-semibold text-[#172554] truncate max-w-full">
            {t.dashboard.quickCredit}
          </span>
        </button>

        <button
          type="button"
          onClick={() => setTxnModal({ open: true, type: 'REPAYMENT' })}
          className="rounded-2xl bg-white border border-slate-200/80 shadow-[0_2px_8px_rgba(37,99,235,0.04)] active:bg-[#F5F8FF] py-3 px-1.5 flex flex-col items-center gap-1.5 cursor-pointer"
        >
          <span className="w-9 h-9 rounded-xl bg-green-50 text-green-600 border border-green-200/70 flex items-center justify-center">
            <ArrowDownLeft className="w-4 h-4" />
          </span>
          <span className="text-[11px] font-semibold text-[#172554] truncate max-w-full">
            {t.dashboard.quickPayment}
          </span>
        </button>

        <button
          type="button"
          onClick={() => setAddCustomerOpen(true)}
          className="rounded-2xl bg-white border border-slate-200/80 shadow-[0_2px_8px_rgba(37,99,235,0.04)] active:bg-[#F5F8FF] py-3 px-1.5 flex flex-col items-center gap-1.5 cursor-pointer"
        >
          <span className="w-9 h-9 rounded-xl bg-[#DBEAFE]/70 text-[#2563EB] border border-[#93C5FD]/50 flex items-center justify-center">
            <UserPlus className="w-4 h-4" />
          </span>
          <span className="text-[11px] font-semibold text-[#172554] truncate max-w-full">
            {t.dashboard.quickAddParty}
          </span>
        </button>

        <button
          type="button"
          onClick={() => navigate('/reports')}
          className="rounded-2xl bg-white border border-slate-200/80 shadow-[0_2px_8px_rgba(37,99,235,0.04)] active:bg-[#F5F8FF] py-3 px-1.5 flex flex-col items-center gap-1.5 cursor-pointer"
        >
          <span className="w-9 h-9 rounded-xl bg-[#DBEAFE]/70 text-[#2563EB] border border-[#93C5FD]/50 flex items-center justify-center">
            <BarChart3 className="w-4 h-4" />
          </span>
          <span className="text-[11px] font-semibold text-[#172554] truncate max-w-full">
            {t.dashboard.quickReports}
          </span>
        </button>
      </section>

      <section className="rounded-2xl bg-white border border-slate-200/80 shadow-[0_2px_10px_rgba(37,99,235,0.04)] p-4 space-y-2.5">
        <div className="flex items-center justify-between">
          <span className="text-xs font-semibold text-[#172554]">{t.dashboard.sevenDayActivity}</span>
          <div className="flex items-center gap-3 text-[11px] text-[#64748B]">
            <span className="inline-flex items-center gap-1">
              <span className="w-2 h-2 rounded-xs bg-orange-500" />
              {t.dashboard.creditLegend}
            </span>
            <span className="inline-flex items-center gap-1">
              <span className="w-2 h-2 rounded-xs bg-green-600" />
              {t.dashboard.paidLegend}
            </span>
          </div>
        </div>

        <div className="h-[150px] w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chartData} margin={{ top: 4, right: 0, left: 0, bottom: 0 }}>
              <XAxis
                dataKey="label"
                tick={{ fill: '#64748B', fontSize: 10 }}
                axisLine={false}
                tickLine={false}
              />
              <Tooltip
                cursor={{ fill: 'rgba(37, 99, 235, 0.05)' }}
                contentStyle={{
                  backgroundColor: '#FFFFFF',
                  borderColor: '#CBD5E1',
                  borderRadius: '10px',
                  fontSize: '11px',
                  color: '#172554',
                  boxShadow: '0 4px 12px rgba(37, 99, 235, 0.1)',
                }}
                formatter={(value: unknown, name: unknown) => [
                  `₹${Number(value || 0).toLocaleString('en-IN')}`,
                  name === 'creditRupees' ? t.dashboard.tooltipCredit : t.dashboard.tooltipRepaid,
                ]}
              />
              <Bar dataKey="creditRupees" fill="#F97316" radius={[4, 4, 0, 0]} maxBarSize={16} />
              <Bar dataKey="repaymentRupees" fill="#16A34A" radius={[4, 4, 0, 0]} maxBarSize={16} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </section>

      <section className="space-y-2.5 pb-2">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-display font-semibold text-[#172554]">
            {t.dashboard.recentTransactions}
          </h2>
          <button
            type="button"
            onClick={() => navigate('/transactions')}
            className="text-xs font-semibold text-[#2563EB] cursor-pointer hover:underline"
          >
            {t.dashboard.viewAll}
          </button>
        </div>

        <div className="space-y-2">
          {recentTransactions.map((txn) => (
            <TransactionCard
              key={txn.id}
              transaction={txn}
              customerName={customerMap.get(txn.customerId) || t.common.customer}
              onClick={() => navigate(`/customers/${txn.customerId}`)}
            />
          ))}
        </div>
      </section>

      <TransactionModal
        isOpen={txnModal.open}
        onClose={() => setTxnModal((prev) => ({ ...prev, open: false }))}
        initialType={txnModal.type}
      />

      <AddCustomerModal
        isOpen={addCustomerOpen}
        onClose={() => setAddCustomerOpen(false)}
      />
    </div>
  );
};
