export function generateId(prefix = 'id'): string {
  if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
    return `${prefix}_${crypto.randomUUID().slice(0, 12)}`;
  }
  return `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
}

export function generateIdempotencyKey(scope: string): string {
  const rand = Math.random().toString(36).slice(2, 10);
  return `idem_${scope}_${Date.now()}_${rand}`;
}
