import { LanguageCode } from '@/src/types';
import { getTranslations } from '@/src/utils/i18n';

export function getIntlLocale(lang: LanguageCode): string {
  if (lang === 'hi') return 'hi-IN-u-nu-latn';
  if (lang === 'kn') return 'kn-IN-u-nu-latn';
  return 'en-IN';
}

export function isSameLocalDay(isoA: string, dateB: Date = new Date()): boolean {
  const d = new Date(isoA);
  return (
    d.getFullYear() === dateB.getFullYear() &&
    d.getMonth() === dateB.getMonth() &&
    d.getDate() === dateB.getDate()
  );
}

export function getDayKey(isoOrDate: string | Date): string {
  const d = typeof isoOrDate === 'string' ? new Date(isoOrDate) : isoOrDate;
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

export function isWithinLastDays(iso: string, days: number, now: Date = new Date()): boolean {
  const target = new Date(iso);
  const start = new Date(now);
  start.setHours(0, 0, 0, 0);
  start.setDate(start.getDate() - (days - 1));
  return target >= start && target <= now;
}

export function formatShortDate(iso: string, lang: LanguageCode = 'en'): string {
  const d = new Date(iso);
  return d.toLocaleDateString(getIntlLocale(lang), {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  });
}

export function formatTime(iso: string, lang: LanguageCode = 'en'): string {
  const d = new Date(iso);
  return d.toLocaleTimeString(getIntlLocale(lang), {
    hour: '2-digit',
    minute: '2-digit',
    hour12: true,
  });
}

export function formatDateTime(iso: string, lang: LanguageCode = 'en'): string {
  const d = new Date(iso);
  const now = new Date();
  const t = getTranslations(lang);
  if (isSameLocalDay(iso, now)) {
    return `${t.labels.today}, ${formatTime(iso, lang)}`;
  }
  const yesterday = new Date(now);
  yesterday.setDate(yesterday.getDate() - 1);
  if (isSameLocalDay(iso, yesterday)) {
    return `${t.labels.yesterday}, ${formatTime(iso, lang)}`;
  }
  return `${d.toLocaleDateString(getIntlLocale(lang), {
    day: '2-digit',
    month: 'short',
  })}, ${formatTime(iso, lang)}`;
}

export function formatDuration(seconds: number): string {
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
}
