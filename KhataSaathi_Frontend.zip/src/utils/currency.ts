/**
 * Currency utilities using integer paise arithmetic to prevent floating-point drift.
 * 1 INR = 100 Paise.
 */

export function formatINR(paise: number, options?: { showSign?: boolean; forceDecimals?: boolean }): string {
  const safePaise = Math.round(Number.isFinite(paise) ? paise : 0);
  const isNegative = safePaise < 0;
  const absPaise = Math.abs(safePaise);
  const rupees = absPaise / 100;
  const hasRemainder = absPaise % 100 !== 0;

  const formatted = new Intl.NumberFormat('en-IN', {
    minimumFractionDigits: hasRemainder || options?.forceDecimals ? 2 : 0,
    maximumFractionDigits: 2,
  }).format(rupees);

  const sign = isNegative ? '-' : options?.showSign && safePaise > 0 ? '+' : '';
  return `${sign}₹${formatted}`;
}

export function formatINRCompact(paise: number): string {
  const safePaise = Math.round(Number.isFinite(paise) ? paise : 0);
  const absRupees = Math.abs(safePaise) / 100;
  const sign = safePaise < 0 ? '-' : '';

  if (absRupees >= 10000000) {
    return `${sign}₹${(absRupees / 10000000).toFixed(2)}Cr`;
  }
  if (absRupees >= 100000) {
    return `${sign}₹${(absRupees / 100000).toFixed(2)}L`;
  }
  if (absRupees >= 1000) {
    return `${sign}₹${(absRupees / 1000).toFixed(1)}k`;
  }
  return formatINR(safePaise);
}

/**
 * Converts a user-entered rupee string (e.g. "500.50", "1,250", "340") into integer paise.
 * Returns null if invalid or non-positive when requirePositive is true.
 */
export function parseRupeesToPaise(input: string | number, requirePositive = true): number | null {
  if (typeof input === 'number') {
    if (!Number.isFinite(input)) return null;
    const paise = Math.round(input * 100);
    if (requirePositive && paise <= 0) return null;
    if (!requirePositive && paise < 0) return null;
    return paise;
  }

  const cleaned = input.replace(/[₹,\s]/g, '').trim();
  if (!cleaned || !/^\d+(\.\d{1,2})?$/.test(cleaned)) {
    return null;
  }

  const [wholePart, fracPart = ''] = cleaned.split('.');
  const wholePaise = Number.parseInt(wholePart, 10) * 100;
  const fracPaise = Number.parseInt(fracPart.padEnd(2, '0'), 10);
  const total = wholePaise + fracPaise;

  if (!Number.isFinite(total)) return null;
  if (requirePositive && total <= 0) return null;
  if (!requirePositive && total < 0) return null;
  return total;
}

export function paiseToInputString(paise: number): string {
  const safePaise = Math.round(Number.isFinite(paise) ? paise : 0);
  const rupees = safePaise / 100;
  return safePaise % 100 === 0 ? String(rupees) : rupees.toFixed(2);
}
