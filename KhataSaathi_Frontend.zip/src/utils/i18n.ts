import { LanguageCode, ShopCategory } from '@/src/types';

export interface Translations {
  brandName: string;
  tagline: string;
  common: {
    cancel: string;
    save: string;
    close: string;
    edit: string;
    reset: string;
    reverse: string;
    apply: string;
    clearAll: string;
    retry: string;
    discard: string;
    confirmAndSave: string;
    noPhone: string;
    customer: string;
    unknown: string;
    entriesCount: (n: number) => string;
  };
  categories: Record<ShopCategory, string>;
  nav: {
    dashboard: string;
    voice: string;
    customers: string;
    transactions: string;
    reports: string;
    settings: string;
    voiceAssistantTitle: string;
    customerKhataTitle: string;
    goBack: string;
    settingsAria: string;
    homeAria: string;
    bottomNavAria: string;
  };
  auth: {
    heroTitle: string;
    heroSubtitle: string;
    loginTab: string;
    newShopTab: string;
    ownerNameLabel: string;
    ownerNamePlaceholder: string;
    mobileLabel: string;
    sendOtpBtn: string;
    otpSentTo: string;
    demoOtpLabel: string;
    autoFill: string;
    enterOtpLabel: string;
    verifyBtn: string;
    changeNumber: string;
    resendIn: (sec: number) => string;
    resendOtp: string;
    demoShopBtn: string;
    demoFooterNote: string;
    errNameRequired: string;
    errInvalidMobile: string;
    errIncorrectOtp: (otp: string) => string;
  };
  setup: {
    title: string;
    subtitle: string;
    shopNameLabel: string;
    shopNamePlaceholder: string;
    ownerNameLabel: string;
    ownerNamePlaceholder: string;
    categoryLabel: string;
    languageLabel: string;
    addressLabel: string;
    addressPlaceholder: string;
    launchBtn: string;
    errRequired: string;
  };
  dashboard: {
    totalOutstanding: string;
    partiesCount: (n: number) => string;
    todaysCredit: string;
    todaysRepayments: string;
    voiceCtaTitle: string;
    voiceCtaExample: string;
    quickCredit: string;
    quickPayment: string;
    quickAddParty: string;
    quickReports: string;
    sevenDayActivity: string;
    creditLegend: string;
    paidLegend: string;
    tooltipCredit: string;
    tooltipRepaid: string;
    recentTransactions: string;
    viewAll: string;
  };
  voice: {
    demoBadge: string;
    voiceOn: string;
    muted: string;
    errOn: string;
    errOff: string;
    states: {
      listening: string;
      processingAudio: string;
      transcribing: string;
      extracting: string;
      saving: string;
      tapToSpeak: string;
    };
    subtitle: string;
    samplePromptHeading: string;
    transcriptTitle: string;
    transcriptPlaceholder: string;
    interpretBtn: string;
    notSaved: string;
    editText: string;
    selectCustomerTitle: (n: number) => string;
    confirmNewCustomer: string;
    confirmAdd: string;
    confirmEntryTitle: string;
    selectCustomerPlaceholder: string;
    creditToggle: string;
    repaymentToggle: string;
    amountLabel: string;
    notesLabel: string;
    prevBal: string;
    plusCredit: string;
    minusPaid: string;
    newBal: string;
    advanceAck: string;
    answerTitle: string;
    savedTitle: string;
    openLedger: string;
    transactionsBtn: string;
    dashboardBtn: string;
    speakAgain: string;
    stopLabel: string;
    micAriaStart: string;
    micAriaStop: string;
    errSimulatedAi: string;
    errUnknownCommand: string;
    errTypeOrRecord: string;
    errInvalidCustName: string;
    errSelectCustomer: string;
    errInvalidAmount: string;
    errConfirmOverpay: string;
    errSimulatedSave: string;
    errSaveFailed: string;
    errCreateCustomerFailed: string;
    spokenCommandNotUnderstood: string;
    msgDailySummary: (credit: string, repaid: string, due: string) => string;
    msgTotalOutstanding: (count: number, due: string) => string;
    msgCustomerBalance: (name: string, balance: string) => string;
    msgCustomerHistory: (name: string, balance: string) => string;
    msgCustomerAdded: (name: string) => string;
    msgSavedEntry: (amount: string, type: 'CREDIT' | 'REPAYMENT', name: string, newBal: string) => string;
    micUnavailable: string;
    micPermissionDenied: string;
    micNotFound: string;
    sampleLabels: Record<string, { label: string; hint: string }>;
  };
  customers: {
    activeSummary: (count: number) => string;
    dueLabel: string;
    addParty: string;
    searchPlaceholder: string;
    filters: {
      all: string;
      due: string;
      settled: string;
      inactive: string;
    };
    emptyTitle: string;
    emptySearchDesc: (q: string) => string;
    emptyFilterDesc: string;
    emptyAction: string;
    inactiveTag: string;
    statusDue: string;
    statusAdvance: string;
    statusSettled: string;
  };
  ledger: {
    notFoundTitle: string;
    notFoundDesc: string;
    backToCustomers: string;
    editProfileAria: string;
    deactivateAria: string;
    reactivateAria: string;
    inactiveTag: string;
    netBalance: string;
    owesYou: string;
    advanceWithShop: string;
    settled: string;
    creditLabel: string;
    repaidLabel: string;
    giveCredit: string;
    gotPayment: string;
    historyTitle: string;
    balShort: string;
    openingBalance: string;
    editCustomerTitle: string;
    customerNameLabel: string;
    phoneLabel: string;
    notesLabel: string;
    reverseEntryTitle: string;
    reverseSubtitle: string;
    entryLabel: string;
    reasonLabel: string;
    reasonPlaceholder: string;
  };
  transactions: {
    addCredit: string;
    gotPayment: string;
    searchPlaceholder: string;
    filtersBtn: string;
    filtersCountBtn: (n: number) => string;
    types: {
      all: string;
      credit: string;
      repayment: string;
      reversal: string;
    };
    emptyTitle: string;
    emptyDesc: string;
    filterModalTitle: string;
    customerFilterLabel: string;
    allCustomers: string;
    dateRangeLabel: string;
    dates: {
      all: string;
      today: string;
      last7d: string;
      last30d: string;
    };
    entrySourceLabel: string;
    sources: {
      all: string;
      voice: string;
      manual: string;
    };
    minAmount: string;
    maxAmount: string;
    reverseTitle: string;
    reverseSubtitle: string;
    customerLabel: string;
    entryLabel: string;
    reasonLabel: string;
    reasonPlaceholder: string;
  };
  reports: {
    periods: {
      daily: string;
      weekly: string;
      monthly: string;
    };
    csvBtn: string;
    creditGiven: string;
    repayments: string;
    collectedSub: string;
    netChange: string;
    totalDue: string;
    partiesDueSub: (n: number) => string;
    chartTitle: string;
    creditLegend: string;
    paidLegend: string;
    tooltipCredit: string;
    tooltipRepayment: string;
    voiceEntries: string;
    manualEntries: string;
    highestOutstanding: string;
    allSettled: string;
    creditSummary: (credit: string, repaid: string) => string;
    buckets: {
      morning: string;
      afternoon: string;
      evening: string;
      night: string;
      week1: string;
      week2: string;
      week3: string;
      week4: string;
    };
  };
  settings: {
    shopProfileTitle: string;
    shopNameLabel: string;
    ownerNameLabel: string;
    categoryLabel: string;
    languageLabel: string;
    addressLabel: string;
    spokenRepliesTitle: string;
    spokenRepliesDesc: string;
    savedFeedback: string;
    saveSettingsBtn: string;
    auditTrailTitle: string;
    downloadZip: string;
    resetDemoBtn: string;
    logoutBtn: string;
    resetModalTitle: string;
    resetModalSubtitle: string;
    resetModalDesc: string;
    confirmResetBtn: string;
  };
  modals: {
    addCustomerTitle: string;
    addCustomerSubtitle: string;
    customerNameLabel: string;
    customerNamePlaceholder: string;
    mobileLabel: string;
    mobilePlaceholder: string;
    openingBalLabel: string;
    openingBalHelper: string;
    notesLabel: string;
    notesPlaceholder: string;
    duplicateWarning: string;
    addAnyway: string;
    createBtn: string;
    errNameMin: string;
    errInvalidOpeningBal: string;
    errDuplicateAck: string;
    errCreateCustomer: string;
    txnAddCreditTitle: string;
    txnRecordRepaymentTitle: string;
    txnSubtitle: string;
    creditTab: string;
    repaymentTab: string;
    selectCustomerLabel: string;
    selectCustomerOption: string;
    dueSuffix: string;
    amountLabel: string;
    amountPlaceholder: string;
    descLabel: string;
    descCreditPlaceholder: string;
    descRepayPlaceholder: string;
    dateLabel: string;
    prevBal: string;
    newBal: string;
    overpaymentMsg: (paid: string, due: string, excess: string) => string;
    overpaymentAck: string;
    saveCreditBtn: string;
    saveRepayBtn: string;
    errSelectCustomer: string;
    errValidAmount: string;
    errConfirmOverpay: string;
    errSaveTxn: string;
  };
  labels: {
    credit: string;
    repayment: string;
    reversal: string;
    voiceEntry: string;
    manualEntry: string;
    outstanding: string;
    settled: string;
    advance: string;
    today: string;
    yesterday: string;
    reverseBtnTitle: string;
  };
  errors: {
    shopRequired: string;
    shopNameEmpty: string;
    customerNameMin: string;
    openingNegative: string;
    customerNotFound: string;
    selectedCustomerNotFound: string;
    inactiveCustomerEntry: string;
    amountGreaterThanZero: string;
    txnNotFound: string;
    alreadyReversed: string;
    couldNotUpdateCustomer: string;
    couldNotSaveSettings: string;
    couldNotReverseTxn: string;
  };
}

const DICTIONARY: Record<LanguageCode, Translations> = {
  en: {
    brandName: 'KhataSaathi',
    tagline: 'Your Voice. Your Khata. Your Business.',
    common: {
      cancel: 'Cancel',
      save: 'Save',
      close: 'Close',
      edit: 'Edit',
      reset: 'Reset',
      reverse: 'Reverse',
      apply: 'Apply',
      clearAll: 'Clear All',
      retry: 'Retry',
      discard: 'Discard',
      confirmAndSave: 'Confirm & Save',
      noPhone: 'No phone',
      customer: 'Customer',
      unknown: 'Unknown',
      entriesCount: (n) => `${n} entries`,
    },
    categories: {
      'Kirana & Grocery': 'Kirana & Grocery',
      'Wholesale & Distributors': 'Wholesale & Distributors',
      'Hardware & Electrical': 'Hardware & Electrical',
      'Pharmacy & Medical': 'Pharmacy & Medical',
      'Stationery & Books': 'Stationery & Books',
      'Textiles & Apparel': 'Textiles & Apparel',
      Other: 'Other',
    },
    nav: {
      dashboard: 'Dashboard',
      voice: 'Voice',
      customers: 'Customers',
      transactions: 'Ledger',
      reports: 'Reports',
      settings: 'Settings',
      voiceAssistantTitle: 'Voice Assistant',
      customerKhataTitle: 'Customer Khata',
      goBack: 'Go back',
      settingsAria: 'Settings',
      homeAria: 'KhataSaathi Home',
      bottomNavAria: 'Mobile bottom navigation',
    },
    auth: {
      heroTitle: 'Voice-first digital khata for your shop.',
      heroSubtitle:
        'Record udhaar and repayments in English, Hindi, or Kannada—always confirmed before saving.',
      loginTab: 'Login',
      newShopTab: 'New Shop',
      ownerNameLabel: 'Owner Full Name',
      ownerNamePlaceholder: 'e.g. Anand Gupta',
      mobileLabel: 'Mobile Number',
      sendOtpBtn: 'Send Simulated OTP',
      otpSentTo: 'OTP sent to',
      demoOtpLabel: 'Demo OTP:',
      autoFill: 'Auto-fill',
      enterOtpLabel: 'Enter 4-Digit OTP',
      verifyBtn: 'Verify & Continue',
      changeNumber: 'Change number',
      resendIn: (sec) => `Resend in ${sec}s`,
      resendOtp: 'Resend OTP',
      demoShopBtn: 'Try Instant Demo Shop (Annapurna Kirana)',
      demoFooterNote: '100% browser-local demo · Sample data saved in localStorage',
      errNameRequired: 'Please enter your full name.',
      errInvalidMobile: 'Enter a valid 10-digit Indian mobile number.',
      errIncorrectOtp: (otp) => `Incorrect OTP. Enter ${otp} shown above.`,
    },
    setup: {
      title: 'Setup Your Shop',
      subtitle: 'Currency: INR (₹) · IST',
      shopNameLabel: 'Shop / Business Name *',
      shopNamePlaceholder: 'e.g. Annapurna Kirana & General Store',
      ownerNameLabel: 'Owner Name *',
      ownerNamePlaceholder: 'e.g. Anand Gupta',
      categoryLabel: 'Shop Category',
      languageLabel: 'Voice & UI Language',
      addressLabel: 'Shop Address (Optional)',
      addressPlaceholder: 'e.g. Gandhi Bazaar, Bengaluru',
      launchBtn: 'Launch Shop Khata',
      errRequired: 'Please complete required shop details.',
    },
    dashboard: {
      totalOutstanding: 'Total Outstanding',
      partiesCount: (n) => `${n} Parties`,
      todaysCredit: "Today's Credit",
      todaysRepayments: "Today's Repayments",
      voiceCtaTitle: 'Speak to update your Khata',
      voiceCtaExample: '“Ramesh ka 340 rupaye udhaar likho”',
      quickCredit: 'Credit',
      quickPayment: 'Payment',
      quickAddParty: 'Add Party',
      quickReports: 'Reports',
      sevenDayActivity: '7-Day Activity',
      creditLegend: 'Credit',
      paidLegend: 'Paid',
      tooltipCredit: 'Credit',
      tooltipRepaid: 'Repaid',
      recentTransactions: 'Recent Transactions',
      viewAll: 'View All',
    },
    voice: {
      demoBadge: 'Simulated Voice & AI Demo',
      voiceOn: 'Voice On',
      muted: 'Muted',
      errOn: 'Err On',
      errOff: 'Err Off',
      states: {
        listening: 'Listening',
        processingAudio: 'Processing Audio...',
        transcribing: 'Transcribing speech (Simulated STT)...',
        extracting: 'Extracting Khata Details...',
        saving: 'Saving to ledger...',
        tapToSpeak: 'Tap Blue Mic & Speak',
      },
      subtitle: 'English, Hindi & Kannada · Confirm before saving',
      samplePromptHeading: 'Tap a sample voice command:',
      transcriptTitle: 'Transcript (Editable)',
      transcriptPlaceholder: 'Type or edit command: "Ramesh ka 340 rupaye udhaar likho"',
      interpretBtn: 'Interpret Command',
      notSaved: 'Not Saved',
      editText: 'Edit Text',
      selectCustomerTitle: (n) => `Select Customer (${n} Matches)`,
      confirmNewCustomer: 'Confirm New Customer',
      confirmAdd: 'Confirm Add',
      confirmEntryTitle: 'Confirm Khata Entry',
      selectCustomerPlaceholder: 'Select customer...',
      creditToggle: 'Credit (+Udhaar)',
      repaymentToggle: 'Repayment (-Jama)',
      amountLabel: 'Amount (₹)',
      notesLabel: 'Notes',
      prevBal: 'Prev Bal',
      plusCredit: '+Credit',
      minusPaid: '-Paid',
      newBal: 'New Bal',
      advanceAck: 'Record excess payment as advance credit',
      answerTitle: 'Answer',
      savedTitle: 'Saved to Khata',
      openLedger: 'Open Ledger',
      transactionsBtn: 'Transactions',
      dashboardBtn: 'Dashboard',
      speakAgain: 'Speak Again',
      stopLabel: 'STOP',
      micAriaStart: 'Start voice recording',
      micAriaStop: 'Stop voice recording',
      errSimulatedAi:
        'Simulated AI/STT failure: Could not process this command. Edit transcript or retry.',
      errUnknownCommand:
        'Command not understood. Edit transcript or tap a sample command.',
      errTypeOrRecord: 'Please record or type a command.',
      errInvalidCustName: 'Enter a valid customer name.',
      errSelectCustomer: 'Select a customer first.',
      errInvalidAmount: 'Enter a valid ₹ amount greater than 0.',
      errConfirmOverpay: 'Confirm the advance checkbox below to save overpayment.',
      errSimulatedSave: 'Simulated save failure: Ledger rejected entry. Nothing was saved.',
      errSaveFailed: 'Failed to save transaction.',
      errCreateCustomerFailed: 'Could not create customer.',
      spokenCommandNotUnderstood: 'Command not understood. Please speak again.',
      msgDailySummary: (credit, repaid, due) =>
        `Today's credit: ${credit}, repayments: ${repaid}, total due: ${due}.`,
      msgTotalOutstanding: (count, due) =>
        `Total outstanding across ${count} customers is ${due}.`,
      msgCustomerBalance: (name, balance) => `${name}'s balance is ${balance}.`,
      msgCustomerHistory: (name, balance) => `${name} · Current balance ${balance}.`,
      msgCustomerAdded: (name) => `Customer ${name} added to your khata.`,
      msgSavedEntry: (amount, type, name, newBal) =>
        `Saved ${amount} ${type === 'CREDIT' ? 'credit' : 'repayment'} for ${name}. New balance: ${newBal}.`,
      micUnavailable:
        'Browser microphone recording is unavailable in this environment. You can still test with sample voice commands or typed transcripts.',
      micPermissionDenied:
        'Microphone permission was denied. Allow mic access in browser settings or use the sample voice prompts below.',
      micNotFound:
        'No active microphone detected. Use the sample voice prompts or type a transcript to test the pipeline.',
      sampleLabels: {
        sample_ramesh_credit: {
          label: 'Duplicate Name Demo (Ramesh)',
          hint: 'Triggers duplicate Ramesh selection & ₹340 credit',
        },
        sample_ramesh_kumar_exact: {
          label: 'Hindi Credit (Ramesh Kumar)',
          hint: 'Prev ₹500 + ₹340 credit = ₹840 new balance',
        },
        sample_suresh_repayment: {
          label: 'Hindi Repayment (Suresh)',
          hint: 'Records ₹500 repayment for Suresh Nair',
        },
        sample_mohan_decimal: {
          label: 'English Credit (Mohan)',
          hint: 'Tests decimal accuracy (₹1,250.50)',
        },
        sample_anita_balance: {
          label: 'Balance Check (Anita)',
          hint: 'Read-only customer balance lookup',
        },
        sample_daily_summary: {
          label: 'Daily Summary Query',
          hint: 'Read-only today credit, repayment & outstanding',
        },
        sample_kannada_credit: {
          label: 'Kannada Credit (Karim)',
          hint: 'Kannada voice command for Karim Sheikh',
        },
        sample_kannada_repayment: {
          label: 'Kannada Payment (Suresh)',
          hint: 'Kannada repayment command for Suresh Nair',
        },
        sample_create_customer: {
          label: 'Create Customer (Arjun)',
          hint: 'Creates a new customer record after confirmation',
        },
      },
    },
    customers: {
      activeSummary: (count) => `${count} active`,
      dueLabel: 'Due',
      addParty: 'Add Party',
      searchPlaceholder: 'Search name or phone...',
      filters: {
        all: 'All Active',
        due: 'Due Pending',
        settled: 'Settled',
        inactive: 'Inactive',
      },
      emptyTitle: 'No customers found',
      emptySearchDesc: (q) => `No customer matched "${q}".`,
      emptyFilterDesc: 'No customers under this filter.',
      emptyAction: 'Add Customer',
      inactiveTag: '· Inactive',
      statusDue: 'Due',
      statusAdvance: 'Advance',
      statusSettled: 'Settled',
    },
    ledger: {
      notFoundTitle: 'Customer not found',
      notFoundDesc: 'This customer profile may have been removed.',
      backToCustomers: 'Back to Customers',
      editProfileAria: 'Edit profile',
      deactivateAria: 'Deactivate',
      reactivateAria: 'Reactivate',
      inactiveTag: '· Inactive',
      netBalance: 'Net Balance',
      owesYou: 'Customer owes you',
      advanceWithShop: 'Advance with shop',
      settled: 'Settled',
      creditLabel: 'Credit:',
      repaidLabel: 'Repaid:',
      giveCredit: 'Give Credit',
      gotPayment: 'Got Payment',
      historyTitle: 'Ledger History',
      balShort: 'Bal',
      openingBalance: 'Opening Balance',
      editCustomerTitle: 'Edit Customer',
      customerNameLabel: 'Customer Name *',
      phoneLabel: 'Phone Number',
      notesLabel: 'Notes',
      reverseEntryTitle: 'Reverse Entry',
      reverseSubtitle: 'Preserves full audit trail',
      entryLabel: 'Entry:',
      reasonLabel: 'Reason (Optional)',
      reasonPlaceholder: 'e.g. Wrong amount',
    },
    transactions: {
      addCredit: 'Add Credit',
      gotPayment: 'Got Payment',
      searchPlaceholder: 'Search customer or item...',
      filtersBtn: 'Filters',
      filtersCountBtn: (n) => `Filters (${n})`,
      types: {
        all: 'All',
        credit: 'Credit',
        repayment: 'Repayment',
        reversal: 'Reversal',
      },
      emptyTitle: 'No matching entries',
      emptyDesc: 'Try clearing filters or record a new credit/repayment.',
      filterModalTitle: 'Filter Ledger',
      customerFilterLabel: 'Customer',
      allCustomers: 'All Customers',
      dateRangeLabel: 'Date Range',
      dates: {
        all: 'All Dates',
        today: 'Today',
        last7d: 'Last 7 Days',
        last30d: 'Last 30 Days',
      },
      entrySourceLabel: 'Entry Source',
      sources: {
        all: 'All',
        voice: 'Voice',
        manual: 'Manual',
      },
      minAmount: 'Min ₹',
      maxAmount: 'Max ₹',
      reverseTitle: 'Reverse Entry',
      reverseSubtitle: 'Preserves full audit history',
      customerLabel: 'Customer:',
      entryLabel: 'Entry:',
      reasonLabel: 'Reason (Optional)',
      reasonPlaceholder: 'e.g. Incorrect amount',
    },
    reports: {
      periods: {
        daily: 'Today',
        weekly: '7 Days',
        monthly: '30 Days',
      },
      csvBtn: 'CSV',
      creditGiven: 'Credit Given',
      repayments: 'Repayments',
      collectedSub: 'Collected',
      netChange: 'Net Change',
      totalDue: 'Total Due',
      partiesDueSub: (n) => `${n} parties due`,
      chartTitle: 'Credit vs Repayment',
      creditLegend: 'Credit',
      paidLegend: 'Paid',
      tooltipCredit: 'Credit',
      tooltipRepayment: 'Repayment',
      voiceEntries: 'Voice',
      manualEntries: 'Manual',
      highestOutstanding: 'Highest Outstanding Customers',
      allSettled: 'All customer balances are settled.',
      creditSummary: (credit, repaid) => `Credit ${credit} · Repaid ${repaid}`,
      buckets: {
        morning: 'Morning',
        afternoon: 'Afternoon',
        evening: 'Evening',
        night: 'Night',
        week1: 'Week 1',
        week2: 'Week 2',
        week3: 'Week 3',
        week4: 'Week 4',
      },
    },
    settings: {
      shopProfileTitle: 'Shop Profile',
      shopNameLabel: 'Shop Name *',
      ownerNameLabel: 'Owner Name *',
      categoryLabel: 'Category',
      languageLabel: 'Language',
      addressLabel: 'Address',
      spokenRepliesTitle: 'Spoken Voice Replies',
      spokenRepliesDesc: 'Read answers aloud',
      savedFeedback: 'Settings saved.',
      saveSettingsBtn: 'Save Settings',
      auditTrailTitle: 'Audit Trail',
      downloadZip: 'Download KhataSaathi_Frontend.zip',
      resetDemoBtn: 'Reset Demo',
      logoutBtn: 'Logout',
      resetModalTitle: 'Reset Demo Data?',
      resetModalSubtitle: 'Restores sample customers and transactions',
      resetModalDesc:
        'Your browser changes will be replaced with the default 10 sample customers and 20 transactions.',
      confirmResetBtn: 'Reset',
    },
    modals: {
      addCustomerTitle: 'Add New Customer',
      addCustomerSubtitle: 'Create a customer khata profile for your shop',
      customerNameLabel: 'Customer Name *',
      customerNamePlaceholder: 'e.g. Rajesh Verma',
      mobileLabel: 'Mobile Number (Optional)',
      mobilePlaceholder: 'e.g. 98450 12345',
      openingBalLabel: 'Opening Balance ₹ (Optional)',
      openingBalHelper: 'Previous pending balance before starting KhataSaathi',
      notesLabel: 'Notes (Optional)',
      notesPlaceholder: 'e.g. Block C, weekly groceries',
      duplicateWarning: 'Similar customer already exists in your khata:',
      addAnyway: 'This is a different customer, add anyway',
      createBtn: 'Create Customer',
      errNameMin: 'Please enter the customer full name (at least 2 characters).',
      errInvalidOpeningBal:
        'Opening balance must be a valid non-negative rupee amount (e.g. 500 or 250.50).',
      errDuplicateAck:
        'Possible duplicate customer detected below. Review or check "Add anyway" to continue.',
      errCreateCustomer: 'Could not create customer.',
      txnAddCreditTitle: 'Add Credit (Udhaar)',
      txnRecordRepaymentTitle: 'Record Repayment (Jama)',
      txnSubtitle: 'All entries update the customer ledger deterministically in paise',
      creditTab: 'Credit Given (+Udhaar)',
      repaymentTab: 'Repayment (-Jama)',
      selectCustomerLabel: 'Customer *',
      selectCustomerOption: 'Select customer...',
      dueSuffix: 'due',
      amountLabel: 'Amount (INR) *',
      amountPlaceholder: 'e.g. 500 or 340.50',
      descLabel: 'Description / Items',
      descCreditPlaceholder: 'e.g. Rice 5kg, milk & groceries',
      descRepayPlaceholder: 'e.g. Cash / UPI payment received',
      dateLabel: 'Date & Time',
      prevBal: 'Previous Balance',
      newBal: 'New Balance',
      overpaymentMsg: (paid, due, excess) =>
        `Repayment (${paid}) exceeds current outstanding (${due}). Recording this will create a ${excess} customer advance credit.`,
      overpaymentAck: 'Record excess as customer advance',
      saveCreditBtn: 'Save Credit',
      saveRepayBtn: 'Save Repayment',
      errSelectCustomer: 'Please select a customer.',
      errValidAmount: 'Enter a valid amount greater than ₹0 (e.g. 340 or 500.50).',
      errConfirmOverpay:
        'Repayment exceeds current due balance. Confirm advance policy checkbox below to proceed.',
      errSaveTxn: 'Failed to save transaction.',
    },
    labels: {
      credit: 'Credit',
      repayment: 'Payment',
      reversal: 'Reversal',
      voiceEntry: 'Voice',
      manualEntry: 'Manual',
      outstanding: 'Due',
      settled: 'Settled',
      advance: 'Advance',
      today: 'Today',
      yesterday: 'Yesterday',
      reverseBtnTitle: 'Reverse transaction',
    },
    errors: {
      shopRequired: 'Shop name and owner name are required.',
      shopNameEmpty: 'Shop name cannot be empty.',
      customerNameMin: 'Customer name must be at least 2 characters.',
      openingNegative: 'Opening balance cannot be negative.',
      customerNotFound: 'Customer not found.',
      selectedCustomerNotFound: 'Selected customer could not be found.',
      inactiveCustomerEntry: 'Cannot record entries for an inactive customer.',
      amountGreaterThanZero: 'Amount must be greater than ₹0.',
      txnNotFound: 'Transaction not found.',
      alreadyReversed: 'This transaction has already been reversed.',
      couldNotUpdateCustomer: 'Could not update customer.',
      couldNotSaveSettings: 'Could not save settings.',
      couldNotReverseTxn: 'Could not reverse transaction.',
    },
  },

  hi: {
    brandName: 'खातासाथी',
    tagline: 'आपकी आवाज़। आपका खाता। आपका व्यापार।',
    common: {
      cancel: 'रद्द करें',
      save: 'सेव करें',
      close: 'बंद करें',
      edit: 'बदलें',
      reset: 'रीसेट',
      reverse: 'वापस लें',
      apply: 'लागू करें',
      clearAll: 'सब हटाएं',
      retry: 'फिर कोशिश करें',
      discard: 'हटाएं',
      confirmAndSave: 'पुष्टि करें और सेव करें',
      noPhone: 'फ़ोन नंबर नहीं',
      customer: 'ग्राहक',
      unknown: 'अज्ञात',
      entriesCount: (n) => `${n} एंट्री`,
    },
    categories: {
      'Kirana & Grocery': 'किराना और जनरल स्टोर',
      'Wholesale & Distributors': 'थोक और डिस्ट्रीब्यूटर',
      'Hardware & Electrical': 'हार्डवेयर और इलेक्ट्रिकल',
      'Pharmacy & Medical': 'मेडिकल और फार्मेसी',
      'Stationery & Books': 'स्टेशनरी और किताबें',
      'Textiles & Apparel': 'कपड़ा और रेडीमेड',
      Other: 'अन्य दुकान',
    },
    nav: {
      dashboard: 'होम',
      voice: 'आवाज़',
      customers: 'ग्राहक',
      transactions: 'लेन-देन',
      reports: 'रिपोर्ट',
      settings: 'सेटिंग्स',
      voiceAssistantTitle: 'आवाज़ सहायक',
      customerKhataTitle: 'ग्राहक खाता',
      goBack: 'पीछे जाएं',
      settingsAria: 'सेटिंग्स',
      homeAria: 'खातासाथी होम',
      bottomNavAria: 'नीचे का नेविगेशन',
    },
    auth: {
      heroTitle: 'आपकी दुकान का आसान डिजिटल बोलने वाला खाता।',
      heroSubtitle:
        'हिन्दी, कन्नड़ या अंग्रेज़ी में उधार और जमा लिखें—सेव करने से पहले हमेशा आपकी पुष्टि के साथ।',
      loginTab: 'लॉगिन',
      newShopTab: 'नई दुकान',
      ownerNameLabel: 'मालिक का पूरा नाम',
      ownerNamePlaceholder: 'जैसे: आनंद गुप्ता',
      mobileLabel: 'मोबाइल नंबर',
      sendOtpBtn: 'डेमो OTP भेजें',
      otpSentTo: 'OTP भेजा गया:',
      demoOtpLabel: 'डेमो OTP:',
      autoFill: 'अपने-आप भरें',
      enterOtpLabel: '4 अंकों का OTP लिखें',
      verifyBtn: 'जाँचें और आगे बढ़ें',
      changeNumber: 'नंबर बदलें',
      resendIn: (sec) => `${sec} सेकंड में फिर भेजें`,
      resendOtp: 'OTP फिर भेजें',
      demoShopBtn: 'तुरंत डेमो दुकान चलाएं (अन्नपूर्णा किराना)',
      demoFooterNote: '100% ब्राउज़र-लोकल डेमो · डेटा आपके फ़ोन में सेव रहेगा',
      errNameRequired: 'कृपया अपना पूरा नाम लिखें।',
      errInvalidMobile: 'कृपया 10 अंकों का सही मोबाइल नंबर डालें।',
      errIncorrectOtp: (otp) => `गलत OTP। ऊपर दिया गया ${otp} डालें।`,
    },
    setup: {
      title: 'अपनी दुकान सेट करें',
      subtitle: 'मुद्रा: रुपये (₹) · IST',
      shopNameLabel: 'दुकान का नाम *',
      shopNamePlaceholder: 'जैसे: अन्नपूर्णा किराना स्टोर',
      ownerNameLabel: 'मालिक का नाम *',
      ownerNamePlaceholder: 'जैसे: आनंद गुप्ता',
      categoryLabel: 'दुकान की श्रेणी',
      languageLabel: 'आवाज़ और ऐप की भाषा',
      addressLabel: 'दुकान का पता (वैकल्पिक)',
      addressPlaceholder: 'जैसे: गांधी बाज़ार, बेंगलुरु',
      launchBtn: 'दुकान खाता शुरू करें',
      errRequired: 'कृपया दुकान की जरूरी जानकारी भरें।',
    },
    dashboard: {
      totalOutstanding: 'कुल बकाया राशि',
      partiesCount: (n) => `${n} ग्राहक`,
      todaysCredit: 'आज का उधार',
      todaysRepayments: 'आज का जमा',
      voiceCtaTitle: 'बोलकर अपना खाता लिखें',
      voiceCtaExample: '“रमेश का 340 रुपये उधार लिखो”',
      quickCredit: 'उधार दें',
      quickPayment: 'जमा लिखें',
      quickAddParty: 'नया ग्राहक',
      quickReports: 'रिपोर्ट',
      sevenDayActivity: 'पिछले 7 दिन का हिसाब',
      creditLegend: 'उधार',
      paidLegend: 'जमा',
      tooltipCredit: 'उधार',
      tooltipRepaid: 'जमा',
      recentTransactions: 'हाल के लेन-देन',
      viewAll: 'सभी देखें',
    },
    voice: {
      demoBadge: 'डेमो आवाज़ और AI प्रोसेसिंग',
      voiceOn: 'आवाज़ चालू',
      muted: 'म्यूट',
      errOn: 'एरर टेस्ट चालू',
      errOff: 'एरर टेस्ट बंद',
      states: {
        listening: 'सुन रहे हैं',
        processingAudio: 'आवाज़ प्रोसेस हो रही है...',
        transcribing: 'आवाज़ को लिखा जा रहा है (डेमो)...',
        extracting: 'खाते की जानकारी समझ रहे हैं...',
        saving: 'खाते में सेव हो रहा है...',
        tapToSpeak: 'नीला माइक दबाएं और बोलें',
      },
      subtitle: 'हिन्दी, कन्नड़ और अंग्रेज़ी · सेव करने से पहले पक्का करें',
      samplePromptHeading: 'तुरंत टेस्ट करने के लिए बोलने का उदाहरण चुनें:',
      transcriptTitle: 'लिखा गया वाक्य (बदल सकते हैं)',
      transcriptPlaceholder: 'वाक्य लिखें या सुधारें: "Ramesh ka 340 rupaye udhaar likho"',
      interpretBtn: 'वाक्य समझें',
      notSaved: 'सेव नहीं हुआ',
      editText: 'वाक्य सुधारें',
      selectCustomerTitle: (n) => `ग्राहक चुनें (${n} नाम मिले)`,
      confirmNewCustomer: 'नया ग्राहक जोड़ने की पुष्टि',
      confirmAdd: 'जोड़ें',
      confirmEntryTitle: 'खाता एंट्री पक्की करें',
      selectCustomerPlaceholder: 'ग्राहक चुनें...',
      creditToggle: 'उधार दिया (+उधार)',
      repaymentToggle: 'जमा मिला (-जमा)',
      amountLabel: 'राशि (₹)',
      notesLabel: 'विवरण / सामान',
      prevBal: 'पिछला बकाया',
      plusCredit: '+उधार',
      minusPaid: '-जमा',
      newBal: 'नया बकाया',
      advanceAck: 'बची हुई अतिरिक्त राशि को ग्राहक के अग्रिम (एडवांस) में जोड़ें',
      answerTitle: 'खाता जवाब',
      savedTitle: 'खाते में सेव हो गया',
      openLedger: 'खाता खोलें',
      transactionsBtn: 'सभी लेन-देन',
      dashboardBtn: 'डैशबोर्ड',
      speakAgain: 'फिर से बोलें',
      stopLabel: 'रोकें',
      micAriaStart: 'बोलना शुरू करें',
      micAriaStop: 'रिकॉर्डिंग रोकें',
      errSimulatedAi:
        'डेमो एरर: यह बात समझ नहीं आई। ऊपर लिखा वाक्य सुधारें या फिर कोशिश करें।',
      errUnknownCommand:
        'कमांड समझ नहीं आया। वाक्य सुधारें या नीचे दिए उदाहरण पर टैप करें।',
      errTypeOrRecord: 'कृपया माइक से बोलें या वाक्य टाइप करें।',
      errInvalidCustName: 'सही ग्राहक नाम लिखें।',
      errSelectCustomer: 'कृपया पहले ग्राहक चुनें।',
      errInvalidAmount: '₹0 से अधिक की सही राशि डालें।',
      errConfirmOverpay: 'अतिरिक्त जमा सेव करने के लिए नीचे बॉक्स पर टिक करें।',
      errSimulatedSave: 'डेमो सेव एरर: एंट्री सेव नहीं हुई।',
      errSaveFailed: 'लेन-देन सेव नहीं हो पाया।',
      errCreateCustomerFailed: 'ग्राहक नहीं जुड़ पाया।',
      spokenCommandNotUnderstood: 'बात समझ नहीं आई। कृपया दोबारा बोलें।',
      msgDailySummary: (credit, repaid, due) =>
        `आज का उधार ${credit}, आज का जमा ${repaid} और कुल बकाया ${due} है।`,
      msgTotalOutstanding: (count, due) =>
        `${count} ग्राहकों पर कुल बकाया ${due} है।`,
      msgCustomerBalance: (name, balance) => `${name} का बकाया ${balance} है।`,
      msgCustomerHistory: (name, balance) => `${name} · मौजूदा बकाया ${balance}।`,
      msgCustomerAdded: (name) => `ग्राहक ${name} आपके खाते में जुड़ गया है।`,
      msgSavedEntry: (amount, type, name, newBal) =>
        `${name} के लिए ${amount} का ${type === 'CREDIT' ? 'उधार' : 'जमा'} सेव हो गया। नया बकाया: ${newBal}।`,
      micUnavailable:
        'इस ब्राउज़र में माइक्रोफ़ोन उपलब्ध नहीं है। आप नीचे दिए उदाहरण बटन दबाकर या वाक्य टाइप करके टेस्ट कर सकते हैं।',
      micPermissionDenied:
        'माइक्रोफ़ोन की अनुमति नहीं मिली। ब्राउज़र सेटिंग में अनुमति दें या नीचे उदाहरण का उपयोग करें।',
      micNotFound:
        'कोई सक्रिय माइक्रोफ़ोन नहीं मिला। टेस्ट करने के लिए नीचे उदाहरण चुनें या वाक्य टाइप करें।',
      sampleLabels: {
        sample_ramesh_credit: {
          label: 'एक जैसे नाम (रमेश - ₹340 उधार)',
          hint: 'रमेश चुनने और ₹340 उधार का डेमो',
        },
        sample_ramesh_kumar_exact: {
          label: 'रमेश कुमार ₹340 उधार',
          hint: 'पिछला ₹500 + ₹340 = ₹840 नया बकाया',
        },
        sample_suresh_repayment: {
          label: 'सुरेश ने ₹500 वापस दिए',
          hint: 'सुरेश नायर का ₹500 जमा दर्ज करें',
        },
        sample_mohan_decimal: {
          label: 'मोहन ₹1,250.50 उधार (अंग्रेज़ी)',
          hint: 'पैसे तक सटीक हिसाब का टेस्ट',
        },
        sample_anita_balance: {
          label: 'अनीता का बकाया पूछें',
          hint: 'सिर्फ़ बकाया देखने का कमांड',
        },
        sample_daily_summary: {
          label: 'आज का हिसाब बताओ',
          hint: 'आज का उधार, जमा और कुल बकाया सुनें',
        },
        sample_kannada_credit: {
          label: 'करीम ₹250 उधार (कन्नड़)',
          hint: 'कन्नड़ आवाज़ कमांड का टेस्ट',
        },
        sample_kannada_repayment: {
          label: 'सुरेश ₹500 जमा (कन्नड़)',
          hint: 'कन्नड़ जमा कमांड का टेस्ट',
        },
        sample_create_customer: {
          label: 'नया ग्राहक अर्जुन मेहता जोड़ें',
          hint: 'पुष्टि के बाद नया ग्राहक बनाएं',
        },
      },
    },
    customers: {
      activeSummary: (count) => `${count} सक्रिय ग्राहक`,
      dueLabel: 'कुल बकाया',
      addParty: 'नया ग्राहक',
      searchPlaceholder: 'नाम या फ़ोन नंबर से खोजें...',
      filters: {
        all: 'सभी सक्रिय',
        due: 'बकाया बाकी',
        settled: 'हिसाब पूरा',
        inactive: 'निष्क्रिय',
      },
      emptyTitle: 'कोई ग्राहक नहीं मिला',
      emptySearchDesc: (q) => `"${q}" से कोई ग्राहक नहीं मिला।`,
      emptyFilterDesc: 'इस फ़िल्टर में कोई ग्राहक नहीं है।',
      emptyAction: 'ग्राहक जोड़ें',
      inactiveTag: '· निष्क्रिय',
      statusDue: 'बकाया',
      statusAdvance: 'एडवांस',
      statusSettled: 'हिसाब साफ',
    },
    ledger: {
      notFoundTitle: 'ग्राहक नहीं मिला',
      notFoundDesc: 'यह ग्राहक खाता उपलब्ध नहीं है।',
      backToCustomers: 'ग्राहक सूची पर जाएं',
      editProfileAria: 'जानकारी बदलें',
      deactivateAria: 'निष्क्रिय करें',
      reactivateAria: 'फिर सक्रिय करें',
      inactiveTag: '· निष्क्रिय',
      netBalance: 'शुद्ध बकाया',
      owesYou: 'ग्राहक को देना है',
      advanceWithShop: 'दुकान के पास एडवांस',
      settled: 'हिसाब बराबर',
      creditLabel: 'कुल उधार:',
      repaidLabel: 'कुल जमा:',
      giveCredit: 'उधार लिखें',
      gotPayment: 'जमा मिला',
      historyTitle: 'लेन-देन इतिहास',
      balShort: 'बकाया',
      openingBalance: 'शुरुआती बकाया',
      editCustomerTitle: 'ग्राहक जानकारी बदलें',
      customerNameLabel: 'ग्राहक का नाम *',
      phoneLabel: 'फ़ोन नंबर',
      notesLabel: 'नोट्स',
      reverseEntryTitle: 'एंट्री वापस लें (रिवर्स)',
      reverseSubtitle: 'पूरा ऑडिट रिकॉर्ड सुरक्षित रहेगा',
      entryLabel: 'एंट्री:',
      reasonLabel: 'कारण (वैकल्पिक)',
      reasonPlaceholder: 'जैसे: गलत राशि लिखी गई',
    },
    transactions: {
      addCredit: 'उधार जोड़ें',
      gotPayment: 'जमा मिला',
      searchPlaceholder: 'ग्राहक या सामान खोजें...',
      filtersBtn: 'फ़िल्टर',
      filtersCountBtn: (n) => `फ़िल्टर (${n})`,
      types: {
        all: 'सभी',
        credit: 'उधार',
        repayment: 'जमा',
        reversal: 'रिवर्स',
      },
      emptyTitle: 'कोई लेन-देन नहीं मिला',
      emptyDesc: 'फ़िल्टर साफ करें या नया उधार/जमा दर्ज करें।',
      filterModalTitle: 'लेन-देन फ़िल्टर करें',
      customerFilterLabel: 'ग्राहक',
      allCustomers: 'सभी ग्राहक',
      dateRangeLabel: 'तारीख',
      dates: {
        all: 'सभी तारीखें',
        today: 'आज',
        last7d: 'पिछले 7 दिन',
        last30d: 'पिछले 30 दिन',
      },
      entrySourceLabel: 'एंट्री का तरीका',
      sources: {
        all: 'सभी',
        voice: 'आवाज़',
        manual: 'मैनुअल',
      },
      minAmount: 'कम से कम ₹',
      maxAmount: 'ज़्यादा से ज़्यादा ₹',
      reverseTitle: 'एंट्री रिवर्स करें',
      reverseSubtitle: 'पूरा हिसाब रिकॉर्ड सुरक्षित रहेगा',
      customerLabel: 'ग्राहक:',
      entryLabel: 'एंट्री:',
      reasonLabel: 'कारण (वैकल्पिक)',
      reasonPlaceholder: 'जैसे: गलत राशि',
    },
    reports: {
      periods: {
        daily: 'आज',
        weekly: '7 दिन',
        monthly: '30 दिन',
      },
      csvBtn: 'CSV',
      creditGiven: 'दिया गया उधार',
      repayments: 'मिला जमा',
      collectedSub: 'वसूली',
      netChange: 'शुद्ध बदलाव',
      totalDue: 'कुल बकाया',
      partiesDueSub: (n) => `${n} ग्राहकों पर बाकी`,
      chartTitle: 'उधार बनाम जमा',
      creditLegend: 'उधार',
      paidLegend: 'जमा',
      tooltipCredit: 'उधार',
      tooltipRepayment: 'जमा',
      voiceEntries: 'आवाज़ से',
      manualEntries: 'मैनुअल से',
      highestOutstanding: 'सबसे ज़्यादा बकाया वाले ग्राहक',
      allSettled: 'सभी ग्राहकों का हिसाब चुकता है।',
      creditSummary: (credit, repaid) => `उधार ${credit} · जमा ${repaid}`,
      buckets: {
        morning: 'सुबह',
        afternoon: 'दोपहर',
        evening: 'शाम',
        night: 'रात',
        week1: 'हफ्ता 1',
        week2: 'हफ्ता 2',
        week3: 'हफ्ता 3',
        week4: 'हफ्ता 4',
      },
    },
    settings: {
      shopProfileTitle: 'दुकान की जानकारी',
      shopNameLabel: 'दुकान का नाम *',
      ownerNameLabel: 'मालिक का नाम *',
      categoryLabel: 'दुकान श्रेणी',
      languageLabel: 'भाषा चुनें',
      addressLabel: 'पता',
      spokenRepliesTitle: 'आवाज़ में जवाब सुनें',
      spokenRepliesDesc: 'बोलकर उत्तर सुनाएं',
      savedFeedback: 'सेटिंग्स सेव हो गईं।',
      saveSettingsBtn: 'सेटिंग्स सेव करें',
      auditTrailTitle: 'ऑडिट लॉग (इतिहास)',
      downloadZip: 'KhataSaathi_Frontend.zip डाउनलोड करें',
      resetDemoBtn: 'डेमो रीसेट',
      logoutBtn: 'लॉगआउट',
      resetModalTitle: 'डेमो डेटा रीसेट करें?',
      resetModalSubtitle: 'शुरुआती ग्राहक और लेन-देन वापस आएंगे',
      resetModalDesc:
        'आपके द्वारा किए गए बदलाव हट जाएंगे और डिफ़ॉल्ट 10 ग्राहक व 20 लेन-देन वापस आ जाएंगे।',
      confirmResetBtn: 'रीसेट करें',
    },
    modals: {
      addCustomerTitle: 'नया ग्राहक जोड़ें',
      addCustomerSubtitle: 'अपनी दुकान के लिए ग्राहक खाता बनाएं',
      customerNameLabel: 'ग्राहक का नाम *',
      customerNamePlaceholder: 'जैसे: राजेश वर्मा',
      mobileLabel: 'मोबाइल नंबर (वैकल्पिक)',
      mobilePlaceholder: 'जैसे: 98450 12345',
      openingBalLabel: 'पुराना बकाया ₹ (वैकल्पिक)',
      openingBalHelper: 'खातासाथी शुरू करने से पहले का बाकी पैसा',
      notesLabel: 'नोट्स (वैकल्पिक)',
      notesPlaceholder: 'जैसे: ब्लॉक C, हफ्ते का राशन',
      duplicateWarning: 'इस नाम या नंबर जैसा ग्राहक पहले से मौजूद है:',
      addAnyway: 'यह अलग ग्राहक है, फिर भी जोड़ें',
      createBtn: 'ग्राहक बनाएं',
      errNameMin: 'कृपया ग्राहक का पूरा नाम लिखें (कम से कम 2 अक्षर)।',
      errInvalidOpeningBal: 'पुराना बकाया सही रुपये में लिखें (जैसे 500 या 250.50)।',
      errDuplicateAck: 'नीचे मिलता-जुलता ग्राहक दिखा है। जांचें या "फिर भी जोड़ें" पर टिक करें।',
      errCreateCustomer: 'ग्राहक नहीं बन सका।',
      txnAddCreditTitle: 'उधार जोड़ें (+उधार)',
      txnRecordRepaymentTitle: 'जमा लिखें (-जमा)',
      txnSubtitle: 'हर एंट्री से ग्राहक का बकाया तुरंत अपडेट होता है',
      creditTab: 'उधार दिया (+उधार)',
      repaymentTab: 'जमा मिला (-जमा)',
      selectCustomerLabel: 'ग्राहक *',
      selectCustomerOption: 'ग्राहक चुनें...',
      dueSuffix: 'बकाया',
      amountLabel: 'राशि (₹) *',
      amountPlaceholder: 'जैसे: 500 या 340.50',
      descLabel: 'विवरण / सामान',
      descCreditPlaceholder: 'जैसे: चावल 5 किलो, दूध और किराना',
      descRepayPlaceholder: 'जैसे: नकद / UPI से मिला',
      dateLabel: 'तारीख और समय',
      prevBal: 'पिछला बकाया',
      newBal: 'नया बकाया',
      overpaymentMsg: (paid, due, excess) =>
        `जमा राशि (${paid}) मौजूदा बकाया (${due}) से अधिक है। सेव करने पर ${excess} ग्राहक के एडवांस में जुड़ जाएगा।`,
      overpaymentAck: 'अतिरिक्त राशि को एडवांस के रूप में लिखें',
      saveCreditBtn: 'उधार सेव करें',
      saveRepayBtn: 'जमा सेव करें',
      errSelectCustomer: 'कृपया एक ग्राहक चुनें।',
      errValidAmount: '₹0 से अधिक की सही राशि लिखें (जैसे 340 या 500.50)।',
      errConfirmOverpay: 'जमा राशि बकाया से अधिक है। आगे बढ़ने के लिए नीचे बॉक्स पर टिक करें।',
      errSaveTxn: 'लेन-देन सेव नहीं हो पाया।',
    },
    labels: {
      credit: 'उधार',
      repayment: 'जमा',
      reversal: 'रिवर्स',
      voiceEntry: 'आवाज़',
      manualEntry: 'मैनुअल',
      outstanding: 'बकाया',
      settled: 'हिसाब साफ',
      advance: 'एडवांस',
      today: 'आज',
      yesterday: 'कल',
      reverseBtnTitle: 'लेन-देन वापस लें',
    },
    errors: {
      shopRequired: 'दुकान का नाम और मालिक का नाम आवश्यक है।',
      shopNameEmpty: 'दुकान का नाम खाली नहीं हो सकता।',
      customerNameMin: 'ग्राहक का नाम कम से कम 2 अक्षरों का होना चाहिए।',
      openingNegative: 'शुरुआती बकाया माइनस में नहीं हो सकता।',
      customerNotFound: 'ग्राहक नहीं मिला।',
      selectedCustomerNotFound: 'चुना गया ग्राहक नहीं मिला।',
      inactiveCustomerEntry: 'निष्क्रिय ग्राहक के खाते में एंट्री नहीं कर सकते।',
      amountGreaterThanZero: 'राशि ₹0 से ज़्यादा होनी चाहिए।',
      txnNotFound: 'लेन-देन नहीं मिला।',
      alreadyReversed: 'यह लेन-देन पहले ही रिवर्स हो चुका है।',
      couldNotUpdateCustomer: 'ग्राहक की जानकारी अपडेट नहीं हो सकी।',
      couldNotSaveSettings: 'सेटिंग्स सेव नहीं हो सकीं।',
      couldNotReverseTxn: 'लेन-देन रिवर्स नहीं हो सका।',
    },
  },

  kn: {
    brandName: 'ಖಾತಾಸಾಥಿ',
    tagline: 'ನಿಮ್ಮ ಧ್ವನಿ. ನಿಮ್ಮ ಖಾತಾ. ನಿಮ್ಮ ವ್ಯಾಪಾರ.',
    common: {
      cancel: 'ರದ್ದು',
      save: 'ಉಳಿಸಿ',
      close: 'ಮುಚ್ಚಿ',
      edit: 'ತಿದ್ದುಪಡಿ',
      reset: 'ಮರುಹೊಂದಿಸಿ',
      reverse: 'ಹಿಂಪಡೆಯಿರಿ',
      apply: 'ಅನ್ವಯಿಸಿ',
      clearAll: 'ಎಲ್ಲಾ ತೆರವುಗೊಳಿಸಿ',
      retry: 'ಮತ್ತೆ ಪ್ರಯತ್ನಿಸಿ',
      discard: 'ಬಿಡಿ',
      confirmAndSave: 'ಖಚಿತಪಡಿಸಿ ಉಳಿಸಿ',
      noPhone: 'ಫೋನ್ ಇಲ್ಲ',
      customer: 'ಗ್ರಾಹಕ',
      unknown: 'ಅಜ್ಞಾತ',
      entriesCount: (n) => `${n} ದಾಖಲೆಗಳು`,
    },
    categories: {
      'Kirana & Grocery': 'ಕಿರಾಣಿ ಮತ್ತು ದಿನಸಿ ಅಂಗಡಿ',
      'Wholesale & Distributors': 'ಸಗಟು ಮತ್ತು ವಿತರಕರು',
      'Hardware & Electrical': 'ಹಾರ್ಡ್‌ವೇರ್ ಮತ್ತು ಎಲೆಕ್ಟ್ರಿಕಲ್',
      'Pharmacy & Medical': 'ಮೆಡಿಕಲ್ ಮತ್ತು ಔಷಧಾಲಯ',
      'Stationery & Books': 'ಸ್ಟೇಷನರಿ ಮತ್ತು ಪುಸ್ತಕಗಳು',
      'Textiles & Apparel': 'ಬಟ್ಟೆ ಮತ್ತು ವಸ್ತ್ರಗಳು',
      Other: 'ಇತರೆ',
    },
    nav: {
      dashboard: 'ಮುಖಪುಟ',
      voice: 'ಧ್ವನಿ',
      customers: 'ಗ್ರಾಹಕರು',
      transactions: 'ವಹಿವಾಟು',
      reports: 'ವರದಿ',
      settings: 'ಸೆಟ್ಟಿಂಗ್ಸ್',
      voiceAssistantTitle: 'ಧ್ವನಿ ಸಹಾಯಕ',
      customerKhataTitle: 'ಗ್ರಾಹಕ ಖಾತಾ',
      goBack: 'ಹಿಂದಕ್ಕೆ',
      settingsAria: 'ಸೆಟ್ಟಿಂಗ್‌ಗಳು',
      homeAria: 'ಖಾತಾಸಾಥಿ ಮುಖಪುಟ',
      bottomNavAria: 'ಕೆಳಗಿನ ನ್ಯಾವಿಗೇಷನ್',
    },
    auth: {
      heroTitle: 'ನಿಮ್ಮ ಅಂಗಡಿಗೆ ಧ್ವನಿ-ಆಧಾರಿತ ಡಿಜಿಟಲ್ ಖಾತಾ.',
      heroSubtitle:
        'ಕನ್ನಡ, ಹಿಂದಿ ಅಥವಾ ಇಂಗ್ಲಿಷ್‌ನಲ್ಲಿ ಉದ್ರಿ ಮತ್ತು ಪಾವತಿಗಳನ್ನು ಬರೆಯಿರಿ—ಉಳಿಸುವ ಮೊದಲು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಿ.',
      loginTab: 'ಲಾಗಿನ್',
      newShopTab: 'ಹೊಸ ಅಂಗಡಿ',
      ownerNameLabel: 'ಮಾಲೀಕರ ಪೂರ್ಣ ಹೆಸರು',
      ownerNamePlaceholder: 'ಉದಾ: ಆನಂದ್ ಗುಪ್ತಾ',
      mobileLabel: 'ಮೊಬೈಲ್ ಸಂಖ್ಯೆ',
      sendOtpBtn: 'ಡೆಮೋ OTP ಕಳುಹಿಸಿ',
      otpSentTo: 'OTP ಕಳುಹಿಸಲಾಗಿದೆ:',
      demoOtpLabel: 'ಡೆಮೋ OTP:',
      autoFill: 'ಸ್ವಯಂ ಭರ್ತಿ',
      enterOtpLabel: '4 ಅಂಕಿಯ OTP ನಮೂದಿಸಿ',
      verifyBtn: 'ಪರಿಶೀಲಿಸಿ ಮುಂದುವರಿಸಿ',
      changeNumber: 'ಸಂಖ್ಯೆ ಬದಲಿಸಿ',
      resendIn: (sec) => `${sec} ಸೆಕೆಂಡ್‌ನಲ್ಲಿ ಮತ್ತೆ ಕಳುಹಿಸಿ`,
      resendOtp: 'OTP ಮತ್ತೆ ಕಳುಹಿಸಿ',
      demoShopBtn: 'ತಕ್ಷಣ ಡೆಮೋ ಅಂಗಡಿ ತೆರೆಯಿರಿ (ಅನ್ನಪೂರ್ಣ ಕಿರಾಣಿ)',
      demoFooterNote: '100% ಬ್ರೌಸರ್-ಲೋಕಲ್ ಡೆಮೋ · ಮಾಹಿತಿ ನಿಮ್ಮ ಫೋನ್‌ನಲ್ಲಿ ಉಳಿಯುತ್ತದೆ',
      errNameRequired: 'ದಯವಿಟ್ಟು ನಿಮ್ಮ ಪೂರ್ಣ ಹೆಸರನ್ನು ನಮೂದಿಸಿ.',
      errInvalidMobile: 'ದಯವಿಟ್ಟು ಸರಿಯಾದ 10 ಅಂಕಿಯ ಮೊಬೈಲ್ ಸಂಖ್ಯೆಯನ್ನು ನಮೂದಿಸಿ.',
      errIncorrectOtp: (otp) => `ತಪ್ಪಾದ OTP. ಮೇಲೆ ತೋರಿಸಿದ ${otp} ನಮೂದಿಸಿ.`,
    },
    setup: {
      title: 'ನಿಮ್ಮ ಅಂಗಡಿಯನ್ನು ಸೆಟ್ ಮಾಡಿ',
      subtitle: 'ಕರೆನ್ಸಿ: INR (₹) · IST',
      shopNameLabel: 'ಅಂಗಡಿಯ ಹೆಸರು *',
      shopNamePlaceholder: 'ಉದಾ: ಅನ್ನಪೂರ್ಣ ಕಿರಾಣಿ ಸ್ಟೋರ್',
      ownerNameLabel: 'ಮಾಲೀಕರ ಹೆಸರು *',
      ownerNamePlaceholder: 'ಉದಾ: ಆನಂದ್ ಗುಪ್ತಾ',
      categoryLabel: 'ಅಂಗಡಿ ವಿಭಾಗ',
      languageLabel: 'ಧ್ವನಿ ಮತ್ತು ಆ್ಯಪ್ ಭಾಷೆ',
      addressLabel: 'ಅಂಗಡಿ ವಿಳಾಸ (ಐಚ್ಛಿಕ)',
      addressPlaceholder: 'ಉದಾ: ಗಾಂಧಿ ಬಜಾರ್, ಬೆಂಗಳೂರು',
      launchBtn: 'ಅಂಗಡಿ ಖಾತಾ ಪ್ರಾರಂಭಿಸಿ',
      errRequired: 'ದಯವಿಟ್ಟು ಅಗತ್ಯವಿರುವ ಅಂಗಡಿ ವಿವರಗಳನ್ನು ಭರ್ತಿ ಮಾಡಿ.',
    },
    dashboard: {
      totalOutstanding: 'ಒಟ್ಟು ಬಾಕಿ ಮೊತ್ತ',
      partiesCount: (n) => `${n} ಗ್ರಾಹಕರು`,
      todaysCredit: 'ಇಂದಿನ ಉದ್ರಿ',
      todaysRepayments: 'ಇಂದಿನ ಪಾವತಿ',
      voiceCtaTitle: 'ಮಾತನಾಡಿ ನಿಮ್ಮ ಖಾತಾ ಬರೆಯಿರಿ',
      voiceCtaExample: '“ರಮೇಶ್ ಅವರ 340 ರೂಪಾಯಿ ಉದ್ರಿ ಬರೆಯಿರಿ”',
      quickCredit: 'ಉದ್ರಿ',
      quickPayment: 'ಪಾವತಿ',
      quickAddParty: 'ಹೊಸ ಗ್ರಾಹಕ',
      quickReports: 'ವರದಿ',
      sevenDayActivity: '7 ದಿನಗಳ ವಹಿವಾಟು',
      creditLegend: 'ಉದ್ರಿ',
      paidLegend: 'ಪಾವತಿ',
      tooltipCredit: 'ಉದ್ರಿ',
      tooltipRepaid: 'ಪಾವತಿ',
      recentTransactions: 'ಇತ್ತೀಚಿನ ವಹಿವಾಟುಗಳು',
      viewAll: 'ಎಲ್ಲಾ ನೋಡಿ',
    },
    voice: {
      demoBadge: 'ಸಿಮ್ಯುಲೇಟೆಡ್ ಧ್ವನಿ ಮತ್ತು AI ಡೆಮೋ',
      voiceOn: 'ಧ್ವನಿ ಆನ್',
      muted: 'ಮ್ಯೂಟ್',
      errOn: 'ದೋಷ ಆನ್',
      errOff: 'ದೋಷ ಆಫ್',
      states: {
        listening: 'ಕೇಳುತ್ತಿದ್ದೇವೆ',
        processingAudio: 'ಧ್ವನಿ ಪ್ರಕ್ರಿಯೆಯಲ್ಲಿದೆ...',
        transcribing: 'ಮಾತನ್ನು ಬರೆಯಲಾಗುತ್ತಿದೆ (ಡೆಮೋ)...',
        extracting: 'ಖಾತಾ ವಿವರಗಳನ್ನು ತೆಗೆಯಲಾಗುತ್ತಿದೆ...',
        saving: 'ಖಾತಾದಲ್ಲಿ ಉಳಿಸಲಾಗುತ್ತಿದೆ...',
        tapToSpeak: 'ನೀಲಿ ಮೈಕ್ ಒತ್ತಿ ಮಾತನಾಡಿ',
      },
      subtitle: 'ಕನ್ನಡ, ಹಿಂದಿ ಮತ್ತು ಇಂಗ್ಲಿಷ್ · ಉಳಿಸುವ ಮೊದಲು ಖಚಿತಪಡಿಸಿ',
      samplePromptHeading: 'ಪರೀಕ್ಷಿಸಲು ಮಾದರಿ ಧ್ವನಿ ಆಜ್ಞೆಯನ್ನು ಒತ್ತಿರಿ:',
      transcriptTitle: 'ಬರೆದ ವಾಕ್ಯ (ತಿದ್ದುಪಡಿ ಮಾಡಬಹುದು)',
      transcriptPlaceholder: 'ವಾಕ್ಯ ಬರೆಯಿರಿ: "Karim avara 250 rupayi udri bari"',
      interpretBtn: 'ಆಜ್ಞೆಯನ್ನು ಅರ್ಥೈಸಿ',
      notSaved: 'ಉಳಿಸಲಾಗಿಲ್ಲ',
      editText: 'ಪಠ್ಯ ತಿದ್ದುಪಡಿ',
      selectCustomerTitle: (n) => `ಗ್ರಾಹಕರನ್ನು ಆಯ್ಕೆಮಾಡಿ (${n} ಹೊಂದಾಣಿಕೆಗಳು)`,
      confirmNewCustomer: 'ಹೊಸ ಗ್ರಾಹಕರನ್ನು ಖಚಿತಪಡಿಸಿ',
      confirmAdd: 'ಸೇರಿಸಿ',
      confirmEntryTitle: 'ಖಾತಾ ದಾಖಲೆ ಖಚಿತಪಡಿಸಿ',
      selectCustomerPlaceholder: 'ಗ್ರಾಹಕರನ್ನು ಆಯ್ಕೆಮಾಡಿ...',
      creditToggle: 'ಉದ್ರಿ ನೀಡಿದ್ದು (+ಉದ್ರಿ)',
      repaymentToggle: 'ಪಾವತಿ ಬಂದಿದ್ದು (-ಜಮಾ)',
      amountLabel: 'ಮೊತ್ತ (₹)',
      notesLabel: 'ವಿವರ / ಸಾಮಾನು',
      prevBal: 'ಹಿಂದಿನ ಬಾಕಿ',
      plusCredit: '+ಉದ್ರಿ',
      minusPaid: '-ಪಾವತಿ',
      newBal: 'ಹೊಸ ಬಾಕಿ',
      advanceAck: 'ಹೆಚ್ಚುವರಿ ಹಣವನ್ನು ಗ್ರಾಹಕರ ಮುಂಗಡವಾಗಿ (Advance) ಉಳಿಸಿ',
      answerTitle: 'ಉತ್ತರ',
      savedTitle: 'ಖಾತಾದಲ್ಲಿ ಉಳಿಸಲಾಗಿದೆ',
      openLedger: 'ಖಾತಾ ತೆರೆಯಿರಿ',
      transactionsBtn: 'ವಹಿವಾಟುಗಳು',
      dashboardBtn: 'ಮುಖಪುಟ',
      speakAgain: 'ಮತ್ತೆ ಮಾತನಾಡಿ',
      stopLabel: 'ನಿಲ್ಲಿಸಿ',
      micAriaStart: 'ಧ್ವನಿ ರೆಕಾರ್ಡಿಂಗ್ ಪ್ರಾರಂಭಿಸಿ',
      micAriaStop: 'ರೆಕಾರ್ಡಿಂಗ್ ನಿಲ್ಲಿಸಿ',
      errSimulatedAi:
        'ಡೆಮೋ ದೋಷ: ಈ ಆಜ್ಞೆಯನ್ನು ಅರ್ಥಮಾಡಿಕೊಳ್ಳಲು ಆಗಲಿಲ್ಲ. ಪಠ್ಯ ತಿದ್ದುಪಡಿ ಮಾಡಿ ಅಥವಾ ಮತ್ತೆ ಪ್ರಯತ್ನಿಸಿ.',
      errUnknownCommand:
        'ಆಜ್ಞೆ ಅರ್ಥವಾಗಲಿಲ್ಲ. ಪಠ್ಯವನ್ನು ತಿದ್ದುಪಡಿ ಮಾಡಿ ಅಥವಾ ಮಾದರಿ ಆಜ್ಞೆಯನ್ನು ಒತ್ತಿರಿ.',
      errTypeOrRecord: 'ದಯವಿಟ್ಟು ಮಾತನಾಡಿ ಅಥವಾ ವಾಕ್ಯವನ್ನು ಟೈಪ್ ಮಾಡಿ.',
      errInvalidCustName: 'ಸರಿಯಾದ ಗ್ರಾಹಕರ ಹೆಸರನ್ನು ನಮೂದಿಸಿ.',
      errSelectCustomer: 'ಮೊದಲು ಗ್ರಾಹಕರನ್ನು ಆಯ್ಕೆಮಾಡಿ.',
      errInvalidAmount: '₹0 ಗಿಂತ ಹೆಚ್ಚಿನ ಸರಿಯಾದ ಮೊತ್ತವನ್ನು ನಮೂದಿಸಿ.',
      errConfirmOverpay: 'ಹೆಚ್ಚುವರಿ ಪಾವತಿ ಉಳಿಸಲು ಕೆಳಗಿನ ಬಾಕ್ಸ್ ಅನ್ನು ಟಿಕ್ ಮಾಡಿ.',
      errSimulatedSave: 'ಡೆಮೋ ಉಳಿಸುವ ದೋಷ: ದಾಖಲೆ ಉಳಿಸಲಾಗಿಲ್ಲ.',
      errSaveFailed: 'ವಹಿವಾಟು ಉಳಿಸಲು ಸಾಧ್ಯವಾಗಲಿಲ್ಲ.',
      errCreateCustomerFailed: 'ಗ್ರಾಹಕರನ್ನು ಸೇರಿಸಲು ಸಾಧ್ಯವಾಗಲಿಲ್ಲ.',
      spokenCommandNotUnderstood: 'ಆಜ್ಞೆ ಅರ್ಥವಾಗಲಿಲ್ಲ. ದಯವಿಟ್ಟು ಮತ್ತೆ ಹೇಳಿ.',
      msgDailySummary: (credit, repaid, due) =>
        `ಇಂದಿನ ಉದ್ರಿ ${credit}, ಇಂದಿನ ಪಾವತಿ ${repaid}, ಒಟ್ಟು ಬಾಕಿ ${due}.`,
      msgTotalOutstanding: (count, due) =>
        `${count} ಗ್ರಾಹಕರ ಒಟ್ಟು ಬಾಕಿ ${due} ಆಗಿದೆ.`,
      msgCustomerBalance: (name, balance) => `${name} ಅವರ ಬಾಕಿ ${balance} ಆಗಿದೆ.`,
      msgCustomerHistory: (name, balance) => `${name} · ಪ್ರಸ್ತುತ ಬಾಕಿ ${balance}.`,
      msgCustomerAdded: (name) => `ಗ್ರಾಹಕ ${name} ನಿಮ್ಮ ಖಾತಾಗೆ ಸೇರಿಸಲ್ಪಟ್ಟಿದ್ದಾರೆ.`,
      msgSavedEntry: (amount, type, name, newBal) =>
        `${name} ಅವರಿಗೆ ${amount} ${type === 'CREDIT' ? 'ಉದ್ರಿ' : 'ಪಾವತಿ'} ಉಳಿಸಲಾಗಿದೆ. ಹೊಸ ಬಾಕಿ: ${newBal}.`,
      micUnavailable:
        'ಈ ಬ್ರೌಸರ್‌ನಲ್ಲಿ ಮೈಕ್ರೊಫೋನ್ ರೆಕಾರ್ಡಿಂಗ್ ಲಭ್ಯವಿಲ್ಲ. ಕೆಳಗಿನ ಮಾದರಿ ಆಜ್ಞೆಗಳು ಅಥವಾ ಟೈಪ್ ಮಾಡುವ ಮೂಲಕ ಪರೀಕ್ಷಿಸಬಹುದು.',
      micPermissionDenied:
        'ಮೈಕ್ರೊಫೋನ್ ಅನುಮತಿ ನಿರಾಕರಿಸಲಾಗಿದೆ. ಬ್ರೌಸರ್ ಸೆಟ್ಟಿಂಗ್ಸ್‌ನಲ್ಲಿ ಅನುಮತಿ ನೀಡಿ ಅಥವಾ ಕೆಳಗಿನ ಮಾದರಿ ಆಜ್ಞೆಗಳನ್ನು ಬಳಸಿ.',
      micNotFound:
        'ಸಕ್ರಿಯ ಮೈಕ್ರೊಫೋನ್ ಕಂಡುಬಂದಿಲ್ಲ. ಕೆಳಗಿನ ಮಾದರಿ ಆಜ್ಞೆಗಳನ್ನು ಬಳಸಿ ಅಥವಾ ವಾಕ್ಯ ಟೈಪ್ ಮಾಡಿ.',
      sampleLabels: {
        sample_ramesh_credit: {
          label: 'ಒಂದೇ ಹೆಸರಿನ ಗ್ರಾಹಕರು (ರಮೇಶ್ ₹340)',
          hint: 'ರಮೇಶ್ ಆಯ್ಕೆ ಮತ್ತು ₹340 ಉದ್ರಿ ಡೆಮೋ',
        },
        sample_ramesh_kumar_exact: {
          label: 'ರಮೇಶ್ ಕುಮಾರ್ ₹340 ಉದ್ರಿ',
          hint: 'ಹಿಂದಿನ ₹500 + ₹340 = ₹840 ಹೊಸ ಬಾಕಿ',
        },
        sample_suresh_repayment: {
          label: 'ಸುರೇಶ್ ₹500 ಪಾವತಿ (ಹಿಂದಿ)',
          hint: 'ಸುರೇಶ್ ನಾಯರ್ ಅವರ ₹500 ಪಾವತಿ ದಾಖಲಿಸಿ',
        },
        sample_mohan_decimal: {
          label: 'ಮೋಹನ್ ₹1,250.50 ಉದ್ರಿ (ಇಂಗ್ಲಿಷ್)',
          hint: 'ಪೈಸೆ ನಿಖರತೆ ಪರೀಕ್ಷೆ',
        },
        sample_anita_balance: {
          label: 'ಅನಿತಾ ಬಾಕಿ ಪರಿಶೀಲನೆ',
          hint: 'ಗ್ರಾಹಕರ ಬಾಕಿ ನೋಡುವ ಆಜ್ಞೆ',
        },
        sample_daily_summary: {
          label: 'ಇಂದಿನ ಲೆಕ್ಕ ಹೇಳಿ',
          hint: 'ಇಂದಿನ ಉದ್ರಿ, ಪಾವತಿ ಮತ್ತು ಒಟ್ಟು ಬಾಕಿ',
        },
        sample_kannada_credit: {
          label: 'ಕರೀಂ ₹250 ಉದ್ರಿ (ಕನ್ನಡ)',
          hint: 'ಕನ್ನಡ ಧ್ವನಿ ಆಜ್ಞೆ — ಕರೀಂ ಶೇಖ್',
        },
        sample_kannada_repayment: {
          label: 'ಸುರೇಶ್ ₹500 ಪಾವತಿ (ಕನ್ನಡ)',
          hint: 'ಕನ್ನಡ ಪಾವತಿ ಆಜ್ಞೆ — ಸುರೇಶ್ ನಾಯರ್',
        },
        sample_create_customer: {
          label: 'ಹೊಸ ಗ್ರಾಹಕ ಅರ್ಜುನ್ ಮೆಹ್ತಾ ಸೇರಿಸಿ',
          hint: 'ಖಚಿತಪಡಿಸಿದ ನಂತರ ಹೊಸ ಗ್ರಾಹಕರನ್ನು ಸೇರಿಸುತ್ತದೆ',
        },
      },
    },
    customers: {
      activeSummary: (count) => `${count} ಸಕ್ರಿಯ`,
      dueLabel: 'ಬಾಕಿ',
      addParty: 'ಹೊಸ ಗ್ರಾಹಕ',
      searchPlaceholder: 'ಹೆಸರು ಅಥವಾ ಫೋನ್ ಸಂಖ್ಯೆ ಹುಡುಕಿ...',
      filters: {
        all: 'ಎಲ್ಲಾ ಸಕ್ರಿಯ',
        due: 'ಬಾಕಿ ಇರುವವರು',
        settled: 'ಪೂರ್ಣಗೊಂಡಿದೆ',
        inactive: 'ನಿಷ್ಕ್ರಿಯ',
      },
      emptyTitle: 'ಯಾವುದೇ ಗ್ರಾಹಕರು ಕಂಡುಬಂದಿಲ್ಲ',
      emptySearchDesc: (q) => `"${q}" ಗೆ ಯಾವುದೇ ಗ್ರಾಹಕರು ಸಿಗಲಿಲ್ಲ.`,
      emptyFilterDesc: 'ಈ ಫಿಲ್ಟರ್‌ನಲ್ಲಿ ಯಾವುದೇ ಗ್ರಾಹಕರಿಲ್ಲ.',
      emptyAction: 'ಗ್ರಾಹಕರನ್ನು ಸೇರಿಸಿ',
      inactiveTag: '· ನಿಷ್ಕ್ರಿಯ',
      statusDue: 'ಬಾಕಿ',
      statusAdvance: 'ಮುಂಗಡ',
      statusSettled: 'ಚುಕ್ತಾ',
    },
    ledger: {
      notFoundTitle: 'ಗ್ರಾಹಕರು ಸಿಗಲಿಲ್ಲ',
      notFoundDesc: 'ಈ ಗ್ರಾಹಕರ ಖಾತೆ ಲಭ್ಯವಿಲ್ಲ.',
      backToCustomers: 'ಗ್ರಾಹಕರ ಪಟ್ಟಿಗೆ ಹಿಂತಿರುಗಿ',
      editProfileAria: 'ವಿವರ ತಿದ್ದುಪಡಿ',
      deactivateAria: 'ನಿಷ್ಕ್ರಿಯಗೊಳಿಸಿ',
      reactivateAria: 'ಸಕ್ರಿಯಗೊಳಿಸಿ',
      inactiveTag: '· ನಿಷ್ಕ್ರಿಯ',
      netBalance: 'ನಿವ್ವಳ ಬಾಕಿ',
      owesYou: 'ಗ್ರಾಹಕರು ಕೊಡಬೇಕಾದ್ದು',
      advanceWithShop: 'ಅಂಗಡಿಯಲ್ಲಿ ಮುಂಗಡ ಇದೆ',
      settled: 'ಲೆಕ್ಕ ಸಮವಾಗಿದೆ',
      creditLabel: 'ಒಟ್ಟು ಉದ್ರಿ:',
      repaidLabel: 'ಒಟ್ಟು ಪಾವತಿ:',
      giveCredit: 'ಉದ್ರಿ ಕೊಡಿ',
      gotPayment: 'ಪಾವತಿ ಪಡೆಯಿರಿ',
      historyTitle: 'ವಹಿವಾಟು ಇತಿಹಾಸ',
      balShort: 'ಬಾಕಿ',
      openingBalance: 'ಆರಂಭಿಕ ಬಾಕಿ',
      editCustomerTitle: 'ಗ್ರಾಹಕರ ವಿವರ ತಿದ್ದುಪಡಿ',
      customerNameLabel: 'ಗ್ರಾಹಕರ ಹೆಸರು *',
      phoneLabel: 'ಫೋನ್ ಸಂಖ್ಯೆ',
      notesLabel: 'ಟಿಪ್ಪಣಿ',
      reverseEntryTitle: 'ದಾಖಲೆ ಹಿಂಪಡೆಯಿರಿ',
      reverseSubtitle: 'ಸಂಪೂರ್ಣ ಆಡಿಟ್ ದಾಖಲೆ ಸುರಕ್ಷಿತವಾಗಿರುತ್ತದೆ',
      entryLabel: 'ದಾಖಲೆ:',
      reasonLabel: 'ಕಾರಣ (ಐಚ್ಛಿಕ)',
      reasonPlaceholder: 'ಉದಾ: ತಪ್ಪು ಮೊತ್ತ',
    },
    transactions: {
      addCredit: 'ಉದ್ರಿ ಸೇರಿಸಿ',
      gotPayment: 'ಪಾವತಿ ಸಿಕ್ಕಿದೆ',
      searchPlaceholder: 'ಗ್ರಾಹಕ ಅಥವಾ ಸಾಮಾನು ಹುಡುಕಿ...',
      filtersBtn: 'ಫಿಲ್ಟರ್',
      filtersCountBtn: (n) => `ಫಿಲ್ಟರ್ (${n})`,
      types: {
        all: 'ಎಲ್ಲಾ',
        credit: 'ಉದ್ರಿ',
        repayment: 'ಪಾವತಿ',
        reversal: 'ಹಿಂಪಡೆತ',
      },
      emptyTitle: 'ಯಾವುದೇ ವಹಿವಾಟು ಸಿಗಲಿಲ್ಲ',
      emptyDesc: 'ಫಿಲ್ಟರ್ ತೆಗೆಯಿರಿ ಅಥವಾ ಹೊಸ ಉದ್ರಿ/ಪಾವತಿ ದಾಖಲಿಸಿ.',
      filterModalTitle: 'ವಹಿವಾಟು ಫಿಲ್ಟರ್ ಮಾಡಿ',
      customerFilterLabel: 'ಗ್ರಾಹಕ',
      allCustomers: 'ಎಲ್ಲಾ ಗ್ರಾಹಕರು',
      dateRangeLabel: 'ದಿನಾಂಕ',
      dates: {
        all: 'ಎಲ್ಲಾ ದಿನಾಂಕಗಳು',
        today: 'ಇಂದು',
        last7d: 'ಕಳೆದ 7 ದಿನಗಳು',
        last30d: 'ಕಳೆದ 30 ದಿನಗಳು',
      },
      entrySourceLabel: 'ದಾಖಲೆ ವಿಧಾನ',
      sources: {
        all: 'ಎಲ್ಲಾ',
        voice: 'ಧ್ವನಿ',
        manual: 'ಮ್ಯಾನ್ಯುವಲ್',
      },
      minAmount: 'ಕನಿಷ್ಠ ₹',
      maxAmount: 'ಗರಿಷ್ಠ ₹',
      reverseTitle: 'ದಾಖಲೆ ಹಿಂಪಡೆಯಿರಿ',
      reverseSubtitle: 'ಸಂಪೂರ್ಣ ಲೆಕ್ಕ ಇತಿಹಾಸ ಉಳಿಯುತ್ತದೆ',
      customerLabel: 'ಗ್ರಾಹಕ:',
      entryLabel: 'ದಾಖಲೆ:',
      reasonLabel: 'ಕಾರಣ (ಐಚ್ಛಿಕ)',
      reasonPlaceholder: 'ಉದಾ: ತಪ್ಪು ಮೊತ್ತ',
    },
    reports: {
      periods: {
        daily: 'ಇಂದು',
        weekly: '7 ದಿನ',
        monthly: '30 ದಿನ',
      },
      csvBtn: 'CSV',
      creditGiven: 'ನೀಡಿದ ಉದ್ರಿ',
      repayments: 'ಬಂದ ಪಾವತಿ',
      collectedSub: 'ಸಂಗ್ರಹವಾಗಿದೆ',
      netChange: 'ನಿವ್ವಳ ಬದಲಾವಣೆ',
      totalDue: 'ಒಟ್ಟು ಬಾಕಿ',
      partiesDueSub: (n) => `${n} ಗ್ರಾಹಕರ ಬಾಕಿ`,
      chartTitle: 'ಉದ್ರಿ ಮತ್ತು ಪಾವತಿ',
      creditLegend: 'ಉದ್ರಿ',
      paidLegend: 'ಪಾವತಿ',
      tooltipCredit: 'ಉದ್ರಿ',
      tooltipRepayment: 'ಪಾವತಿ',
      voiceEntries: 'ಧ್ವನಿ ಮೂಲಕ',
      manualEntries: 'ಮ್ಯಾನ್ಯುವಲ್',
      highestOutstanding: 'ಹೆಚ್ಚು ಬಾಕಿ ಇರುವ ಗ್ರಾಹಕರು',
      allSettled: 'ಎಲ್ಲಾ ಗ್ರಾಹಕರ ಬಾಕಿ ಚುಕ್ತಾ ಆಗಿದೆ.',
      creditSummary: (credit, repaid) => `ಉದ್ರಿ ${credit} · ಪಾವತಿ ${repaid}`,
      buckets: {
        morning: 'ಬೆಳಿಗ್ಗೆ',
        afternoon: 'ಮಧ್ಯಾಹ್ನ',
        evening: 'ಸಂಜೆ',
        night: 'ರಾತ್ರಿ',
        week1: 'ವಾರ 1',
        week2: 'ವಾರ 2',
        week3: 'ವಾರ 3',
        week4: 'ವಾರ 4',
      },
    },
    settings: {
      shopProfileTitle: 'ಅಂಗಡಿ ವಿವರಗಳು',
      shopNameLabel: 'ಅಂಗಡಿಯ ಹೆಸರು *',
      ownerNameLabel: 'ಮಾಲೀಕರ ಹೆಸರು *',
      categoryLabel: 'ವಿಭಾಗ',
      languageLabel: 'ಭಾಷೆ ಆಯ್ಕೆ',
      addressLabel: 'ವಿಳಾಸ',
      spokenRepliesTitle: 'ಧ್ವನಿಯಲ್ಲಿ ಉತ್ತರ ಕೇಳಿ',
      spokenRepliesDesc: 'ಉತ್ತರಗಳನ್ನು ಗಟ್ಟಿಯಾಗಿ ಓದಿ',
      savedFeedback: 'ಸೆಟ್ಟಿಂಗ್‌ಗಳು ಉಳಿಸಲ್ಪಟ್ಟಿವೆ.',
      saveSettingsBtn: 'ಸೆಟ್ಟಿಂಗ್‌ಗಳನ್ನು ಉಳಿಸಿ',
      auditTrailTitle: 'ಆಡಿಟ್ ಇತಿಹಾಸ',
      downloadZip: 'KhataSaathi_Frontend.zip ಡೌನ್‌ಲೋಡ್ ಮಾಡಿ',
      resetDemoBtn: 'ಡೆಮೋ ಮರುಹೊಂದಿಸಿ',
      logoutBtn: 'ಲಾಗ್‌ಔಟ್',
      resetModalTitle: 'ಡೆಮೋ ಡೇಟಾ ಮರುಹೊಂದಿಸಬೇಕೆ?',
      resetModalSubtitle: 'ಮಾದರಿ ಗ್ರಾಹಕರು ಮತ್ತು ವಹಿವಾಟುಗಳು ಮರಳುತ್ತವೆ',
      resetModalDesc:
        'ನಿಮ್ಮ ಬ್ರೌಸರ್ ಬದಲಾವಣೆಗಳನ್ನು ತೆಗೆದುಹಾಕಿ ಡೀಫಾಲ್ಟ್ 10 ಗ್ರಾಹಕರು ಮತ್ತು 20 ವಹಿವಾಟುಗಳನ್ನು ಮರುಸ್ಥಾಪಿಸಲಾಗುತ್ತದೆ.',
      confirmResetBtn: 'ಮರುಹೊಂದಿಸಿ',
    },
    modals: {
      addCustomerTitle: 'ಹೊಸ ಗ್ರಾಹಕರನ್ನು ಸೇರಿಸಿ',
      addCustomerSubtitle: 'ನಿಮ್ಮ ಅಂಗಡಿಗಾಗಿ ಗ್ರಾಹಕ ಖಾತಾ ರಚಿಸಿ',
      customerNameLabel: 'ಗ್ರಾಹಕರ ಹೆಸರು *',
      customerNamePlaceholder: 'ಉದಾ: ರಾಜೇಶ್ ವರ್ಮಾ',
      mobileLabel: 'ಮೊಬೈಲ್ ಸಂಖ್ಯೆ (ಐಚ್ಛಿಕ)',
      mobilePlaceholder: 'ಉದಾ: 98450 12345',
      openingBalLabel: 'ಆರಂಭಿಕ ಬಾಕಿ ₹ (ಐಚ್ಛಿಕ)',
      openingBalHelper: 'ಖಾತಾಸಾಥಿ ಪ್ರಾರಂಭಿಸುವ ಮೊದಲಿನ ಹಳೆಯ ಬಾಕಿ',
      notesLabel: 'ಟಿಪ್ಪಣಿ (ಐಚ್ಛಿಕ)',
      notesPlaceholder: 'ಉದಾ: ಬ್ಲಾಕ್ C, ವಾರದ ದಿನಸಿ',
      duplicateWarning: 'ಇದೇ ರೀತಿಯ ಗ್ರಾಹಕರು ಈಗಾಗಲೇ ಖಾತಾದಲ್ಲಿದ್ದಾರೆ:',
      addAnyway: 'ಇವರು ಬೇರೆ ಗ್ರಾಹಕರು, ಆದರೂ ಸೇರಿಸಿ',
      createBtn: 'ಗ್ರಾಹಕರನ್ನು ರಚಿಸಿ',
      errNameMin: 'ದಯವಿಟ್ಟು ಗ್ರಾಹಕರ ಪೂರ್ಣ ಹೆಸರನ್ನು ನಮೂದಿಸಿ (ಕನಿಷ್ಠ 2 ಅಕ್ಷರಗಳು).',
      errInvalidOpeningBal:
        'ಆರಂಭಿಕ ಬಾಕಿ ಸರಿಯಾದ ರೂಪಾಯಿ ಮೊತ್ತವಾಗಿರಬೇಕು (ಉದಾ. 500 ಅಥವಾ 250.50).',
      errDuplicateAck:
        'ಹೋಲುವ ಗ್ರಾಹಕರು ಕಂಡುಬಂದಿದ್ದಾರೆ. ಪರಿಶೀಲಿಸಿ ಅಥವಾ "ಆದರೂ ಸೇರಿಸಿ" ಟಿಕ್ ಮಾಡಿ.',
      errCreateCustomer: 'ಗ್ರಾಹಕರನ್ನು ಸೇರಿಸಲು ಸಾಧ್ಯವಾಗಲಿಲ್ಲ.',
      txnAddCreditTitle: 'ಉದ್ರಿ ಸೇರಿಸಿ (+ಉದ್ರಿ)',
      txnRecordRepaymentTitle: 'ಪಾವತಿ ದಾಖಲಿಸಿ (-ಜಮಾ)',
      txnSubtitle: 'ಎಲ್ಲಾ ದಾಖಲೆಗಳು ಪೈಸೆ ನಿಖರತೆಯಲ್ಲಿ ಗ್ರಾಹಕ ಖಾತಾವನ್ನು ನವೀಕರಿಸುತ್ತವೆ',
      creditTab: 'ಉದ್ರಿ ನೀಡಿದ್ದು (+ಉದ್ರಿ)',
      repaymentTab: 'ಪಾವತಿ (-ಜಮಾ)',
      selectCustomerLabel: 'ಗ್ರಾಹಕರು *',
      selectCustomerOption: 'ಗ್ರಾಹಕರನ್ನು ಆಯ್ಕೆಮಾಡಿ...',
      dueSuffix: 'ಬಾಕಿ',
      amountLabel: 'ಮೊತ್ತ (₹) *',
      amountPlaceholder: 'ಉದಾ: 500 ಅಥವಾ 340.50',
      descLabel: 'ವಿವರ / ಸಾಮಾನು',
      descCreditPlaceholder: 'ಉದಾ: ಅಕ್ಕಿ 5 ಕೆಜಿ, ಹಾಲು ಮತ್ತು ದಿನಸಿ',
      descRepayPlaceholder: 'ಉದಾ: ನಗದು / UPI ಪಾವತಿ',
      dateLabel: 'ದಿನಾಂಕ ಮತ್ತು ಸಮಯ',
      prevBal: 'ಹಿಂದಿನ ಬಾಕಿ',
      newBal: 'ಹೊಸ ಬಾಕಿ',
      overpaymentMsg: (paid, due, excess) =>
        `ಪಾವತಿ (${paid}) ಪ್ರಸ್ತುತ ಬಾಕಿ (${due}) ಗಿಂತ ಹೆಚ್ಚಿದೆ. ಇದನ್ನು ಉಳಿಸಿದರೆ ${excess} ಗ್ರಾಹಕರ ಮುಂಗಡ ಹಣವಾಗಿ ಉಳಿಯುತ್ತದೆ.`,
      overpaymentAck: 'ಹೆಚ್ಚುವರಿ ಹಣವನ್ನು ಮುಂಗಡವಾಗಿ ದಾಖಲಿಸಿ',
      saveCreditBtn: 'ಉದ್ರಿ ಉಳಿಸಿ',
      saveRepayBtn: 'ಪಾವತಿ ಉಳಿಸಿ',
      errSelectCustomer: 'ದಯವಿಟ್ಟು ಗ್ರಾಹಕರನ್ನು ಆಯ್ಕೆಮಾಡಿ.',
      errValidAmount: '₹0 ಗಿಂತ ಹೆಚ್ಚಿನ ಸರಿಯಾದ ಮೊತ್ತ ನಮೂದಿಸಿ (ಉದಾ. 340 ಅಥವಾ 500.50).',
      errConfirmOverpay:
        'ಪಾವತಿ ಬಾಕಿಗಿಂತ ಹೆಚ್ಚಿದೆ. ಮುಂದುವರಿಯಲು ಕೆಳಗಿನ ಬಾಕ್ಸ್ ಟಿಕ್ ಮಾಡಿ.',
      errSaveTxn: 'ವಹಿವಾಟು ಉಳಿಸಲು ಸಾಧ್ಯವಾಗಲಿಲ್ಲ.',
    },
    labels: {
      credit: 'ಉದ್ರಿ',
      repayment: 'ಪಾವತಿ',
      reversal: 'ಹಿಂಪಡೆತ',
      voiceEntry: 'ಧ್ವನಿ',
      manualEntry: 'ಮ್ಯಾನ್ಯುವಲ್',
      outstanding: 'ಬಾಕಿ',
      settled: 'ಚುಕ್ತಾ',
      advance: 'ಮುಂಗಡ',
      today: 'ಇಂದು',
      yesterday: 'ನಿನ್ನೆ',
      reverseBtnTitle: 'ವಹಿವಾಟು ಹಿಂಪಡೆಯಿರಿ',
    },
    errors: {
      shopRequired: 'ಅಂಗಡಿ ಹೆಸರು ಮತ್ತು ಮಾಲೀಕರ ಹೆಸರು ಅಗತ್ಯವಿದೆ.',
      shopNameEmpty: 'ಅಂಗಡಿಯ ಹೆಸರು ಖಾಲಿ ಇರಬಾರದು.',
      customerNameMin: 'ಗ್ರಾಹಕರ ಹೆಸರು ಕನಿಷ್ಠ 2 ಅಕ್ಷರಗಳಿರಬೇಕು.',
      openingNegative: 'ಆರಂಭಿಕ ಬಾಕಿ ಋಣಾತ್ಮಕವಾಗಿರಬಾರದು.',
      customerNotFound: 'ಗ್ರಾಹಕರು ಸಿಗಲಿಲ್ಲ.',
      selectedCustomerNotFound: 'ಆಯ್ಕೆಮಾಡಿದ ಗ್ರಾಹಕರು ಸಿಗಲಿಲ್ಲ.',
      inactiveCustomerEntry: 'ನಿಷ್ಕ್ರಿಯ ಗ್ರಾಹಕರಿಗೆ ದಾಖಲೆ ಸೇರಿಸಲು ಸಾಧ್ಯವಿಲ್ಲ.',
      amountGreaterThanZero: 'ಮೊತ್ತವು ₹0 ಗಿಂತ ಹೆಚ್ಚಾಗಿರಬೇಕು.',
      txnNotFound: 'ವಹಿವಾಟು ಕಂಡುಬಂದಿಲ್ಲ.',
      alreadyReversed: 'ಈ ವಹಿವಾಟನ್ನು ಈಗಾಗಲೇ ಹಿಂಪಡೆಯಲಾಗಿದೆ.',
      couldNotUpdateCustomer: 'ಗ್ರಾಹಕರ ವಿವರ ನವೀಕರಿಸಲು ಸಾಧ್ಯವಾಗಲಿಲ್ಲ.',
      couldNotSaveSettings: 'ಸೆಟ್ಟಿಂಗ್‌ಗಳನ್ನು ಉಳಿಸಲು ಸಾಧ್ಯವಾಗಲಿಲ್ಲ.',
      couldNotReverseTxn: 'ವಹಿವಾಟು ಹಿಂಪಡೆಯಲು ಸಾಧ್ಯವಾಗಲಿಲ್ಲ.',
    },
  },
};

export function getTranslations(lang: LanguageCode): Translations {
  return DICTIONARY[lang] || DICTIONARY.en;
}

export const LANGUAGE_OPTIONS: { code: LanguageCode; label: string; nativeLabel: string }[] = [
  { code: 'en', label: 'English', nativeLabel: 'English' },
  { code: 'hi', label: 'Hindi', nativeLabel: 'हिन्दी' },
  { code: 'kn', label: 'Kannada', nativeLabel: 'ಕನ್ನಡ' },
];
