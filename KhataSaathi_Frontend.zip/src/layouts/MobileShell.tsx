import React, { createContext, useContext, useState } from 'react';
import { Wifi, BatteryFull, Signal } from 'lucide-react';

const MobilePortalContext = createContext<HTMLDivElement | null>(null);

export function useMobilePortalContainer(): HTMLDivElement | null {
  return useContext(MobilePortalContext);
}

export const MobileShell: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [portalNode, setPortalNode] = useState<HTMLDivElement | null>(null);

  return (
    <div className="min-h-[100dvh] w-full bg-[#E8EFFB] sm:py-4 sm:px-4 flex items-center justify-center">
      {/* Mobile Device Viewport: edge-to-edge on phones, crisp 420px Android frame on desktop */}
      <div className="relative w-full h-[100dvh] sm:w-[420px] sm:h-[min(868px,calc(100dvh-2rem))] sm:rounded-[38px] sm:border-[4px] sm:border-slate-300/90 sm:shadow-[0_24px_70px_rgba(23,37,84,0.14)] bg-[#F5F8FF] flex flex-col overflow-hidden">
        {/* Subtle Android Status Bar (visible on desktop frame only) */}
        <div className="hidden sm:flex items-center justify-between px-6 pt-2.5 pb-1.5 text-[11px] font-semibold text-[#172554] bg-white shrink-0 select-none">
          <span className="font-mono tabular-nums">9:41</span>
          <div className="w-20 h-4 rounded-full bg-slate-200/80 border border-slate-300/60" />
          <div className="flex items-center gap-1.5 text-[#172554]">
            <Signal className="w-3 h-3" />
            <Wifi className="w-3 h-3" />
            <BatteryFull className="w-3.5 h-3.5 text-[#2563EB]" />
          </div>
        </div>

        <MobilePortalContext.Provider value={portalNode}>
          <div className="relative flex-1 flex flex-col min-h-0 overflow-hidden bg-[#F5F8FF]">
            {children}
          </div>
        </MobilePortalContext.Provider>

        {/* Portal target for mobile bottom sheets */}
        <div ref={setPortalNode} className="pointer-events-none absolute inset-0 z-50" />

        {/* Android Bottom Gesture Indicator (desktop frame only) */}
        <div className="hidden sm:flex justify-center py-1.5 bg-white shrink-0">
          <div className="w-28 h-1 rounded-full bg-slate-300" />
        </div>
      </div>
    </div>
  );
};
