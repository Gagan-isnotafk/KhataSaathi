import React from 'react';
import { NavLink, Outlet, useLocation, useNavigate } from 'react-router-dom';
import {
  ArrowLeft,
  BarChart3,
  BookOpen,
  LayoutDashboard,
  Mic,
  Settings,
  Users,
} from 'lucide-react';
import { LogoMark } from '@/src/assets/LogoMark';
import { useApp } from '@/src/context/AppContext';

export const AppLayout: React.FC = () => {
  const { shop, t } = useApp();
  const navigate = useNavigate();
  const location = useLocation();

  const mobileTabs = [
    { to: '/dashboard', label: t.nav.dashboard, icon: LayoutDashboard },
    { to: '/customers', label: t.nav.customers, icon: Users },
    { to: '/voice', label: t.nav.voice, icon: Mic, isCenter: true },
    { to: '/transactions', label: t.nav.transactions, icon: BookOpen },
    { to: '/reports', label: t.nav.reports, icon: BarChart3 },
  ];

  const isCustomerLedgerSubpage = location.pathname.startsWith('/customers/');
  const isSettingsPage = location.pathname.startsWith('/settings');

  const getHeaderTitle = () => {
    const path = location.pathname;
    if (path.startsWith('/voice')) return t.nav.voiceAssistantTitle;
    if (path.startsWith('/customers/')) return t.nav.customerKhataTitle;
    if (path.startsWith('/customers')) return t.nav.customers;
    if (path.startsWith('/transactions')) return t.nav.transactions;
    if (path.startsWith('/reports')) return t.nav.reports;
    if (path.startsWith('/settings')) return t.nav.settings;
    return shop.name;
  };

  return (
    <div className="flex-1 flex flex-col min-h-0 bg-[#F5F8FF] text-[#172554]">
      <header className="shrink-0 h-[56px] pt-safe bg-white border-b border-slate-200/80 px-4 flex items-center justify-between gap-2.5 shadow-[0_1px_4px_rgba(23,37,84,0.04)]">
        <div className="flex items-center gap-2.5 min-w-0">
          {isCustomerLedgerSubpage || isSettingsPage ? (
            <button
              type="button"
              onClick={() =>
                navigate(isCustomerLedgerSubpage ? '/customers' : '/dashboard')
              }
              aria-label={t.nav.goBack}
              className="min-h-[42px] min-w-[42px] -ml-1.5 rounded-full flex items-center justify-center text-[#172554] active:bg-[#DBEAFE]/60 cursor-pointer shrink-0"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
          ) : (
            <button
              type="button"
              onClick={() => navigate('/dashboard')}
              className="flex items-center shrink-0 cursor-pointer"
              aria-label={t.nav.homeAria}
            >
              <LogoMark className="w-8 h-8" />
            </button>
          )}

          <div className="min-w-0">
            <h1 className="text-[16px] font-display font-bold text-[#172554] truncate leading-tight">
              {getHeaderTitle()}
            </h1>
            {location.pathname === '/dashboard' && (
              <p className="text-[11px] text-[#64748B] truncate">
                {shop.ownerName} · {t.categories[shop.category] || shop.category}
              </p>
            )}
          </div>
        </div>

        <button
          type="button"
          onClick={() => navigate('/settings')}
          aria-label={t.nav.settingsAria}
          className={`min-h-[42px] min-w-[42px] -mr-1 rounded-full flex items-center justify-center transition-colors cursor-pointer shrink-0 ${
            isSettingsPage
              ? 'text-[#2563EB] bg-[#DBEAFE]'
              : 'text-[#64748B] hover:text-[#172554] active:bg-slate-100'
          }`}
        >
          <Settings className="w-5 h-5" />
        </button>
      </header>

      <main className="flex-1 overflow-y-auto overflow-x-hidden px-4 py-4 space-y-4">
        <Outlet />
      </main>

      <nav
        aria-label={t.nav.bottomNavAria}
        className="shrink-0 pb-safe bg-white border-t border-slate-200/90 shadow-[0_-4px_16px_rgba(23,37,84,0.05)]"
      >
        <div className="h-[64px] grid grid-cols-5 items-center px-1">
          {mobileTabs.map((tab) => {
            const Icon = tab.icon;
            if (tab.isCenter) {
              const isActive = location.pathname.startsWith(tab.to);
              return (
                <NavLink
                  key={tab.to}
                  to={tab.to}
                  aria-label={t.nav.voiceAssistantTitle}
                  className="flex flex-col items-center justify-center h-full relative"
                >
                  <span
                    className={`w-16 h-16 -mt-7 rounded-full flex items-center justify-center transition-transform active:scale-95 ring-4 ring-[#DBEAFE] border-2 border-white ${
                      isActive
                        ? 'bg-[#1D4ED8] text-white shadow-[0_10px_28px_rgba(37,99,235,0.48)]'
                        : 'bg-[#2563EB] text-white shadow-[0_8px_24px_rgba(37,99,235,0.38)]'
                    }`}
                  >
                    <Icon className="w-7 h-7 text-white stroke-[2.2]" />
                  </span>
                </NavLink>
              );
            }

            return (
              <NavLink
                key={tab.to}
                to={tab.to}
                className={({ isActive }) =>
                  `flex flex-col items-center justify-center gap-0.5 h-full min-h-[44px] transition-colors ${
                    isActive
                      ? 'text-[#2563EB]'
                      : 'text-[#64748B] hover:text-[#172554]'
                  }`
                }
              >
                <Icon className="w-5 h-5" />
                <span className="text-[10px] font-semibold tracking-tight truncate max-w-[60px]">
                  {tab.label}
                </span>
              </NavLink>
            );
          })}
        </div>
      </nav>
    </div>
  );
};
