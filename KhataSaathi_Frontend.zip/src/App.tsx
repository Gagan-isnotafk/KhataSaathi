import React from 'react';
import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom';
import { AppProvider, useApp } from '@/src/context/AppContext';
import { AppLayout } from '@/src/layouts/AppLayout';
import { MobileShell } from '@/src/layouts/MobileShell';
import { CustomerLedgerPage } from '@/src/pages/CustomerLedgerPage';
import { CustomersPage } from '@/src/pages/CustomersPage';
import { DashboardPage } from '@/src/pages/DashboardPage';
import { ReportsPage } from '@/src/pages/ReportsPage';
import { SettingsPage } from '@/src/pages/SettingsPage';
import { ShopSetupPage } from '@/src/pages/ShopSetupPage';
import { TransactionsPage } from '@/src/pages/TransactionsPage';
import { VoiceAssistantPage } from '@/src/pages/VoiceAssistantPage';
import { WelcomeLoginPage } from '@/src/pages/WelcomeLoginPage';

const RequireAuth: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { session } = useApp();
  if (!session.isAuthenticated) {
    return <Navigate to="/login" replace />;
  }
  return <>{children}</>;
};

const RequireShopSetup: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { session } = useApp();
  if (!session.isAuthenticated) {
    return <Navigate to="/login" replace />;
  }
  if (!session.isShopSetupComplete) {
    return <Navigate to="/setup" replace />;
  }
  return <>{children}</>;
};

function AppRoutes() {
  return (
    <Routes>
      <Route path="/" element={<WelcomeLoginPage />} />
      <Route path="/login" element={<WelcomeLoginPage />} />
      <Route
        path="/setup"
        element={
          <RequireAuth>
            <ShopSetupPage />
          </RequireAuth>
        }
      />

      <Route
        element={
          <RequireShopSetup>
            <AppLayout />
          </RequireShopSetup>
        }
      >
        <Route path="/dashboard" element={<DashboardPage />} />
        <Route path="/voice" element={<VoiceAssistantPage />} />
        <Route path="/customers" element={<CustomersPage />} />
        <Route path="/customers/:id" element={<CustomerLedgerPage />} />
        <Route path="/transactions" element={<TransactionsPage />} />
        <Route path="/reports" element={<ReportsPage />} />
        <Route path="/settings" element={<SettingsPage />} />
      </Route>

      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}

export default function App() {
  return (
    <AppProvider>
      <BrowserRouter>
        <MobileShell>
          <AppRoutes />
        </MobileShell>
      </BrowserRouter>
    </AppProvider>
  );
}
