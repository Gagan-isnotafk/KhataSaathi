export type LanguageCode = 'en' | 'hi' | 'kn';

export type ShopCategory =
  | 'Kirana & Grocery'
  | 'Wholesale & Distributors'
  | 'Hardware & Electrical'
  | 'Pharmacy & Medical'
  | 'Stationery & Books'
  | 'Textiles & Apparel'
  | 'Other';

export interface User {
  id: string;
  name: string;
  phone: string;
  status: 'ACTIVE';
  createdAt: string;
  updatedAt: string;
}

export interface Shop {
  id: string;
  name: string;
  ownerId: string;
  ownerName: string;
  category: ShopCategory;
  currency: 'INR';
  language: LanguageCode;
  address?: string;
  timezone: 'Asia/Kolkata';
  voiceFeedbackEnabled: boolean;
  createdAt: string;
}

export interface Customer {
  id: string;
  shopId: string;
  name: string;
  phone?: string;
  notes?: string;
  openingBalancePaise: number;
  status: 'ACTIVE' | 'INACTIVE';
  createdAt: string;
}

export type TransactionType = 'CREDIT' | 'REPAYMENT' | 'REVERSAL';
export type TransactionSource = 'VOICE' | 'MANUAL';
export type TransactionStatus = 'POSTED' | 'REVERSED';

export interface Transaction {
  id: string;
  shopId: string;
  customerId: string;
  type: TransactionType;
  amountPaise: number;
  description: string;
  source: TransactionSource;
  createdBy: string;
  occurredAt: string;
  createdAt: string;
  status: TransactionStatus;
  idempotencyKey: string;
  reversedTransactionId?: string;
  reversalForType?: 'CREDIT' | 'REPAYMENT';
}

export interface CustomerSummary {
  customer: Customer;
  totalCreditPaise: number;
  totalRepaymentPaise: number;
  currentBalancePaise: number;
  transactionCount: number;
  lastTransactionAt: string | null;
}

export interface LedgerEntry {
  transaction: Transaction;
  runningBalancePaise: number;
}

export type VoiceState =
  | 'IDLE'
  | 'RECORDING'
  | 'AUDIO_READY'
  | 'TRANSCRIBING'
  | 'TRANSCRIPT_READY'
  | 'INTERPRETING'
  | 'VALIDATING'
  | 'WAITING_FOR_CONFIRMATION'
  | 'SAVING'
  | 'SUCCESS'
  | 'FAILED';

export type VoiceIntent =
  | 'ADD_CREDIT'
  | 'RECORD_REPAYMENT'
  | 'CHECK_BALANCE'
  | 'CUSTOMER_HISTORY'
  | 'DAILY_SUMMARY'
  | 'TOTAL_OUTSTANDING'
  | 'CREATE_CUSTOMER'
  | 'UNKNOWN';

export interface ParsedVoiceCommand {
  intent: VoiceIntent;
  rawTranscript: string;
  customerNameQuery: string | null;
  matchedCustomerId: string | null;
  candidateCustomerIds: string[];
  amountPaise: number | null;
  currency: 'INR';
  description: string;
  isReadOnly: boolean;
  needsClarification: boolean;
  clarificationType?: 'DUPLICATE_CUSTOMER' | 'MISSING_CUSTOMER' | 'MISSING_AMOUNT' | 'OVERPAYMENT' | 'UNKNOWN_COMMAND';
  clarificationMessage?: string;
}

export interface AuditLog {
  id: string;
  shopId: string;
  actorId: string;
  action: string;
  entityType: 'CUSTOMER' | 'TRANSACTION' | 'SHOP' | 'AUTH' | 'VOICE';
  entityId: string;
  summary: string;
  createdAt: string;
}

export interface AuthSession {
  isAuthenticated: boolean;
  isShopSetupComplete: boolean;
  token: string;
  userId: string;
}

export type ReportPeriod = 'DAILY' | 'WEEKLY' | 'MONTHLY';
