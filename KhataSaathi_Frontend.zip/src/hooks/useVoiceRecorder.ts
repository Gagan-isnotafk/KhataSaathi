import { useCallback, useEffect, useRef, useState } from 'react';

interface RecorderMessages {
  unavailable?: string;
  denied?: string;
  notFound?: string;
}

interface UseVoiceRecorderReturn {
  isRecording: boolean;
  durationSeconds: number;
  waveformBars: number[];
  audioUrl: string | null;
  micError: string | null;
  hasPermissionIssue: boolean;
  startRecording: () => Promise<boolean>;
  stopRecording: () => Promise<number>;
  clearAudio: () => void;
}

const BAR_COUNT = 28;
const IDLE_BARS = Array.from({ length: BAR_COUNT }, () => 14);

export function useVoiceRecorder(messages?: RecorderMessages): UseVoiceRecorderReturn {
  const [isRecording, setIsRecording] = useState(false);
  const [durationSeconds, setDurationSeconds] = useState(0);
  const [waveformBars, setWaveformBars] = useState<number[]>(IDLE_BARS);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [micError, setMicError] = useState<string | null>(null);
  const [hasPermissionIssue, setHasPermissionIssue] = useState(false);

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const rafRef = useRef<number | null>(null);
  const timerRef = useRef<number | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const durationRef = useRef(0);
  const messagesRef = useRef(messages);
  messagesRef.current = messages;

  const cleanupStreams = useCallback(() => {
    if (rafRef.current !== null) {
      cancelAnimationFrame(rafRef.current);
      rafRef.current = null;
    }
    if (timerRef.current !== null) {
      window.clearInterval(timerRef.current);
      timerRef.current = null;
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    }
    if (audioCtxRef.current && audioCtxRef.current.state !== 'closed') {
      audioCtxRef.current.close().catch(() => undefined);
      audioCtxRef.current = null;
    }
    setWaveformBars(IDLE_BARS);
  }, []);

  useEffect(() => {
    return () => {
      cleanupStreams();
      if (audioUrl) {
        URL.revokeObjectURL(audioUrl);
      }
    };
  }, [audioUrl, cleanupStreams]);

  const startRecording = useCallback(async (): Promise<boolean> => {
    setMicError(null);
    setHasPermissionIssue(false);
    durationRef.current = 0;
    setDurationSeconds(0);

    if (audioUrl) {
      URL.revokeObjectURL(audioUrl);
      setAudioUrl(null);
    }

    if (
      typeof navigator === 'undefined' ||
      !navigator.mediaDevices ||
      typeof navigator.mediaDevices.getUserMedia !== 'function'
    ) {
      setHasPermissionIssue(true);
      setMicError(
        messagesRef.current?.unavailable ||
          'Browser microphone recording is unavailable in this environment. You can still test with sample voice commands or typed transcripts.'
      );
      return false;
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;

      const mimeType =
        typeof MediaRecorder !== 'undefined' && MediaRecorder.isTypeSupported('audio/webm')
          ? 'audio/webm'
          : undefined;
      const recorder = mimeType
        ? new MediaRecorder(stream, { mimeType })
        : new MediaRecorder(stream);

      chunksRef.current = [];
      recorder.ondataavailable = (event) => {
        if (event.data && event.data.size > 0) {
          chunksRef.current.push(event.data);
        }
      };

      recorder.onstop = () => {
        if (chunksRef.current.length > 0) {
          const blob = new Blob(chunksRef.current, { type: mimeType || 'audio/webm' });
          const url = URL.createObjectURL(blob);
          setAudioUrl(url);
        }
      };

      mediaRecorderRef.current = recorder;
      recorder.start(150);
      setIsRecording(true);

      timerRef.current = window.setInterval(() => {
        durationRef.current += 1;
        setDurationSeconds(durationRef.current);
      }, 1000);

      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        const audioCtx = new AudioCtx();
        audioCtxRef.current = audioCtx;
        const source = audioCtx.createMediaStreamSource(stream);
        const analyser = audioCtx.createAnalyser();
        analyser.fftSize = 64;
        source.connect(analyser);

        const dataArray = new Uint8Array(analyser.frequencyBinCount);
        const renderWave = () => {
          analyser.getByteFrequencyData(dataArray);
          const nextBars = Array.from({ length: BAR_COUNT }, (_, idx) => {
            const sample = dataArray[idx % dataArray.length] || 0;
            return Math.max(14, Math.min(100, Math.round((sample / 255) * 100)));
          });
          setWaveformBars(nextBars);
          rafRef.current = requestAnimationFrame(renderWave);
        };
        rafRef.current = requestAnimationFrame(renderWave);
      }

      return true;
    } catch (err) {
      cleanupStreams();
      setIsRecording(false);
      setHasPermissionIssue(true);
      const message =
        err instanceof Error && err.name === 'NotAllowedError'
          ? messagesRef.current?.denied ||
            'Microphone permission was denied. Allow mic access in browser settings or use the sample voice prompts below.'
          : messagesRef.current?.notFound ||
            'No active microphone detected. Use the sample voice prompts or type a transcript to test the pipeline.';
      setMicError(message);
      return false;
    }
  }, [audioUrl, cleanupStreams]);

  const stopRecording = useCallback(async (): Promise<number> => {
    const finalSeconds = durationRef.current;
    setIsRecording(false);

    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      mediaRecorderRef.current.stop();
    }
    cleanupStreams();
    return finalSeconds;
  }, [cleanupStreams]);

  const clearAudio = useCallback(() => {
    if (audioUrl) {
      URL.revokeObjectURL(audioUrl);
      setAudioUrl(null);
    }
    setDurationSeconds(0);
    setMicError(null);
  }, [audioUrl]);

  return {
    isRecording,
    durationSeconds,
    waveformBars,
    audioUrl,
    micError,
    hasPermissionIssue,
    startRecording,
    stopRecording,
    clearAudio,
  };
}
