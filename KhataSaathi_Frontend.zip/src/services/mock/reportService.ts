import {
  Customer,
  CustomerSummary,
  LanguageCode,
  ReportPeriod,
  Transaction,
} from '@/src/types';
import {
  getDayKey,
  getIntlLocale,
  isSameLocalDay,
  isWithinLastDays,
} from '@/src/utils/date';
import { getTranslations } from '@/src/utils/i18n';
import { computeAllCustomerSummaries } from './ledgerEngine';

export interface ChartPoint {
  label: string;
  dateKey: string;
  creditRupees: number;
  repaymentRupees: number;
  creditPaise: number;
  repaymentPaise: number;
}

export interface PeriodReport {
  period: ReportPeriod;
  totalCreditPaise: number;
  totalRepaymentPaise: number;
  netChangePaise: number;
  transactionCount: number;
  voiceCount: number;
  manualCount: number;
  chartSeries: ChartPoint[];
  topDebtors: CustomerSummary[];
  totalOutstandingPaise: number;
}

export function buildSevenDaySeries(
  transactions: Transaction[],
  lang: LanguageCode = 'en'
): ChartPoint[] {
  const days: ChartPoint[] = [];
  const map = new Map<string, ChartPoint>();
  const t = getTranslations(lang);
  const locale = getIntlLocale(lang);

  for (let i = 6; i >= 0; i--) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    const key = getDayKey(d);
    const label =
      i === 0
        ? t.labels.today
        : d.toLocaleDateString(locale, { weekday: 'short' });
    const point: ChartPoint = {
      label,
      dateKey: key,
      creditRupees: 0,
      repaymentRupees: 0,
      creditPaise: 0,
      repaymentPaise: 0,
    };
    days.push(point);
    map.set(key, point);
  }

  for (const txn of transactions) {
    if (txn.status !== 'POSTED') continue;
    const key = getDayKey(txn.occurredAt);
    const bucket = map.get(key);
    if (!bucket) continue;
    if (txn.type === 'CREDIT') {
      bucket.creditPaise += txn.amountPaise;
      bucket.creditRupees = Number((bucket.creditPaise / 100).toFixed(2));
    } else if (txn.type === 'REPAYMENT') {
      bucket.repaymentPaise += txn.amountPaise;
      bucket.repaymentRupees = Number((bucket.repaymentPaise / 100).toFixed(2));
    }
  }

  return days;
}

export function generatePeriodReport(
  period: ReportPeriod,
  customers: Customer[],
  transactions: Transaction[],
  lang: LanguageCode = 'en'
): PeriodReport {
  const now = new Date();
  const t = getTranslations(lang);
  const filteredTxns = transactions.filter((txn) => {
    if (txn.status !== 'POSTED') return false;
    if (period === 'DAILY') return isSameLocalDay(txn.occurredAt, now);
    if (period === 'WEEKLY') return isWithinLastDays(txn.occurredAt, 7, now);
    return isWithinLastDays(txn.occurredAt, 30, now);
  });

  let totalCreditPaise = 0;
  let totalRepaymentPaise = 0;
  let voiceCount = 0;
  let manualCount = 0;

  for (const txn of filteredTxns) {
    if (txn.type === 'CREDIT') totalCreditPaise += txn.amountPaise;
    if (txn.type === 'REPAYMENT') totalRepaymentPaise += txn.amountPaise;
    if (txn.source === 'VOICE') voiceCount += 1;
    else manualCount += 1;
  }

  let chartSeries: ChartPoint[] = [];
  if (period === 'DAILY') {
    const buckets: ChartPoint[] = [
      { label: t.reports.buckets.morning, dateKey: '0', creditRupees: 0, repaymentRupees: 0, creditPaise: 0, repaymentPaise: 0 },
      { label: t.reports.buckets.afternoon, dateKey: '1', creditRupees: 0, repaymentRupees: 0, creditPaise: 0, repaymentPaise: 0 },
      { label: t.reports.buckets.evening, dateKey: '2', creditRupees: 0, repaymentRupees: 0, creditPaise: 0, repaymentPaise: 0 },
      { label: t.reports.buckets.night, dateKey: '3', creditRupees: 0, repaymentRupees: 0, creditPaise: 0, repaymentPaise: 0 },
    ];
    for (const txn of filteredTxns) {
      const hour = new Date(txn.occurredAt).getHours();
      const idx = hour < 12 ? 0 : hour < 17 ? 1 : hour < 21 ? 2 : 3;
      if (txn.type === 'CREDIT') {
        buckets[idx].creditPaise += txn.amountPaise;
        buckets[idx].creditRupees = Number((buckets[idx].creditPaise / 100).toFixed(2));
      } else if (txn.type === 'REPAYMENT') {
        buckets[idx].repaymentPaise += txn.amountPaise;
        buckets[idx].repaymentRupees = Number((buckets[idx].repaymentPaise / 100).toFixed(2));
      }
    }
    chartSeries = buckets;
  } else if (period === 'WEEKLY') {
    chartSeries = buildSevenDaySeries(transactions, lang);
  } else {
    const weekBuckets: ChartPoint[] = [
      { label: t.reports.buckets.week1, dateKey: 'w1', creditRupees: 0, repaymentRupees: 0, creditPaise: 0, repaymentPaise: 0 },
      { label: t.reports.buckets.week2, dateKey: 'w2', creditRupees: 0, repaymentRupees: 0, creditPaise: 0, repaymentPaise: 0 },
      { label: t.reports.buckets.week3, dateKey: 'w3', creditRupees: 0, repaymentRupees: 0, creditPaise: 0, repaymentPaise: 0 },
      { label: t.reports.buckets.week4, dateKey: 'w4', creditRupees: 0, repaymentRupees: 0, creditPaise: 0, repaymentPaise: 0 },
    ];
    for (const txn of filteredTxns) {
      const diffDays = Math.floor((now.getTime() - new Date(txn.occurredAt).getTime()) / (1000 * 60 * 60 * 24));
      const idx = diffDays >= 21 ? 0 : diffDays >= 14 ? 1 : diffDays >= 7 ? 2 : 3;
      if (txn.type === 'CREDIT') {
        weekBuckets[idx].creditPaise += txn.amountPaise;
        weekBuckets[idx].creditRupees = Number((weekBuckets[idx].creditPaise / 100).toFixed(2));
      } else if (txn.type === 'REPAYMENT') {
        weekBuckets[idx].repaymentPaise += txn.amountPaise;
        weekBuckets[idx].repaymentRupees = Number((weekBuckets[idx].repaymentPaise / 100).toFixed(2));
      }
    }
    chartSeries = weekBuckets;
  }

  const summaries = computeAllCustomerSummaries(
    customers.filter((c) => c.status === 'ACTIVE'),
    transactions
  );
  const totalOutstandingPaise = summaries.reduce((sum, s) => sum + s.currentBalancePaise, 0);
  const topDebtors = summaries
    .filter((s) => s.currentBalancePaise > 0)
    .sort((a, b) => b.currentBalancePaise - a.currentBalancePaise);

  return {
    period,
    totalCreditPaise,
    totalRepaymentPaise,
    netChangePaise: totalCreditPaise - totalRepaymentPaise,
    transactionCount: filteredTxns.filter((txn) => txn.type !== 'REVERSAL').length,
    voiceCount,
    manualCount,
    chartSeries,
    topDebtors,
    totalOutstandingPaise,
  };
}

export function exportTransactionsToCsv(customers: Customer[], transactions: Transaction[]): string {
  const customerMap = new Map(customers.map((c) => [c.id, c.name]));
  const header = ['Transaction ID', 'Date', 'Customer', 'Type', 'Amount (INR)', 'Source', 'Status', 'Description'];
  const rows = [...transactions]
    .sort((a, b) => new Date(b.occurredAt).getTime() - new Date(a.occurredAt).getTime())
    .map((t) => [
      t.id,
      new Date(t.occurredAt).toISOString(),
      `"${(customerMap.get(t.customerId) || 'Unknown').replace(/"/g, '""')}"`,
      t.type,
      (t.amountPaise / 100).toFixed(2),
      t.source,
      t.status,
      `"${t.description.replace(/"/g, '""')}"`,
    ]);

  return [header.join(','), ...rows.map((r) => r.join(','))].join('\n');
}
