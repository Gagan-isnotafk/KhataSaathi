import { Customer, LanguageCode, ParsedVoiceCommand, VoiceIntent } from '@/src/types';

export interface VoicePresetSample {
  id: string;
  transcript: string;
  language: LanguageCode;
}

export const VOICE_SAMPLE_PROMPTS: VoicePresetSample[] = [
  {
    id: 'sample_ramesh_credit',
    transcript: 'Ramesh ka 340 rupaye udhaar likho',
    language: 'hi',
  },
  {
    id: 'sample_ramesh_kumar_exact',
    transcript: 'Ramesh Kumar ka 340 rupaye udhaar likho',
    language: 'hi',
  },
  {
    id: 'sample_suresh_repayment',
    transcript: 'Suresh ne 500 rupaye wapas diye',
    language: 'hi',
  },
  {
    id: 'sample_mohan_decimal',
    transcript: 'Add 1,250.50 credit for Mohan',
    language: 'en',
  },
  {
    id: 'sample_anita_balance',
    transcript: 'Anita ka balance kitna hai?',
    language: 'hi',
  },
  {
    id: 'sample_daily_summary',
    transcript: 'Aaj ka hisaab batao',
    language: 'hi',
  },
  {
    id: 'sample_kannada_credit',
    transcript: 'Karim avara 250 rupayi udri bari',
    language: 'kn',
  },
  {
    id: 'sample_kannada_repayment',
    transcript: 'Suresh avaru 500 rupayi kottaru',
    language: 'kn',
  },
  {
    id: 'sample_create_customer',
    transcript: 'Naya customer Arjun Mehta add karo',
    language: 'hi',
  },
];

const WORD_NUMBERS: Record<string, number> = {
  ek: 1,
  do: 2,
  teen: 3,
  char: 4,
  paanch: 5,
  panch: 5,
  chhe: 6,
  saat: 7,
  aath: 8,
  nau: 9,
  das: 10,
  bees: 20,
  tees: 30,
  chalis: 40,
  pachaas: 50,
  sau: 100,
  hazaar: 1000,
  hazar: 1000,
};

function extractAmountPaise(text: string): number | null {
  const numericMatch = text.match(/(?:₹|rs\.?|inr)?\s*(\d[\d,]*(?:\.\d{1,2})?)/i);
  if (numericMatch) {
    const cleaned = numericMatch[1].replace(/,/g, '');
    const parsed = Number.parseFloat(cleaned);
    if (Number.isFinite(parsed) && parsed > 0) {
      return Math.round(parsed * 100);
    }
  }

  const tokens = text.toLowerCase().split(/\s+/);
  let total = 0;
  let current = 0;
  for (const tok of tokens) {
    const val = WORD_NUMBERS[tok];
    if (!val) continue;
    if (val === 100 || val === 1000) {
      current = (current || 1) * val;
      if (val === 1000) {
        total += current;
        current = 0;
      }
    } else {
      current += val;
    }
  }
  total += current;
  return total > 0 ? total * 100 : null;
}

function detectIntent(lower: string): VoiceIntent {
  if (
    lower.includes('aaj ka hisaab') ||
    lower.includes('daily summary') ||
    lower.includes('today summary') ||
    lower.includes('aaj kitna') ||
    lower.includes('today credit') ||
    lower.includes('indina lekka') ||
    lower.includes('आज का हिसाब') ||
    lower.includes('ಇಂದಿನ ಲೆಕ್ಕ')
  ) {
    return 'DAILY_SUMMARY';
  }

  if (
    lower.includes('total udhaar') ||
    lower.includes('total outstanding') ||
    lower.includes('kul baaki') ||
    lower.includes('sabka balance') ||
    lower.includes('ottu baki') ||
    lower.includes('कुल बकाया') ||
    lower.includes('ಒಟ್ಟು ಬಾಕಿ')
  ) {
    return 'TOTAL_OUTSTANDING';
  }

  if (
    lower.includes('naya customer') ||
    lower.includes('new customer') ||
    lower.includes('create customer') ||
    lower.includes('customer add') ||
    lower.includes('hosa grahaka') ||
    lower.includes('नया ग्राहक') ||
    lower.includes('ಹೊಸ ಗ್ರಾಹಕ')
  ) {
    return 'CREATE_CUSTOMER';
  }

  if (
    lower.includes('pichla') ||
    lower.includes('history') ||
    lower.includes('transactions') ||
    lower.includes('ledger') ||
    lower.includes('dikhao') ||
    lower.includes('itihasa')
  ) {
    return 'CUSTOMER_HISTORY';
  }

  if (
    lower.includes('balance') ||
    lower.includes('baaki') ||
    lower.includes('kitna hai') ||
    lower.includes('batao') ||
    lower.includes('baki eshtu') ||
    lower.includes('बकाया') ||
    lower.includes('ಬಾಕಿ')
  ) {
    return 'CHECK_BALANCE';
  }

  if (
    lower.includes('wapas') ||
    lower.includes('diye') ||
    lower.includes('diya hai') ||
    lower.includes('jama') ||
    lower.includes('repayment') ||
    lower.includes('paid') ||
    lower.includes('payment') ||
    lower.includes('received') ||
    lower.includes('mila') ||
    lower.includes('pavathi') ||
    lower.includes('kottaru') ||
    lower.includes('kottidare') ||
    lower.includes('जमा') ||
    lower.includes('वापस') ||
    lower.includes('ಪಾವತಿ') ||
    lower.includes('ಕೊಟ್ಟರು')
  ) {
    return 'RECORD_REPAYMENT';
  }

  if (
    lower.includes('udhaar') ||
    lower.includes('udhar') ||
    lower.includes('udri') ||
    lower.includes('credit') ||
    lower.includes('likho') ||
    lower.includes('likh') ||
    lower.includes('bari') ||
    lower.includes('bareyiri') ||
    lower.includes('add') ||
    lower.includes('khata') ||
    lower.includes('उधार') ||
    lower.includes('ಉದ್ರಿ') ||
    lower.includes('ಬರೆಯಿರಿ')
  ) {
    return 'ADD_CREDIT';
  }

  return 'UNKNOWN';
}

function matchCustomerCandidates(transcript: string, customers: Customer[]): {
  query: string | null;
  candidates: Customer[];
} {
  const lower = transcript.toLowerCase();
  const activeCustomers = customers.filter((c) => c.status === 'ACTIVE');

  const fullMatches = activeCustomers.filter((c) => lower.includes(c.name.toLowerCase()));
  if (fullMatches.length > 0) {
    return { query: fullMatches[0].name, candidates: fullMatches };
  }

  const words = lower
    .replace(/[^a-z\s]/g, ' ')
    .split(/\s+/)
    .filter((w) => w.length >= 3);

  const stopWords = new Set([
    'ka', 'ki', 'ke', 'ko', 'ne', 'se', 'rupaye', 'rupee', 'rupees', 'rupayi',
    'udhaar', 'udhar', 'udri', 'credit', 'likho', 'likh', 'add', 'karo', 'bari',
    'bareyiri', 'kottaru', 'wapas', 'diye', 'jama', 'paid', 'payment', 'repayment',
    'balance', 'kitna', 'hai', 'batao', 'hisaab', 'aaj', 'naya', 'customer', 'avara',
    'avaru', 'pichla', 'transaction', 'dikhao', 'for', 'the', 'from', 'his', 'her',
  ]);

  const candidateWords = words.filter((w) => !stopWords.has(w));
  const matchedSet = new Map<string, Customer>();
  let matchedWord: string | null = null;

  for (const word of candidateWords) {
    for (const cust of activeCustomers) {
      const nameParts = cust.name.toLowerCase().split(/\s+/);
      if (nameParts.some((part) => part === word || (word.length >= 4 && part.startsWith(word)))) {
        matchedSet.set(cust.id, cust);
        matchedWord = word;
      }
    }
  }

  if (matchedSet.size > 0) {
    return {
      query: matchedWord ? matchedWord.charAt(0).toUpperCase() + matchedWord.slice(1) : null,
      candidates: Array.from(matchedSet.values()),
    };
  }

  return { query: candidateWords[0] || null, candidates: [] };
}

function extractNewCustomerName(transcript: string): string | null {
  const cleaned = transcript
    .replace(/naya customer|new customer|create customer|add customer|add karo|likho|create|karo/gi, '')
    .replace(/\s+/g, ' ')
    .trim();
  if (!cleaned) return null;
  return cleaned
    .split(' ')
    .map((w) => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase())
    .join(' ');
}

function extractDescription(transcript: string, intent: VoiceIntent): string {
  const lower = transcript.toLowerCase();
  const itemKeywords = ['ration', 'grocery', 'groceries', 'rice', 'chawal', 'milk', 'tea', 'chai', 'oil', 'sugar', 'atta', 'dal', 'snacks', 'biscuit', 'upi', 'cash', 'gpay', 'phonepe'];
  const found = itemKeywords.filter((k) => lower.includes(k));
  if (found.length > 0) {
    return `Voice: ${found.map((f) => f.charAt(0).toUpperCase() + f.slice(1)).join(', ')}`;
  }
  if (intent === 'ADD_CREDIT') return 'Voice credit entry';
  if (intent === 'RECORD_REPAYMENT') return 'Voice repayment received';
  return 'Voice entry';
}

function getLocalizedClarification(
  type: NonNullable<ParsedVoiceCommand['clarificationType']>,
  lang: LanguageCode,
  query?: string | null
): string {
  if (lang === 'hi') {
    switch (type) {
      case 'UNKNOWN_COMMAND':
        return 'बात समझ नहीं आई। जैसे बोलें: "Ramesh ka 340 rupaye udhaar likho" या ऊपर वाक्य बदलें।';
      case 'MISSING_CUSTOMER':
        return query
          ? `"${query}" नाम का कोई सक्रिय ग्राहक नहीं मिला। नीचे से ग्राहक चुनें या वाक्य सुधारें।`
          : 'यह एंट्री किस ग्राहक के लिए है, पहचान नहीं हो सकी। कृपया नीचे से ग्राहक चुनें।';
      case 'DUPLICATE_CUSTOMER':
        return `"${query || ''}" से मिलते-जुलते एक से ज़्यादा ग्राहक मिले। सही ग्राहक चुनें:`;
      case 'MISSING_AMOUNT':
        return `ग्राहक ${query || ''} मिल गया, लेकिन राशि गायब है। नीचे ₹ राशि दर्ज करें।`;
      default:
        return 'कृपया विवरण जांचें।';
    }
  }
  if (lang === 'kn') {
    switch (type) {
      case 'UNKNOWN_COMMAND':
        return 'ಆಜ್ಞೆ ಅರ್ಥವಾಗಲಿಲ್ಲ. ಉದಾ: "Karim avara 250 rupayi udri bari" ಎಂದು ಹೇಳಿ ಅಥವಾ ಮೇಲಿನ ವಾಕ್ಯ ಬದಲಿಸಿ.';
      case 'MISSING_CUSTOMER':
        return query
          ? `"${query}" ಗೆ ಹೊಂದುವ ಸಕ್ರಿಯ ಗ್ರಾಹಕರು ಸಿಗಲಿಲ್ಲ. ಕೆಳಗಿನಿಂದ ಗ್ರಾಹಕರನ್ನು ಆಯ್ಕೆಮಾಡಿ ಅಥವಾ ವಾಕ್ಯ ತಿದ್ದುಪಡಿ ಮಾಡಿ.`
          : 'ಈ ದಾಖಲೆ ಯಾವ ಗ್ರಾಹಕರಿಗೆಂದು ಗುರುತಿಸಲು ಆಗಲಿಲ್ಲ. ದಯವಿಟ್ಟು ಕೆಳಗೆ ಗ್ರಾಹಕರನ್ನು ಆಯ್ಕೆಮಾಡಿ.';
      case 'DUPLICATE_CUSTOMER':
        return `"${query || ''}" ಗೆ ಒಂದಕ್ಕಿಂತ ಹೆಚ್ಚು ಗ್ರಾಹಕರು ಹೊಂದುತ್ತಾರೆ. ದಯವಿಟ್ಟು ಸರಿಯಾದ ಗ್ರಾಹಕರನ್ನು ಆಯ್ಕೆಮಾಡಿ:`;
      case 'MISSING_AMOUNT':
        return `ಗ್ರಾಹಕ ${query || ''} ಸಿಕ್ಕಿದ್ದಾರೆ, ಆದರೆ ಮೊತ್ತ ಇಲ್ಲ. ಕೆಳಗೆ ₹ ಮೊತ್ತವನ್ನು ನಮೂದಿಸಿ.`;
      default:
        return 'ದಯವಿಟ್ಟು ವಿವರಗಳನ್ನು ಪರಿಶೀಲಿಸಿ.';
    }
  }

  switch (type) {
    case 'UNKNOWN_COMMAND':
      return 'Could not understand the bookkeeping intent. Try saying e.g. "Ramesh ka 340 rupaye udhaar likho" or edit the transcript above.';
    case 'MISSING_CUSTOMER':
      return query
        ? `No active customer matched "${query}". Select an existing customer below or edit the transcript.`
        : 'Could not identify which customer this entry is for. Please select a customer below.';
    case 'DUPLICATE_CUSTOMER':
      return `Multiple customers match "${query || ''}". Please select the exact customer:`;
    case 'MISSING_AMOUNT':
      return `Customer ${query || ''} matched, but the amount was missing or zero. Enter the ₹ amount below.`;
    default:
      return 'Please review details.';
  }
}

export function interpretVoiceTranscript(
  transcript: string,
  customers: Customer[],
  lang: LanguageCode = 'en'
): ParsedVoiceCommand {
  const trimmed = transcript.trim();
  const lower = trimmed.toLowerCase();
  const intent = detectIntent(lower);

  if (!trimmed || intent === 'UNKNOWN') {
    return {
      intent: 'UNKNOWN',
      rawTranscript: trimmed,
      customerNameQuery: null,
      matchedCustomerId: null,
      candidateCustomerIds: [],
      amountPaise: null,
      currency: 'INR',
      description: '',
      isReadOnly: false,
      needsClarification: true,
      clarificationType: 'UNKNOWN_COMMAND',
      clarificationMessage: getLocalizedClarification('UNKNOWN_COMMAND', lang),
    };
  }

  if (intent === 'DAILY_SUMMARY' || intent === 'TOTAL_OUTSTANDING') {
    return {
      intent,
      rawTranscript: trimmed,
      customerNameQuery: null,
      matchedCustomerId: null,
      candidateCustomerIds: [],
      amountPaise: null,
      currency: 'INR',
      description: '',
      isReadOnly: true,
      needsClarification: false,
    };
  }

  if (intent === 'CREATE_CUSTOMER') {
    const newName = extractNewCustomerName(trimmed);
    if (!newName) {
      return {
        intent,
        rawTranscript: trimmed,
        customerNameQuery: null,
        matchedCustomerId: null,
        candidateCustomerIds: [],
        amountPaise: null,
        currency: 'INR',
        description: '',
        isReadOnly: false,
        needsClarification: true,
        clarificationType: 'MISSING_CUSTOMER',
        clarificationMessage: getLocalizedClarification('MISSING_CUSTOMER', lang),
      };
    }
    return {
      intent,
      rawTranscript: trimmed,
      customerNameQuery: newName,
      matchedCustomerId: null,
      candidateCustomerIds: [],
      amountPaise: null,
      currency: 'INR',
      description: 'Added via Voice Assistant',
      isReadOnly: false,
      needsClarification: false,
    };
  }

  const { query, candidates } = matchCustomerCandidates(trimmed, customers);
  const amountPaise = extractAmountPaise(trimmed);
  const isReadOnly = intent === 'CHECK_BALANCE' || intent === 'CUSTOMER_HISTORY';

  if (candidates.length === 0) {
    return {
      intent,
      rawTranscript: trimmed,
      customerNameQuery: query,
      matchedCustomerId: null,
      candidateCustomerIds: [],
      amountPaise,
      currency: 'INR',
      description: extractDescription(trimmed, intent),
      isReadOnly,
      needsClarification: true,
      clarificationType: 'MISSING_CUSTOMER',
      clarificationMessage: getLocalizedClarification('MISSING_CUSTOMER', lang, query),
    };
  }

  if (candidates.length > 1) {
    return {
      intent,
      rawTranscript: trimmed,
      customerNameQuery: query,
      matchedCustomerId: null,
      candidateCustomerIds: candidates.map((c) => c.id),
      amountPaise,
      currency: 'INR',
      description: extractDescription(trimmed, intent),
      isReadOnly,
      needsClarification: true,
      clarificationType: 'DUPLICATE_CUSTOMER',
      clarificationMessage: getLocalizedClarification('DUPLICATE_CUSTOMER', lang, query),
    };
  }

  const matchedCustomer = candidates[0];

  if (!isReadOnly && (!amountPaise || amountPaise <= 0)) {
    return {
      intent,
      rawTranscript: trimmed,
      customerNameQuery: matchedCustomer.name,
      matchedCustomerId: matchedCustomer.id,
      candidateCustomerIds: [matchedCustomer.id],
      amountPaise: null,
      currency: 'INR',
      description: extractDescription(trimmed, intent),
      isReadOnly: false,
      needsClarification: true,
      clarificationType: 'MISSING_AMOUNT',
      clarificationMessage: getLocalizedClarification('MISSING_AMOUNT', lang, matchedCustomer.name),
    };
  }

  return {
    intent,
    rawTranscript: trimmed,
    customerNameQuery: matchedCustomer.name,
    matchedCustomerId: matchedCustomer.id,
    candidateCustomerIds: [matchedCustomer.id],
    amountPaise,
    currency: 'INR',
    description: extractDescription(trimmed, intent),
    isReadOnly,
    needsClarification: false,
  };
}

export function simulateSpeechToText(
  recordedSeconds: number,
  lang: LanguageCode = 'en',
  chosenSample?: VoicePresetSample
): string {
  if (chosenSample) {
    return chosenSample.transcript;
  }
  if (recordedSeconds <= 1) {
    if (lang === 'kn') return 'Karim avara 250 rupayi udri bari';
    if (lang === 'en') return 'Add 1,250.50 credit for Mohan';
    return 'Ramesh ka 340 rupaye udhaar likho';
  }
  const langPrompts = VOICE_SAMPLE_PROMPTS.filter((p) => p.language === lang);
  const pool = langPrompts.length > 0 ? langPrompts : VOICE_SAMPLE_PROMPTS;
  const idx = recordedSeconds % pool.length;
  return pool[idx].transcript;
}
