import { Customer, CustomerSummary, LedgerEntry, Transaction } from '@/src/types';
import { isSameLocalDay } from '@/src/utils/date';

/**
 * Computes authoritative chronological ledger and balances in integer paise.
 * Formula: Opening Balance + Total Credit - Total Repayments (reversed txns are negated via reversal entries).
 */
export function computeCustomerLedger(
  customer: Customer,
  allTransactions: Transaction[]
): {
  entries: LedgerEntry[];
  totalCreditPaise: number;
  totalRepaymentPaise: number;
  currentBalancePaise: number;
  lastTransactionAt: string | null;
} {
  const customerTxns = allTransactions
    .filter((t) => t.customerId === customer.id && t.shopId === customer.shopId)
    .sort((a, b) => new Date(a.occurredAt).getTime() - new Date(b.occurredAt).getTime());

  let runningBalance = Math.round(customer.openingBalancePaise);
  let totalCredit = 0;
  let totalRepayment = 0;

  const entries: LedgerEntry[] = customerTxns.map((txn) => {
    if (txn.type === 'CREDIT') {
      runningBalance += txn.amountPaise;
      if (txn.status === 'POSTED') {
        totalCredit += txn.amountPaise;
      }
    } else if (txn.type === 'REPAYMENT') {
      runningBalance -= txn.amountPaise;
      if (txn.status === 'POSTED') {
        totalRepayment += txn.amountPaise;
      }
    } else if (txn.type === 'REVERSAL') {
      if (txn.reversalForType === 'CREDIT') {
        runningBalance -= txn.amountPaise;
      } else if (txn.reversalForType === 'REPAYMENT') {
        runningBalance += txn.amountPaise;
      }
    }

    return {
      transaction: txn,
      runningBalancePaise: runningBalance,
    };
  });

  const lastTxn = customerTxns.length > 0 ? customerTxns[customerTxns.length - 1].occurredAt : null;

  return {
    entries,
    totalCreditPaise: totalCredit,
    totalRepaymentPaise: totalRepayment,
    currentBalancePaise: runningBalance,
    lastTransactionAt: lastTxn,
  };
}

export function computeCustomerBalancePaise(customer: Customer, allTransactions: Transaction[]): number {
  return computeCustomerLedger(customer, allTransactions).currentBalancePaise;
}

export function computeAllCustomerSummaries(
  customers: Customer[],
  transactions: Transaction[]
): CustomerSummary[] {
  return customers.map((customer) => {
    const ledger = computeCustomerLedger(customer, transactions);
    return {
      customer,
      totalCreditPaise: ledger.totalCreditPaise,
      totalRepaymentPaise: ledger.totalRepaymentPaise,
      currentBalancePaise: ledger.currentBalancePaise,
      transactionCount: ledger.entries.length,
      lastTransactionAt: ledger.lastTransactionAt,
    };
  });
}

export function computeDashboardMetrics(customers: Customer[], transactions: Transaction[]) {
  const summaries = computeAllCustomerSummaries(
    customers.filter((c) => c.status === 'ACTIVE'),
    transactions
  );

  const totalOutstandingPaise = summaries.reduce((acc, s) => acc + s.currentBalancePaise, 0);
  const activeCustomerCount = summaries.length;

  const now = new Date();
  let todaysCreditPaise = 0;
  let todaysRepaymentPaise = 0;
  let todaysCount = 0;

  for (const txn of transactions) {
    if (txn.status === 'POSTED' && isSameLocalDay(txn.occurredAt, now)) {
      if (txn.type === 'CREDIT') {
        todaysCreditPaise += txn.amountPaise;
        todaysCount += 1;
      } else if (txn.type === 'REPAYMENT') {
        todaysRepaymentPaise += txn.amountPaise;
        todaysCount += 1;
      }
    }
  }

  return {
    totalOutstandingPaise,
    todaysCreditPaise,
    todaysRepaymentPaise,
    todaysCount,
    activeCustomerCount,
    summaries,
  };
}

export function findDuplicateCustomerMatches(
  name: string,
  phone: string | undefined,
  customers: Customer[],
  excludeCustomerId?: string
): Customer[] {
  const cleanName = name.trim().toLowerCase();
  const cleanPhone = (phone || '').replace(/\D/g, '');

  return customers.filter((c) => {
    if (excludeCustomerId && c.id === excludeCustomerId) return false;
    const existingName = c.name.trim().toLowerCase();
    const existingPhone = (c.phone || '').replace(/\D/g, '');

    const phoneMatch = cleanPhone.length >= 6 && existingPhone.length >= 6 && existingPhone === cleanPhone;
    const nameMatch =
      cleanName.length >= 2 &&
      (existingName === cleanName ||
        existingName.includes(cleanName) ||
        cleanName.includes(existingName));

    return phoneMatch || nameMatch;
  });
}
