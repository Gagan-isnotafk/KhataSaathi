import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import {
  DEMO_SHOP,
  DEMO_USER,
  SAMPLE_AUDIT_LOGS,
  SAMPLE_CUSTOMERS,
  SAMPLE_TRANSACTIONS,
} from '@/src/data/sampleData';
import {
  computeAllCustomerSummaries,
  computeDashboardMetrics,
} from '@/src/services/mock/ledgerEngine';
import {
  AuditLog,
  AuthSession,
  Customer,
  CustomerSummary,
  LanguageCode,
  Shop,
  ShopCategory,
  Transaction,
  TransactionSource,
  User,
} from '@/src/types';
import { getTranslations, Translations } from '@/src/utils/i18n';
import { generateId } from '@/src/utils/idempotency';

const STORAGE_KEYS = {
  SESSION: 'khatasaathi_v1_session',
  USER: 'khatasaathi_v1_user',
  SHOP: 'khatasaathi_v1_shop',
  LANGUAGE: 'khatasaathi_v1_language',
  CUSTOMERS: 'khatasaathi_v1_customers',
  TRANSACTIONS: 'khatasaathi_v1_transactions',
  AUDIT_LOGS: 'khatasaathi_v1_audit_logs',
};

function readStorage<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

function readStoredLanguage(): LanguageCode | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.LANGUAGE);
    if (raw === 'en' || raw === 'hi' || raw === 'kn') return raw;
    return null;
  } catch {
    return null;
  }
}

function writeStorage<T>(key: string, value: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    // Ignore storage quota issues safely
  }
}

export interface ActionResult<T = undefined> {
  ok: boolean;
  data?: T;
  error?: string;
}

interface AppContextValue {
  session: AuthSession;
  user: User;
  shop: Shop;
  customers: Customer[];
  transactions: Transaction[];
  auditLogs: AuditLog[];
  customerSummaries: CustomerSummary[];
  dashboardMetrics: ReturnType<typeof computeDashboardMetrics>;
  t: Translations;

  loginWithOtp: (phone: string) => void;
  registerWithOtp: (name: string, phone: string) => void;
  loginAsDemoShopkeeper: () => void;
  logout: () => void;

  completeShopSetup: (payload: {
    name: string;
    ownerName: string;
    category: ShopCategory;
    language: LanguageCode;
    address?: string;
  }) => ActionResult;
  updateShop: (updates: Partial<Shop>) => ActionResult;
  setLanguage: (lang: LanguageCode) => void;

  addCustomer: (payload: {
    name: string;
    phone?: string;
    notes?: string;
    openingBalancePaise?: number;
  }) => ActionResult<Customer>;
  updateCustomer: (
    customerId: string,
    updates: { name: string; phone?: string; notes?: string }
  ) => ActionResult<Customer>;
  toggleCustomerStatus: (customerId: string) => ActionResult;

  recordTransaction: (payload: {
    customerId: string;
    type: 'CREDIT' | 'REPAYMENT';
    amountPaise: number;
    description: string;
    source: TransactionSource;
    occurredAt?: string;
    idempotencyKey: string;
  }) => ActionResult<Transaction>;

  reverseTransaction: (transactionId: string, reason?: string) => ActionResult<Transaction>;
  resetDemoData: () => void;
}

const DEFAULT_SESSION: AuthSession = {
  isAuthenticated: false,
  isShopSetupComplete: false,
  token: '',
  userId: '',
};

const AppContext = createContext<AppContextValue | null>(null);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [session, setSession] = useState<AuthSession>(() =>
    readStorage<AuthSession>(STORAGE_KEYS.SESSION, DEFAULT_SESSION)
  );
  const [user, setUser] = useState<User>(() =>
    readStorage<User>(STORAGE_KEYS.USER, DEMO_USER)
  );
  const [shop, setShop] = useState<Shop>(() => {
    const storedShop = readStorage<Shop>(STORAGE_KEYS.SHOP, DEMO_SHOP);
    const storedLang = readStoredLanguage();
    return storedLang ? { ...storedShop, language: storedLang } : storedShop;
  });
  const [customers, setCustomers] = useState<Customer[]>(() =>
    readStorage<Customer[]>(STORAGE_KEYS.CUSTOMERS, SAMPLE_CUSTOMERS)
  );
  const [transactions, setTransactions] = useState<Transaction[]>(() =>
    readStorage<Transaction[]>(STORAGE_KEYS.TRANSACTIONS, SAMPLE_TRANSACTIONS)
  );
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>(() =>
    readStorage<AuditLog[]>(STORAGE_KEYS.AUDIT_LOGS, SAMPLE_AUDIT_LOGS)
  );

  useEffect(() => {
    writeStorage(STORAGE_KEYS.SESSION, session);
  }, [session]);

  useEffect(() => {
    writeStorage(STORAGE_KEYS.USER, user);
  }, [user]);

  useEffect(() => {
    writeStorage(STORAGE_KEYS.SHOP, shop);
    try {
      localStorage.setItem(STORAGE_KEYS.LANGUAGE, shop.language);
    } catch {
      // Ignore storage errors safely
    }
    if (typeof document !== 'undefined') {
      document.documentElement.lang = shop.language;
    }
  }, [shop]);

  useEffect(() => {
    writeStorage(STORAGE_KEYS.CUSTOMERS, customers);
  }, [customers]);

  useEffect(() => {
    writeStorage(STORAGE_KEYS.TRANSACTIONS, transactions);
  }, [transactions]);

  useEffect(() => {
    writeStorage(STORAGE_KEYS.AUDIT_LOGS, auditLogs);
  }, [auditLogs]);

  const t = useMemo(() => getTranslations(shop.language), [shop.language]);

  const appendAudit = useCallback(
    (
      action: string,
      entityType: AuditLog['entityType'],
      entityId: string,
      summary: string
    ) => {
      const log: AuditLog = {
        id: generateId('aud'),
        shopId: shop.id,
        actorId: user.id,
        action,
        entityType,
        entityId,
        summary,
        createdAt: new Date().toISOString(),
      };
      setAuditLogs((prev) => [log, ...prev].slice(0, 100));
    },
    [shop.id, user.id]
  );

  const loginWithOtp = useCallback((phone: string) => {
    const cleanPhone = phone.trim();
    const now = new Date().toISOString();
    setUser((prev) => ({
      ...prev,
      phone: cleanPhone || prev.phone,
      updatedAt: now,
    }));
    setSession({
      isAuthenticated: true,
      isShopSetupComplete: true,
      token: generateId('tok'),
      userId: DEMO_USER.id,
    });
  }, []);

  const registerWithOtp = useCallback((name: string, phone: string) => {
    const now = new Date().toISOString();
    const newUserId = generateId('usr');
    const cleanName = name.trim();
    const cleanPhone = phone.trim();

    setUser({
      id: newUserId,
      name: cleanName,
      phone: cleanPhone,
      status: 'ACTIVE',
      createdAt: now,
      updatedAt: now,
    });

    setShop((prev) => ({
      ...prev,
      ownerId: newUserId,
      ownerName: cleanName,
    }));

    setSession({
      isAuthenticated: true,
      isShopSetupComplete: false,
      token: generateId('tok'),
      userId: newUserId,
    });
  }, []);

  const loginAsDemoShopkeeper = useCallback(() => {
    setUser(DEMO_USER);
    setSession({
      isAuthenticated: true,
      isShopSetupComplete: true,
      token: generateId('tok_demo'),
      userId: DEMO_USER.id,
    });
  }, []);

  const logout = useCallback(() => {
    setSession(DEFAULT_SESSION);
  }, []);

  const completeShopSetup = useCallback(
    (payload: {
      name: string;
      ownerName: string;
      category: ShopCategory;
      language: LanguageCode;
      address?: string;
    }): ActionResult => {
      const dict = getTranslations(payload.language);
      if (!payload.name.trim() || !payload.ownerName.trim()) {
        return { ok: false, error: dict.errors.shopRequired };
      }

      setShop((prev) => ({
        ...prev,
        name: payload.name.trim(),
        ownerName: payload.ownerName.trim(),
        category: payload.category,
        language: payload.language,
        address: payload.address?.trim() || undefined,
      }));
      setUser((prev) => ({
        ...prev,
        name: payload.ownerName.trim(),
        updatedAt: new Date().toISOString(),
      }));
      setSession((prev) => ({
        ...prev,
        isShopSetupComplete: true,
      }));
      appendAudit('SHOP_SETUP_COMPLETED', 'SHOP', shop.id, `Updated shop "${payload.name.trim()}"`);
      return { ok: true };
    },
    [appendAudit, shop.id]
  );

  const updateShop = useCallback(
    (updates: Partial<Shop>): ActionResult => {
      const dict = getTranslations(updates.language || shop.language);
      if (updates.name !== undefined && !updates.name.trim()) {
        return { ok: false, error: dict.errors.shopNameEmpty };
      }
      setShop((prev) => ({ ...prev, ...updates }));
      if (updates.ownerName) {
        setUser((prev) => ({
          ...prev,
          name: updates.ownerName!.trim(),
          updatedAt: new Date().toISOString(),
        }));
      }
      appendAudit('SHOP_UPDATED', 'SHOP', shop.id, 'Updated shop settings');
      return { ok: true };
    },
    [appendAudit, shop.id, shop.language]
  );

  const setLanguage = useCallback((lang: LanguageCode) => {
    setShop((prev) => ({ ...prev, language: lang }));
  }, []);

  const addCustomer = useCallback(
    (payload: {
      name: string;
      phone?: string;
      notes?: string;
      openingBalancePaise?: number;
    }): ActionResult<Customer> => {
      const cleanName = payload.name.trim();
      if (cleanName.length < 2) {
        return { ok: false, error: t.errors.customerNameMin };
      }
      const openingPaise = Math.round(payload.openingBalancePaise ?? 0);
      if (!Number.isFinite(openingPaise) || openingPaise < 0) {
        return { ok: false, error: t.errors.openingNegative };
      }

      const newCustomer: Customer = {
        id: generateId('cust'),
        shopId: shop.id,
        name: cleanName,
        phone: payload.phone?.trim() || undefined,
        notes: payload.notes?.trim() || undefined,
        openingBalancePaise: openingPaise,
        status: 'ACTIVE',
        createdAt: new Date().toISOString(),
      };

      setCustomers((prev) => [newCustomer, ...prev]);
      appendAudit('CUSTOMER_CREATED', 'CUSTOMER', newCustomer.id, `Added customer ${cleanName}`);
      return { ok: true, data: newCustomer };
    },
    [appendAudit, shop.id, t.errors]
  );

  const updateCustomer = useCallback(
    (
      customerId: string,
      updates: { name: string; phone?: string; notes?: string }
    ): ActionResult<Customer> => {
      const cleanName = updates.name.trim();
      if (cleanName.length < 2) {
        return { ok: false, error: t.errors.customerNameMin };
      }

      let updated: Customer | undefined;
      setCustomers((prev) =>
        prev.map((c) => {
          if (c.id !== customerId) return c;
          updated = {
            ...c,
            name: cleanName,
            phone: updates.phone?.trim() || undefined,
            notes: updates.notes?.trim() || undefined,
          };
          return updated;
        })
      );

      if (!updated) {
        return { ok: false, error: t.errors.customerNotFound };
      }
      appendAudit('CUSTOMER_UPDATED', 'CUSTOMER', customerId, `Updated customer ${cleanName}`);
      return { ok: true, data: updated };
    },
    [appendAudit, t.errors]
  );

  const toggleCustomerStatus = useCallback(
    (customerId: string): ActionResult => {
      const target = customers.find((c) => c.id === customerId);
      if (!target) return { ok: false, error: t.errors.customerNotFound };

      const nextStatus = target.status === 'ACTIVE' ? 'INACTIVE' : 'ACTIVE';
      setCustomers((prev) =>
        prev.map((c) => (c.id === customerId ? { ...c, status: nextStatus } : c))
      );
      appendAudit(
        nextStatus === 'INACTIVE' ? 'CUSTOMER_DEACTIVATED' : 'CUSTOMER_REACTIVATED',
        'CUSTOMER',
        customerId,
        `${nextStatus === 'INACTIVE' ? 'Deactivated' : 'Reactivated'} ${target.name}`
      );
      return { ok: true };
    },
    [appendAudit, customers, t.errors]
  );

  const recordTransaction = useCallback(
    (payload: {
      customerId: string;
      type: 'CREDIT' | 'REPAYMENT';
      amountPaise: number;
      description: string;
      source: TransactionSource;
      occurredAt?: string;
      idempotencyKey: string;
    }): ActionResult<Transaction> => {
      const customer = customers.find(
        (c) => c.id === payload.customerId && c.shopId === shop.id
      );
      if (!customer) {
        return { ok: false, error: t.errors.selectedCustomerNotFound };
      }

      if (customer.status !== 'ACTIVE') {
        return { ok: false, error: t.errors.inactiveCustomerEntry };
      }

      const amount = Math.round(payload.amountPaise);
      if (!Number.isFinite(amount) || amount <= 0) {
        return { ok: false, error: t.errors.amountGreaterThanZero };
      }

      const existing = transactions.find(
        (txn) => txn.idempotencyKey === payload.idempotencyKey
      );
      if (existing) {
        return { ok: true, data: existing };
      }

      const now = new Date().toISOString();
      const newTxn: Transaction = {
        id: generateId('txn'),
        shopId: shop.id,
        customerId: customer.id,
        type: payload.type,
        amountPaise: amount,
        description:
          payload.description.trim() ||
          (payload.type === 'CREDIT' ? 'Credit entry' : 'Repayment received'),
        source: payload.source,
        createdBy: user.id,
        occurredAt: payload.occurredAt || now,
        createdAt: now,
        status: 'POSTED',
        idempotencyKey: payload.idempotencyKey,
      };

      setTransactions((prev) => [newTxn, ...prev]);
      appendAudit(
        'TRANSACTION_POSTED',
        'TRANSACTION',
        newTxn.id,
        `${payload.source} ${payload.type} ₹${(amount / 100).toFixed(2)} for ${customer.name}`
      );

      return { ok: true, data: newTxn };
    },
    [appendAudit, customers, shop.id, t.errors, transactions, user.id]
  );

  const reverseTransaction = useCallback(
    (transactionId: string, reason?: string): ActionResult<Transaction> => {
      const target = transactions.find((txn) => txn.id === transactionId);
      if (!target) {
        return { ok: false, error: t.errors.txnNotFound };
      }
      if (target.status === 'REVERSED' || target.type === 'REVERSAL') {
        return { ok: false, error: t.errors.alreadyReversed };
      }

      const customer = customers.find((c) => c.id === target.customerId);
      const now = new Date().toISOString();
      const reversalTxn: Transaction = {
        id: generateId('rev'),
        shopId: target.shopId,
        customerId: target.customerId,
        type: 'REVERSAL',
        amountPaise: target.amountPaise,
        description: reason?.trim()
          ? `Reversal: ${reason.trim()} (Ref ${target.id})`
          : `Reversal of ${target.type.toLowerCase()} entry (${target.description})`,
        source: 'MANUAL',
        createdBy: user.id,
        occurredAt: now,
        createdAt: now,
        status: 'POSTED',
        idempotencyKey: `rev_${target.id}`,
        reversedTransactionId: target.id,
        reversalForType: target.type,
      };

      setTransactions((prev) => [
        reversalTxn,
        ...prev.map((txn) => (txn.id === target.id ? { ...txn, status: 'REVERSED' as const } : txn)),
      ]);
      appendAudit(
        'TRANSACTION_REVERSED',
        'TRANSACTION',
        target.id,
        `Reversed ₹${(target.amountPaise / 100).toFixed(2)} for ${customer?.name || target.customerId}`
      );
      return { ok: true, data: reversalTxn };
    },
    [appendAudit, customers, t.errors, transactions, user.id]
  );

  const resetDemoData = useCallback(() => {
    setUser(DEMO_USER);
    setShop((prev) => ({
      ...DEMO_SHOP,
      language: prev.language,
    }));
    setCustomers(SAMPLE_CUSTOMERS);
    setTransactions(SAMPLE_TRANSACTIONS);
    setAuditLogs(SAMPLE_AUDIT_LOGS);
    setSession({
      isAuthenticated: true,
      isShopSetupComplete: true,
      token: generateId('tok_demo'),
      userId: DEMO_USER.id,
    });
  }, []);

  const customerSummaries = useMemo(
    () => computeAllCustomerSummaries(customers, transactions),
    [customers, transactions]
  );

  const dashboardMetrics = useMemo(
    () => computeDashboardMetrics(customers, transactions),
    [customers, transactions]
  );

  const value: AppContextValue = {
    session,
    user,
    shop,
    customers,
    transactions,
    auditLogs,
    customerSummaries,
    dashboardMetrics,
    t,
    loginWithOtp,
    registerWithOtp,
    loginAsDemoShopkeeper,
    logout,
    completeShopSetup,
    updateShop,
    setLanguage,
    addCustomer,
    updateCustomer,
    toggleCustomerStatus,
    recordTransaction,
    reverseTransaction,
    resetDemoData,
  };

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
};

export function useApp(): AppContextValue {
  const ctx = useContext(AppContext);
  if (!ctx) {
    throw new Error('useApp must be used within AppProvider');
  }
  return ctx;
}
