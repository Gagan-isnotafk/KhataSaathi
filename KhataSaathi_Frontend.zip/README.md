# KhataSaathi — Voice-First Digital Ledger

**Tagline:** Your Voice. Your Khata. Your Business.

KhataSaathi is a frontend-only React + TypeScript hackathon prototype demonstrating a voice-first digital credit ledger (Udhaar Khata) built for Indian shopkeepers.

## Tech Stack

- **Framework:** React 19 + TypeScript + Vite
- **Styling:** Tailwind CSS v4
- **Routing:** React Router (`react-router-dom`)
- **Charts:** Recharts
- **Icons:** Lucide React
- **State & Persistence:** React Context + `localStorage`
- **Browser APIs:** `MediaRecorder`, `AudioContext` (live waveform), `SpeechSynthesis` (spoken feedback)

## Key Features

1. **Welcome & OTP Login / Registration:** Mobile number login, simulated OTP verification, and multilingual interface selection (English, Hindi, Kannada).
2. **Shop Setup:** Configure shop name, owner name, business category, language, and optional address.
3. **Dashboard:** Real-time totals in integer paise (Total Outstanding, Today's Credit, Today's Repayments, Active Customers), 7-day credit vs repayment chart, quick actions, and prominent Voice Assistant shortcut.
4. **Voice Assistant (Simulated Demo):**
   - Uses browser `MediaRecorder` + live audio waveform visualizer.
   - Simulates Gnani Prisma speech-to-text & structured AI intent extraction (`ADD_CREDIT`, `RECORD_REPAYMENT`, `CHECK_BALANCE`, `CUSTOMER_HISTORY`, `DAILY_SUMMARY`, `TOTAL_OUTSTANDING`, `CREATE_CUSTOMER`).
   - Supports editable transcripts, inline amount correction, duplicate customer clarification, confirmation gate before saving, and spoken `SpeechSynthesis` replies.
5. **Customers & Duplicate Detection:** Search, filter, sort, view profiles, and create customers with live duplicate name/phone warnings.
6. **Customer Ledger:** Chronological ledger with opening balance, credits, repayments, reversals, running balance, and audit-safe transaction reversal (no silent deletion).
7. **Transactions:** Add credit, record repayment, filter by customer/type/source/date/amount range.
8. **Reports:** Daily, Weekly, and Monthly summaries, top outstanding customers chart & table, and CSV ledger export.
9. **Settings:** Edit shop/owner profile, switch language, toggle voice speech feedback, inspect audit logs, reset demo data, or logout.

## Running Locally

```bash
npm install
npm run dev
```

Build for production:

```bash
npm run build
```

## Note on Demo Simulation

Speech transcription and AI intent parsing in this frontend build are **simulated locally in the browser** for demonstration purposes. All financial math uses integer paise and deterministic ledger calculations stored in `localStorage`.
